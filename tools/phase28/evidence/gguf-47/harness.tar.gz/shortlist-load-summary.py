"""Read the shortlist's load numbers from the freshly captured logs."""
import json
import re
from statistics import median

from evaluate import evidence
from quality import jsonlines


all_runs = jsonlines(evidence / "timing.jsonl")
values = []
for arm in ("b-control", "c", "d"):
    for device in ("cpu", "cuda"):
        bench = [row for row in all_runs if row["arm"] == arm and row["device"] == device
                 and "BenchmarkGemmaEvalFirstQuery" in row["case"]]
        stages = [row for row in all_runs if row["arm"] == arm and row["device"] == device
                  and "TestGemmaEvalStages" in row["case"]]
        assert len(bench) == 5 and len(stages) == 3, (arm, device)
        first_query = []
        load_details = []
        for run in bench:
            got = (evidence / run["case"] / "stdout").read_text()
            match = re.search(r"^BenchmarkGemmaEvalFirstQuery-\d+\s+1\s+(\d+(?:\.\d+)?)\s+ns/op", got, re.M)
            first_query.append(float(match.group(1)) / 1e6)
        for run in stages:
            got = (evidence / run["case"] / "stdout").read_text()
            parsed = re.findall(r'stage "([^"]+)" wall_ns (\d+) rss_kib (\d+)', got)
            load_details.append({phase: {"ms": int(ns) / 1e6, "MiB": int(kib) / 1024} for phase, ns, kib in parsed})
        record = {"arm": arm, "device": device, "rule3_ms": first_query,
                  "median_rule3_ms": median(first_query), "under_600_ms": sum(v < 600 for v in first_query),
                  "rule3_peak_host_mib": max(row["host_peak_rss_kib"] for row in bench) / 1024,
                  "stages": load_details}
        for phase in load_details[0]:
            record["median_" + phase.replace(" ", "_")] = {
                key: median(details[phase][key] for details in load_details) for key in ("ms", "MiB")
            }
        if device == "cuda":
            record["rule3_peak_device_mib"] = max(row["device_peak_mib"] for row in bench)
        values.append(record)

with (evidence / "load-summary.json").open("w") as out:
    json.dump(values, out, indent=2)
    print(file=out)
print("| Arm | Device | Verify ms | Decode ms | Rule-3 ms, median (range) | Peak host MiB | Query / post-GC RSS MiB | Peak device MiB |")
print("| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |")
for row in values:
    median_total = row["median_rule3_ms"]
    total = f'{median_total:.1f} ({min(row["rule3_ms"]):.1f}–{max(row["rule3_ms"]):.1f})'
    query, postgc = [row["median_" + name]["MiB"] for name in ("query", "after_GC_with_model_live")]
    print(f'| {row["arm"]} | {row["device"]} | {row["median_verify"]["ms"]:.1f} | '
          f'{row["median_decode_CPU_runtime"]["ms"]:.1f} | {total} | {row["rule3_peak_host_mib"]:,.1f} | '
          f'{query:,.1f} / {postgc:,.1f} | {row.get("rule3_peak_device_mib", "—")} |')
