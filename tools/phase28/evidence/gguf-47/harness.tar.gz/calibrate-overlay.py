"""Give Google controls the same ranking capture as the scratch quant runner."""
import json
from pathlib import Path
import sys


root = Path(sys.argv[1])
destination = Path(sys.argv[2])
scratch = Path(__file__).resolve().parent
folder = Path("internal/semantic/calibrate")
replacements = {}
for name in ("main.go", "fixture.go", "model.go", "reader.go"):
    path = folder / name
    data = (scratch / "eval-source" / path).read_text()
    if name == "main.go":
        data = data.replace(
            "entries := append([]embed.Entry{bge.Entry()}, gemma2.EvaluationEntries()...)",
            "entries := []embed.Entry{bge.Entry(), gemma2.Entry()}",
        ).replace(
            "slices.ContainsFunc(gemma2.EvaluationEntries(), func(e embed.Entry) bool { return *model == e.Model.Name })",
            "*model == gemma2.Entry().Model.Name",
        )
        assert "EvaluationEntries" not in data
    copy = destination / name
    copy.write_text(data)
    replacements[str(root / path)] = str(copy)
print(json.dumps({"Replace": replacements}, indent=2))
