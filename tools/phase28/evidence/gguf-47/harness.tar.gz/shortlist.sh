#!/usr/bin/env bash
set -euo pipefail

scratch=/var/tmp/pbrain-goinfer-48.E2mMmT
export PBRAIN_EVAL_OUTPUT="$scratch/shortlist-v061"
export PBRAIN_EVAL_QUERY_ONLY=1
export PYTHONUNBUFFERED=1
cd "$scratch"
for phase in load cosines retrieval; do
    python3 "$scratch/shortlist.py" "$phase"
    touch "$PBRAIN_EVAL_OUTPUT/.$phase-complete"
done
