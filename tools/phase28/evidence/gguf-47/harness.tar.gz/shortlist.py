"""The v0.6.1 load and quality checks requested before the next goinfer release."""
import argparse
import contextlib
import json

from evaluate import calibrate, compare, evidence, prepare, sync, tests
from quality import overlap


arms = ("b-control", "c", "d")


def run_load_checks():
    for arm in arms:
        prepare(arm)
    for device in ("cpu", "cuda"):
        for round_ in range(1, 6):
            for arm in arms if round_ % 2 else arms[::-1]:
                tests(arm, device, "BenchmarkGemmaEvalFirstQuery", first=round_)
        for arm in arms:
            tests(arm, device, "TestGemmaEvalStages", count=3)


def compare_passages():
    for device in ("cpu", "cuda"):
        shapes = ("small",) if device == "cpu" else ("small", "slice")
        for shape in shapes:
            brains = {arm: sync(arm, device, shape, 1) for arm in arms}
            for quant in ("c", "d"):
                compare(brains["b-control"], brains[quant], f"{quant}-b-{device}-{shape}",
                        59 if shape == "small" else 1223)


def run_retrieval():
    cutoffs = {}
    for arm in arms:
        tests(arm, "cpu", "TestGemmaEvalVectors")
        calibrate(arm, "cpu", "fit", None)
        fit = evidence / f"{arm}-cpu-calibrate-fit-fit/stdout"
        cutoffs[arm] = json.loads(fit.read_text())["model"]["cutoff"]
        calibrate(arm, "cpu", "check", cutoffs[arm])
    for arm in arms:
        calibrate(arm, "cuda", "check", cutoffs[arm])
    for device in ("cpu", "cuda"):
        reports = {arm: evidence / f"{arm}-{device}-calibrate-check-{cutoffs[arm]}/stdout" for arm in arms}
        for quant in ("c", "d"):
            filename = evidence / f"{quant}-b-{device}-quality-summary.json"
            with filename.open("x") as f, contextlib.redirect_stdout(f):
                overlap("b-control", quant, device, reports["b-control"], reports[quant])


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("phase", choices=("load", "cosines", "retrieval"))
    args = p.parse_args()
    {"load": run_load_checks, "cosines": compare_passages, "retrieval": run_retrieval}[args.phase]()
