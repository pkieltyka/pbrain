"""Pinned, serial Gemma measurements. Run once #43 has released pax."""
import argparse
import contextlib
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sqlite3
import statistics
import struct
import subprocess
import time


root = Path(__file__).resolve().parent
evidence = Path(os.environ.get("PBRAIN_EVAL_OUTPUT", root / "evidence"))
repo = Path("/home/peter/Dev/pkieltyka/pbrain.worktrees/peter-lead-dev")
phase22 = Path("/var/tmp/pbrain-phase28-gemma-22.5UFzx5")
prior_slice = Path("/var/tmp/pbrain-sync-throughput.yqF3OJ")
base_build = Path("/var/tmp/pbrain-sync-43.XW3O3B")
models = Path((root / "model-root").read_text().strip())
registry = {
    "a": ("embeddinggemma-2", phase22 / "gemma-pack", base_build),
    "b": ("embeddinggemma-2", phase22 / "gemma-pack", root),
    "b-control": ("embeddinggemma-2", phase22 / "gemma-pack", root / "eval-bin"),
    "c": ("embeddinggemma-2-q8-0", models / "q8", root / "eval-bin"),
    "d": ("embeddinggemma-2-ud-q6-k-xl", models / "q6", root / "eval-bin"),
}
fixtures = {
    "small": (phase22 / "small-cpu/docs/brain", repo / "tools/phase28/evidence/gemma-pax-22/fixture-paths.txt", 32, 59),
    "slice": (prior_slice / "bge-corpus/docs/brain", prior_slice / "fixture-files.txt", 128, 1223),
}


def sha256(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def gpu(*args):
    return subprocess.check_output(["nvidia-smi", "-i", "0", *args], text=True).strip()


def append(path, data):
    with path.open("a") as handle:
        print(json.dumps(data, sort_keys=True, allow_nan=False), file=handle)


def primed(pack):
    return {file.name: {"size": file.stat().st_size, "sha256": sha256(file)} for file in sorted(pack.iterdir()) if file.is_file()}


def host(case, device):
    now = time.strftime("%FT%TZ", time.gmtime())
    stats = gpu("--query-gpu=uuid,name,driver_version,memory.total,memory.free,memory.used,utilization.gpu",
                "--format=csv,noheader")
    compute = gpu("--query-compute-apps=pid,used_memory", "--format=csv,noheader")
    append(evidence / "preflight.jsonl", {"case": case, "device": device, "at": now,
           "loadavg": Path("/proc/loadavg").read_text().strip(), "nvidia": stats,
           "compute": compute, "affinity": "0-3", "GOMAXPROCS": 4})
    if device == "cuda":
        assert not compute, ("NVIDIA busy", compute)
    uuid, _, _, _, _, used, _ = next(csv.reader([stats], skipinitialspace=True))
    return uuid, int(used.split()[0])


def cpu_stat():
    counters = [int(field) for field in Path("/proc/stat").read_text().splitlines()[0].split()[1:9]]
    return sum(counters), sum(counters) - counters[3] - counters[4]


def environment(case, device, model, pack, uuid):
    env = {key: value for key, value in os.environ.items() if not key.startswith("PBRAIN_")}
    for key in ("GODEBUG", "GOGC", "GOMEMLIMIT"):
        env.pop(key, None)
    env.update(PBRAIN_CACHE=str(evidence / case / "cache"), GIT_CONFIG_GLOBAL=os.devnull,
               GIT_CONFIG_NOSYSTEM="1", GOMAXPROCS="4", TZ="UTC", LC_ALL="C",
               PBRAIN_ALLOW_GEMMA2="1", PBRAIN_TEST_GEMMA2_PACK=str(pack), PBRAIN_EVAL_MODEL=model,
               PBRAIN_EVAL_SMALL_PATHS=str(fixtures["small"][1]), PBRAIN_EVAL_SMALL_ROOT=str(fixtures["small"][0]),
               PBRAIN_EVAL_SLICE_PATHS=str(fixtures["slice"][1]), PBRAIN_EVAL_SLICE_ROOT=str(fixtures["slice"][0]),
               PBRAIN_EVAL_DEVICE="cuda:0" if device == "cuda" else "",
               PBRAIN_EVAL_DUMP=str(evidence / case / "vectors.jsonl"),
               PBRAIN_EVAL_QUESTIONS=str(repo / "internal/semantic/calibrate/testdata/retrieval/questions.json"),
               PBRAIN_EVAL_QUERY_ONLY=os.environ.get("PBRAIN_EVAL_QUERY_ONLY", ""),
               PBRAIN_EVAL_SAME_FILE=os.environ.get("PBRAIN_EVAL_SAME_FILE", ""),
               PBRAIN_EVAL_PRESTAGED=str((models / "google") if model == "embeddinggemma-2" else pack),
               CUDA_VISIBLE_DEVICES=uuid if device == "cuda" else "",
               LD_LIBRARY_PATH="/run/opengl-driver/lib")
    return env


def measure(case, arm, device, binary, args, cwd, ok=(0,)):
    model, pack, _ = registry[arm]
    out = evidence / case
    out.mkdir(parents=True, exist_ok=True)
    # Use instantaneous CPU counters because load averages retain the preceding pass.
    for _ in range(60):
        total, busy = cpu_stat()
        time.sleep(1)
        after_total, after_busy = cpu_stat()
        occupancy = (after_busy - busy) / (after_total - total)
        if occupancy <= 0.04:
            break
    else:
        raise RuntimeError(f"{case}: host remained busy for one minute")
    nvidia, idle = host(case, device)
    env = environment(case, device, model, pack, nvidia)
    cmd = ["taskset", "-c", "0-3", str(binary), *args]
    with contextlib.ExitStack() as cleanup:
        sample = out / "nvidia.csv"
        if device == "cuda":
            samplog = cleanup.enter_context(sample.open("w"))
            sampler = subprocess.Popen(
                ["stdbuf", "-oL", "nvidia-smi", "-i", nvidia, "--query-gpu=timestamp,memory.used,utilization.gpu",
                 "--format=csv,noheader,nounits", "-lms", "100"], stdout=samplog,
            )
            def stop_sampler():
                sampler.terminate()
                sampler.wait(timeout=5)
            cleanup.callback(stop_sampler)
        stdout = cleanup.enter_context((out / "stdout").open("x"))
        stderr = cleanup.enter_context((out / "stderr").open("x"))
        start = time.monotonic_ns()
        with subprocess.Popen(cmd, cwd=cwd, env=env, stdout=stdout, stderr=stderr) as proc:
            _, status, usage = os.wait4(proc.pid, 0)
            proc.returncode = os.waitstatus_to_exitcode(status)
        wall = (time.monotonic_ns() - start) / 1e9
    result = {"case": case, "arm": arm, "model": model, "device": device, "argv": cmd,
              "wall_s": wall, "host_peak_rss_kib": usage.ru_maxrss, "exit": proc.returncode,
              "preflight_host_busy_pct": occupancy * 100}
    if device == "cuda":
        with sample.open() as rows:
            usage = [(int(row[1]), int(row[2])) for row in csv.reader(rows)]
        assert usage, (case, "missing device samples")
        result.update(device_peak_mib=max(memory for memory, _ in usage), device_idle_mib=idle,
                      device_samples=len(usage), device_median_util_pct=statistics.median(util for _, util in usage))
    append(evidence / "timing.jsonl", result)
    assert proc.returncode in ok, (case, proc.returncode, out / "stderr", out / "stdout")
    return result, (out / "stdout").read_text()


def sync(arm, device, shape, rep):
    model, pack, binaries = registry[arm]
    notes, manifest, items, passages = fixtures[shape]
    case = f"{arm}-{device}-sync-{shape}-{rep}"
    corpus = evidence / case / "corpus"
    brain = corpus / "docs/brain"
    brain.mkdir(parents=True)
    digest = hashlib.sha256()
    for rel in sorted(manifest.read_text().splitlines()):
        source = notes / rel
        dest = brain / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        digest.update(rel.encode() + b"\0" + bytes.fromhex(sha256(dest)))
    (brain / "pbrain.toml").write_text(f'[semantic]\nmodel = "{model}"\n')
    (brain / "personal.toml").write_text(f'model_path = "{pack}"\n')
    append(evidence / "fixture.jsonl", {"case": case, "manifest": str(manifest), "manifest_sha256": sha256(manifest),
                                      "corpus_sha256": digest.hexdigest(), "items": items, "passages": passages})
    opts = ["--device", "cuda:0" if device == "cuda" else "cpu", "--json"]
    report, raw = measure(case, arm, device, binaries / f"pbrain-{device}", ["sync", *opts], corpus)
    sections = json.loads(raw)["sections"]
    assert len(sections) == 1, sections
    row = sections[0]
    assert row["items"] == items and row["passages_embedded"] == passages and row["passages_reused"] == 0, row
    assert row["device"] == opts[1], row
    report.update(passages=passages, passages_per_s=passages / report["wall_s"], sections=sections)
    append(evidence / "sync.jsonl", report)
    return brain


def rows(brain):
    index = brain / ".pbrain/index"
    manifest = json.loads((index / "manifest").read_text())
    db = index / manifest["db"]
    assert db.stat().st_size == manifest["size"]
    assert manifest["dim"] == 768
    with contextlib.closing(sqlite3.connect(db.as_uri() + "?mode=ro&immutable=1", uri=True)) as conn:
        assert conn.execute("PRAGMA quick_check").fetchall() == [("ok",)]
        passages = conn.execute(
            "SELECT item.path, item.id, passage.ord, passage.start, passage.stop, passage.digest, passage.vector "
            "FROM passage JOIN item ON passage.item_id=item.id ORDER BY item.path, passage.ord",
        ).fetchall()
    return manifest, passages


def compare(left, right, label, count, threshold=None, identical_fingerprint=False):
    lm, lp = rows(left)
    rm, rp = rows(right)
    assert len(lp) == len(rp) == count, (left, right, len(lp), len(rp))
    assert (lm["fingerprint"] == rm["fingerprint"]) == identical_fingerprint, (lm, rm)
    samples = []
    for a, b in zip(lp, rp, strict=True):
        assert a[:-1] == b[:-1], (a[:3], b[:3])
        x, y = (struct.unpack("<768f", p[-1]) for p in (a, b))
        nx, ny = [math.fsum(v * v for v in vector) for vector in (x, y)]
        assert abs(nx - 1) <= 1e-5 and abs(ny - 1) <= 1e-5, (a[:3], nx, ny)
        cosine = math.fsum(xi * yi for xi, yi in zip(x, y, strict=True)) / math.sqrt(nx * ny)
        assert math.isfinite(cosine), (a[:3], cosine)
        samples.append({"path": a[0], "ordinal": a[2], "start": a[3], "stop": a[4],
                        "digest": a[5].hex(), "cosine": min(cosine, 1), "equal_bytes": a[-1] == b[-1]})
    samples.sort(key=lambda row: (row["cosine"], row["path"], row["ordinal"]))
    values = [sample["cosine"] for sample in samples]
    result = {"pair": label, "count": count, "worst": samples[0], "p5_nearest_rank": values[math.ceil(0.05 * count) - 1],
              "median": statistics.median(values), "equal_bytes": sum(s["equal_bytes"] for s in samples),
              "left_fingerprint": lm["fingerprint"], "right_fingerprint": rm["fingerprint"]}
    with (evidence / f"{label}-vectors.jsonl").open("x") as out:
        for sample in samples:
            print(json.dumps(sample, sort_keys=True), file=out)
    append(evidence / "vector-summary.jsonl", result)
    if threshold is not None:
        assert values[0] >= threshold, (threshold, result)
    return result


def tests(arm, device, function, count=1, first=1):
    work = root / {"a": "base-source", "b": "base-source"}.get(arm, "eval-source")
    arm_group = arm if arm in ("a", "b") else "eval"
    test_dir = Path(os.environ.get("PBRAIN_EVAL_TEST_BIN_DIR", root / f"tests-{arm_group}"))
    tests = test_dir / f"gemma2-{device}.test"
    benchmark = function.startswith("Benchmark")
    for i in range(first, first + count):
        label = f"{arm}-{device}-{function}-{i}"
        args = ["-test.run", "^$", "-test.bench", f"^{function}$", "-test.benchtime", "1x"] if benchmark else ["-test.run", f"^{function}$", "-test.v"]
        _, out = measure(label, arm, device, tests, args, work / "internal/embed/gemma2")
        if benchmark:
            assert "ns/op" in out, (function, out)
        else:
            assert f"--- PASS: {function}" in out, (function, out)


def prepare(arm):
    _, files, binaries = registry[arm]
    evidence.mkdir(exist_ok=True)
    report = {"arm": arm, "files": primed(files)}
    for device in ("cpu", "cuda"):
        binary = binaries / f"pbrain-{device}"
        report[device] = {"file": str(binary), "size": binary.stat().st_size, "sha256": sha256(binary),
                          "version": subprocess.check_output(["go", "version", "-m", str(binary)], text=True)}
    append(evidence / "binary-and-pins.jsonl", report)


def calibrate(arm, device, stage, cutoff):
    model, pack, binaries = registry[arm]
    binary = (root / f"tests-{arm}" if arm in ("a", "b") else binaries) / f"calibrate-{device}"
    case = f"{arm}-{device}-calibrate-{stage}-{cutoff if cutoff is not None else 'fit'}"
    args = ["-model", model, "-model-path", str(pack), "-stage", stage,
            "-index-device", "cuda:0" if device == "cuda" else "cpu"]
    if cutoff is not None:
        args += ["-cutoff", str(cutoff)]
    args.append(str(repo / "internal/semantic/calibrate/testdata/retrieval"))
    timing, out = measure(case, arm, device, binary, args, repo, ok=(0, 1))
    report = json.loads(out)
    assert report["model"]["name"] == model
    append(evidence / "retrieval.jsonl", {"case": case, "cutoff": report["model"]["cutoff"],
           "release_gate_exit": timing["exit"], "path": str(evidence / case / "stdout")})


def one_item_search(arm):
    model, pack, binaries = registry[arm]
    corpus = evidence / f"{arm}-one-item"
    brain = corpus / "docs/brain"
    notes = brain / "notes"
    notes.mkdir(parents=True)
    (brain / "pbrain.toml").write_text(f'[semantic]\nmodel = "{model}"\n')
    (brain / "personal.toml").write_text(f'model_path = "{pack}"\n')
    (notes / "session-storage.md").write_text(
        "---\nkind: note\ntitle: Session storage\n---\n"
        "Authenticated sessions persist in Redis under their session keys.\n"
    )
    binary = binaries / "pbrain-cpu"
    _, result = measure(f"{arm}-one-item-sync", arm, "cpu", binary, ["sync", "--device", "cpu", "--json"], corpus)
    section, = json.loads(result)["sections"]
    assert section["passages_embedded"] == 1 and section["device"] == "cpu", section
    query = ["search", "where is login state kept", "--json"]
    _, strict = measure(f"{arm}-one-item-strict", arm, "cpu", binary, query, corpus)
    assert not json.loads(strict)["results"], strict
    semantic = query + ["--semantic"]
    for i in range(1, 6):
        case = f"{arm}-one-item-search-{i}"
        _, result = measure(case, arm, "cpu", binary, semantic, corpus)
        rows = json.loads(result)["results"]
        error = (evidence / case / "stderr").read_text()
        assert "semantic_not_ready" not in error and "semantic_partial" not in error, error
        append(evidence / "one-item-search.jsonl", {"case": case,
               "semantic_hits": [row["id"] for row in rows if row.get("semantic")]})


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="command", required=True)
    for command in ("prepare", "sync", "tests", "calibrate"):
        one = sub.add_parser(command)
        one.add_argument("arm", choices=registry)
        if command != "prepare":
            one.add_argument("device", choices=("cpu", "cuda"))
        if command == "sync":
            one.add_argument("shape", choices=fixtures)
            one.add_argument("rep", type=int)
        if command == "tests":
            one.add_argument("function")
            one.add_argument("--count", type=int, default=1)
            one.add_argument("--first", type=int, default=1)
        if command == "calibrate":
            one.add_argument("stage", choices=("calibration", "fit", "check"))
            one.add_argument("--cutoff", type=float)
    pair = sub.add_parser("compare")
    pair.add_argument("left")
    pair.add_argument("right")
    pair.add_argument("label")
    pair.add_argument("count", type=int)
    pair.add_argument("--threshold", type=float)
    pair.add_argument("--same-model", action="store_true")
    opt = p.parse_args()
    if opt.command == "prepare":
        prepare(opt.arm)
    elif opt.command == "sync":
        print(sync(opt.arm, opt.device, opt.shape, opt.rep))
    elif opt.command == "tests":
        tests(opt.arm, opt.device, opt.function, opt.count, opt.first)
    elif opt.command == "calibrate":
        calibrate(opt.arm, opt.device, opt.stage, opt.cutoff)
    else:
        brain = lambda case: evidence / case / "corpus/docs/brain"
        print(compare(brain(opt.left), brain(opt.right), opt.label, opt.count, opt.threshold, opt.same_model))


if __name__ == "__main__":
    main()
