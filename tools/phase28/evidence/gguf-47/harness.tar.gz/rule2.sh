#!/usr/bin/env bash
set -euo pipefail

scratch=/var/tmp/pbrain-goinfer-48.E2mMmT
export PBRAIN_EVAL_OUTPUT="$scratch/rule2-v061"
export PBRAIN_EVAL_TEST_BIN_DIR="$PBRAIN_EVAL_OUTPUT/bin"
export PBRAIN_EVAL_SAME_FILE=1
export PYTHONUNBUFFERED=1
export GOWORK=off CGO_ENABLED=0 GOMAXPROCS=4
unset GOFLAGS
mkdir -p "$PBRAIN_EVAL_TEST_BIN_DIR"

cd "$scratch/eval-source"
python3 -c 'import json, sys; json.dump({"Replace": {sys.argv[1]: sys.argv[2]}}, sys.stdout)' \
    "$PWD/internal/embed/gemma2/gemma_eval_test.go" "$scratch/gemma_eval_test.go" > "$PBRAIN_EVAL_OUTPUT/overlay.json"
for device in cpu cuda; do
    tags=()
    if [[ $device == cuda ]]; then
        tags=(-tags cuda)
    fi
    taskset -c 16-31 go test -p 2 -vet=off -trimpath -c -overlay="$PBRAIN_EVAL_OUTPUT/overlay.json" \
        "${tags[@]}" -o "$PBRAIN_EVAL_TEST_BIN_DIR/gemma2-$device.test" ./internal/embed/gemma2
done
sha256sum "$PBRAIN_EVAL_TEST_BIN_DIR"/*.test > "$PBRAIN_EVAL_OUTPUT/test-binaries.sha256"
go version -m "$PBRAIN_EVAL_TEST_BIN_DIR"/*.test > "$PBRAIN_EVAL_OUTPUT/test-build-info.log"

llama="$HOME/goinfer-logs/eg2-gguf-q8-q6/llama-8d60873df-cpu"
sha256sum -c "$llama/probe.sha256" > "$PBRAIN_EVAL_OUTPUT/reference-binary-check.log"
cd "$scratch"
for arm in c d; do
    python3 "$scratch/evaluate.py" prepare "$arm"
    python3 "$scratch/evaluate.py" tests "$arm" cpu TestGemmaEvalVectors
    python3 "$scratch/evaluate.py" tests "$arm" cuda TestGemmaEvalVectors
    python3 "$scratch/quality.py" reference "$arm"
done
touch "$PBRAIN_EVAL_OUTPUT/complete"
