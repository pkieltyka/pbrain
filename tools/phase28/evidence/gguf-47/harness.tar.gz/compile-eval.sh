#!/usr/bin/env bash
set -euo pipefail

scratch=/var/tmp/pbrain-goinfer-48.E2mMmT
repo=/home/peter/Dev/pkieltyka/pbrain.worktrees/peter-lead-dev
base=004e7e3b16661358b306a4f7701ba412cd62558b
pin=$(cat "$scratch/v061-pin/candidate-revision")
export GOWORK=off CGO_ENABLED=0 GOMAXPROCS=4
unset GOFLAGS
set -x
if [[ ! -d $scratch/base-source ]]; then
    mkdir "$scratch/base-source"
    git -C "$repo" archive "$base" | tar -x -C "$scratch/base-source"
fi
mode=${1:?specify a, b or eval}
mod=()
case "$mode" in
    a) cd "$scratch/base-source" ;;
    b)
        cd "$repo"
        [[ $(git rev-parse HEAD) == "$pin" ]]
        ;;
    eval)
        cd "$scratch/eval-source"
        diff -u <(git -C "$repo" show "$pin:go.mod") go.mod
        diff -u <(git -C "$repo" show "$pin:go.sum") go.sum
        ;;
    *) exit 2 ;;
esac
out="$scratch/tests-$mode"
mkdir -p "$out"
python3 -c 'import json, sys; json.dump({"Replace": {sys.argv[1]: sys.argv[2]}}, sys.stdout)' \
    "$PWD/internal/embed/gemma2/gemma_eval_test.go" "$scratch/gemma_eval_test.go" > "$out/test-overlay.json"
go list "${mod[@]}" -m all > "$out/modules.txt"
if [[ $mode == eval ]]; then
    caldir="$scratch/eval-bin"
    calflags=()
else
    caldir="$out"
    mkdir -p "$out/calibrate-source"
    python3 "$scratch/calibrate-overlay.py" "$PWD" "$out/calibrate-source" > "$out/calibrate-overlay.json"
    calflags=(-overlay="$out/calibrate-overlay.json")
fi
for variant in cpu cuda; do
    tags=()
    if [[ $variant == cuda ]]; then
        tags=(-tags cuda)
    fi
    go test -p 2 -vet=off -trimpath -c -overlay="$out/test-overlay.json" "${mod[@]}" "${tags[@]}" \
        -o "$out/gemma2-$variant.test" ./internal/embed/gemma2
    go version -m "$out/gemma2-$variant.test"
    sha256sum "$out/gemma2-$variant.test"
    if [[ $mode == eval ]]; then
        mkdir -p "$scratch/eval-bin"
        go build -p 2 -trimpath -ldflags='-s -w' "${mod[@]}" "${tags[@]}" \
            -o "$scratch/eval-bin/pbrain-$variant" ./cmd/pbrain
    fi
    go build -p 2 -trimpath -ldflags='-s -w' "${mod[@]}" "${tags[@]}" "${calflags[@]}" \
        -o "$caldir/calibrate-$variant" ./internal/semantic/calibrate
done
