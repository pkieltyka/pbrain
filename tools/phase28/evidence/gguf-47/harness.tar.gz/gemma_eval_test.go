package gemma2

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"slices"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/pkieltyka/pbrain/internal/embed"
	"github.com/pkieltyka/pbrain/internal/item"
	"github.com/pkieltyka/pbrain/internal/semantic"
	"github.com/pkieltyka/pbrain/internal/sys"
)

// The scratch evaluator replaces one test hook with its three model entries.
var evaluationEntries = func() []embed.Entry { return []embed.Entry{Entry()} }

const evalQuery = "where is login state kept"

func evalModel(t testing.TB) (embed.Registry, embed.Model) {
	t.Helper()
	r := embed.NewRegistry(evaluationEntries()...)
	name := os.Getenv("PBRAIN_EVAL_MODEL")
	if name == "" {
		name = Entry().Model.Name
	}
	model, ok := r.Lookup(name)
	if !ok {
		t.Fatalf("unknown evaluation model %q", name)
	}
	return r, model
}

func evalOptions() embed.OpenOptions {
	return embed.OpenOptions{Device: os.Getenv("PBRAIN_EVAL_DEVICE")}
}

func evalDevice(t testing.TB, x embed.Embedder, opt embed.OpenOptions) {
	t.Helper()
	want := opt.Device
	if want == "" {
		want = "cpu"
	}
	if x.Info().Device != want {
		t.Fatalf("opened %q, wanted %q", x.Info().Device, want)
	}
}

func BenchmarkGemmaEvalFirstQuery(b *testing.B) {
	d := fixtureDir(b, "PBRAIN_TEST_GEMMA2_PACK")
	r, model := evalModel(b)
	opt := evalOptions()
	for b.Loop() {
		a := verified(b, d, model)
		x, err := r.Open(b.Context(), a, opt)
		if err != nil {
			b.Fatal(err)
		}
		evalDevice(b, x, opt)
		got, err := x.Embed(b.Context(), embed.Query, []string{evalQuery})
		if err != nil || len(got) != 1 || len(got[0]) != dimension {
			b.Fatalf("expected one valid query vector: %v", err)
		}
		if err := x.Close(); err != nil {
			b.Fatal(err)
		}
	}
}

func evalRSS(t testing.TB) int64 {
	t.Helper()
	data, err := os.ReadFile("/proc/self/status")
	if err != nil {
		t.Fatal(err)
	}
	for line := range strings.Lines(string(data)) {
		if strings.HasPrefix(line, "VmRSS:") {
			kib, err := strconv.ParseInt(strings.Fields(line)[1], 10, 64)
			if err != nil {
				t.Fatal(err)
			}
			return kib
		}
	}
	t.Fatal("VmRSS missing")
	return 0
}

func TestGemmaEvalStages(t *testing.T) {
	d := fixtureDir(t, "PBRAIN_TEST_GEMMA2_PACK")
	r, model := evalModel(t)
	opt := evalOptions()
	snapshot := func(stage string, start time.Time) {
		t.Logf("stage %q wall_ns %d rss_kib %d", stage, time.Since(start).Nanoseconds(), evalRSS(t))
	}
	start := time.Now()
	a := verified(t, d, model)
	snapshot("verify", start)
	start = time.Now()
	x, err := r.Open(t.Context(), a, embed.OpenOptions{})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = x.Close() })
	if a.Files != nil {
		t.Fatal("adapter retained verified artifact in the handoff")
	}
	snapshot("decode CPU runtime", start)
	if opt.Device == "cuda:0" {
		start = time.Now()
		if err := attachAccelerator(x.(*encoder).model); err != nil {
			t.Fatal(err)
		}
		snapshot("direct CUDA attach", start)
	} else {
		evalDevice(t, x, opt)
	}
	start = time.Now()
	if _, err := x.Embed(t.Context(), embed.Query, []string{evalQuery}); err != nil {
		t.Fatal(err)
	}
	snapshot("query", start)
	start = time.Now()
	runtime.GC()
	snapshot("after GC with model live", start)
	runtime.KeepAlive(x)
	start = time.Now()
	if err := x.Close(); err != nil {
		t.Fatal(err)
	}
	snapshot("close", start)
}

type evalText struct {
	Key  string
	Role embed.Role
	Text string
}

func evalTexts(t *testing.T) []evalText {
	t.Helper()
	var texts []evalText
	for i, row := range references(t) {
		role := embed.Document
		if row.Role == "query" {
			role = embed.Query
		}
		texts = append(texts, evalText{fmt.Sprintf("reference/%d", i), role, row.Text})
	}
	texts = append(texts,
		evalText{"literal", embed.Document, "a <bos> <eos> <start_of_turn>"},
		evalText{"long-query", embed.Query, strings.Repeat("語の", 9500)},
		evalText{"long-document", embed.Document, strings.Repeat("語の", 9500) + "\n\nkeep this tail"},
	)
	fixtures := []struct {
		id, paths, brain string
		want             int
	}{
		{"small", "PBRAIN_EVAL_SMALL_PATHS", "PBRAIN_EVAL_SMALL_ROOT", 59},
		{"slice", "PBRAIN_EVAL_SLICE_PATHS", "PBRAIN_EVAL_SLICE_ROOT", 1223},
	}
	for _, fixture := range fixtures {
		data, err := os.ReadFile(os.Getenv(fixture.paths))
		if err != nil {
			t.Fatal(err)
		}
		before := len(texts)
		for _, path := range strings.Split(strings.TrimSpace(string(data)), "\n") {
			path = strings.TrimPrefix(path, "docs/brain/")
			name := filepath.Join(os.Getenv(fixture.brain), path)
			data, err := os.ReadFile(name)
			if err != nil {
				t.Fatal(err)
			}
			header, body, _, err := item.Parse(strings.TrimSuffix(filepath.Base(path), ".md"), data)
			if err != nil {
				t.Fatal(err)
			}
			for i, p := range semantic.Passages(header.Title, data[body:]) {
				key := fmt.Sprintf("%s/%s/%d/%x", fixture.id, path, i, p.Digest)
				texts = append(texts, evalText{key, embed.Document, p.Text})
			}
		}
		if len(texts)-before != fixture.want {
			t.Fatalf("%s has %d passages, want %d", fixture.id, len(texts)-before, fixture.want)
		}
	}
	return texts
}

func TestGemmaEvalPreparedIDs(t *testing.T) {
	d := fixtureDir(t, "PBRAIN_TEST_GEMMA2_PACK")
	r, model := evalModel(t)
	x, err := r.Open(t.Context(), verified(t, d, model), embed.OpenOptions{})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = x.Close() })
	e := x.(*encoder)
	texts := evalTexts(t)
	for _, row := range texts {
		ids, err := e.tokenIDs(row.Role, row.Text)
		if err != nil || len(ids) < 2 || len(ids) > maxTokens {
			t.Fatalf("%s expected a framed sequence of up to %d IDs: %v", row.Key, maxTokens, err)
		}
		if ids[0] != e.bos || ids[len(ids)-1] != e.eos {
			t.Fatalf("%s missing outer markers", row.Key)
		}
		if row.Key == "literal" {
			for _, marker := range []string{"<bos>", "<eos>", "<start_of_turn>"} {
				if id, ok := e.tokenizer.TokenID(marker); ok && slices.Contains(ids[1:len(ids)-1], id) {
					t.Fatalf("literal %q parsed as a special token", marker)
				}
			}
		}
		data, err := json.Marshal(ids)
		if err != nil {
			t.Fatal(err)
		}
		t.Logf("prepared %q %d %x", row.Key, len(ids), sha256.Sum256(data))
	}
}

func TestGemmaEvalVectors(t *testing.T) {
	d := fixtureDir(t, "PBRAIN_TEST_GEMMA2_PACK")
	r, model := evalModel(t)
	opt := evalOptions()
	x, err := r.Open(t.Context(), verified(t, d, model), opt)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = x.Close() })
	evalDevice(t, x, opt)
	type query struct {
		ID   string `json:"id"`
		Text string `json:"q"`
	}
	output := os.Getenv("PBRAIN_EVAL_DUMP")
	if output == "" {
		t.Fatal("set PBRAIN_EVAL_DUMP")
	}
	var data []evalText
	sameFile := os.Getenv("PBRAIN_EVAL_SAME_FILE") == "1"
	if sameFile || os.Getenv("PBRAIN_EVAL_QUERY_ONLY") != "1" {
		for _, row := range evalTexts(t) {
			if strings.HasPrefix(row.Key, "reference/") || (sameFile && strings.HasPrefix(row.Key, "small/")) {
				data = append(data, row)
			}
		}
	}
	if sameFile {
		if len(data) != 81 {
			t.Fatalf("expected 22 reference and 59 passage inputs, got %d", len(data))
		}
	} else {
		raw, err := os.ReadFile(os.Getenv("PBRAIN_EVAL_QUESTIONS"))
		if err != nil {
			t.Fatal(err)
		}
		var qs []query
		if err := json.Unmarshal(raw, &qs); err != nil || len(qs) != 107 {
			t.Fatalf("fixture queries = %d: %v", len(qs), err)
		}
		for _, q := range qs {
			data = append(data, evalText{"query/" + q.ID, embed.Query, q.Text})
		}
	}
	f, err := os.OpenFile(output, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o600)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	e := x.(*encoder)
	for _, row := range data {
		ids, err := e.tokenIDs(row.Role, row.Text)
		if err != nil {
			t.Fatal(err)
		}
		v, err := e.embedIDs(t.Context(), ids)
		if err != nil {
			t.Fatalf("%s: %v", row.Key, err)
		}
		if err := enc.Encode(map[string]any{"key": row.Key, "ids": ids, "vector": v}); err != nil {
			t.Fatal(err)
		}
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	t.Logf("recorded %d vectors with prepared IDs for %s", len(data), model.Name)
}

func TestGemmaEvalBatchParity(t *testing.T) {
	if evalOptions().Device != "cuda:0" {
		t.Skip("explicit NVIDIA device required")
	}
	d := fixtureDir(t, "PBRAIN_TEST_GEMMA2_PACK")
	r, model := evalModel(t)
	// Probe the same packing code under a different grouping and order.
	opt := evalOptions()
	opt.MemoryBudget = 1 << 20
	x, err := r.Open(t.Context(), verified(t, d, model), opt)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = x.Close() })
	evalDevice(t, x, opt)
	var small []string
	for _, row := range evalTexts(t) {
		if strings.HasPrefix(row.Key, "small/") {
			small = append(small, row.Text)
		}
	}
	got, err := x.Embed(t.Context(), embed.Document, small)
	if err != nil {
		t.Fatal(err)
	}
	for i, text := range small {
		one, err := x.Embed(t.Context(), embed.Document, []string{text})
		if err != nil || len(one) != 1 || !sameVectorBits(got[i], one[0]) {
			t.Fatalf("singleton differs at passage %d: %v", i, err)
		}
	}
	e := x.(*encoder)
	e.info.Budget = 6 << 30
	slices.Reverse(small)
	reversed, err := e.Embed(t.Context(), embed.Document, small)
	if err != nil {
		t.Fatal(err)
	}
	for i, vector := range reversed {
		if !sameVectorBits(got[len(got)-1-i], vector) {
			t.Fatalf("reverse/wider pack differs at passage %d", i)
		}
	}
	t.Logf("%d CUDA document vectors agree across singleton, tight and reversed wide packing", len(got))
}

func sameVectorBits(a, b []float32) bool {
	return slices.EqualFunc(a, b, func(x, y float32) bool {
		return math.Float32bits(x) == math.Float32bits(y)
	})
}

func TestGemmaEvalWrongFile(t *testing.T) {
	// Exercise dispatcher rejection without allocating verified weights.
	if len(evaluationEntries()) != 3 {
		t.Skip("scratch GGUF registry required")
	}
	entries := evaluationEntries()
	fingerprints := make(map[string]bool, len(entries))
	for _, entry := range entries {
		fp := semantic.IndexFingerprint(entry.Model)
		if fingerprints[fp] {
			t.Fatalf("index fingerprint shared by %s", entry.Model.Name)
		}
		fingerprints[fp] = true
	}
	entry := entries[1]
	wrongSize := entries[2].Model.Files[0].Size
	path := t.TempDir()
	f, err := os.Create(filepath.Join(path, entry.Model.Files[0].Name))
	if err != nil {
		t.Fatal(err)
	}
	err = errors.Join(f.Truncate(wrongSize), f.Close())
	if err != nil {
		t.Fatal(err)
	}
	dir, err := sys.OpenDir(path)
	if err != nil {
		t.Fatal(err)
	}
	defer dir.Close()
	if _, err := embed.Verify(sys.Native(), dir, entry.Model); !errors.Is(err, embed.ErrWrongModel) {
		t.Fatalf("swapped quant: got %v, want a verification error", err)
	}
	r := embed.NewRegistry(entries...)
	a := &embed.Artifact{Model: entry.Model, Files: [][]byte{[]byte("not GGUF")}}
	if _, err := r.Open(context.Background(), a, embed.OpenOptions{}); err == nil || a.Files != nil {
		t.Fatalf("invalid decoder input survived or artifact was retained: %v", err)
	}
}
