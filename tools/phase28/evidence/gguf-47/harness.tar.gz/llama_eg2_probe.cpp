// Compact prepared-IDs embedding probe against local llama.cpp (8d60873df).
// Reads JSONL requests from stdin (one JSON array per line or TSV: id<TAB>id0 id1 ...),
// or --tsv <path> (format: <group>\t<id>\t<tok0> <tok1> ...), runs llama_decode with
// non-causal mean pooling, flash attention disabled, and outputs TSV/JSON normalized 768-D vectors.
// Keeps zero JSON parser dependency so it compiles in <1s against libllama.so.

#include "llama.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

struct SeqInput {
    std::string group;
    std::string id;
    std::vector<llama_token> tokens;
};

static bool load_tsv(const std::string & path, std::vector<SeqInput> & out) {
    std::ifstream in(path);
    if (!in) return false;
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        size_t t1 = line.find('\t');
        size_t t2 = (t1 == std::string::npos) ? std::string::npos : line.find('\t', t1 + 1);
        if (t1 == std::string::npos || t2 == std::string::npos) return false;
        SeqInput s;
        s.group = line.substr(0, t1);
        s.id = line.substr(t1 + 1, t2 - t1 - 1);
        std::istringstream iss(line.substr(t2 + 1));
        int tok = 0;
        while (iss >> tok) s.tokens.push_back(static_cast<llama_token>(tok));
        if (s.tokens.empty()) return false;
        out.push_back(std::move(s));
    }
    return !out.empty();
}

int main(int argc, char ** argv) {
    std::string model_path;
    std::string tsv_path;
    std::string out_path;
    int threads = 4;
    int ngl = 0;
    int n_ubatch = 5120;

    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--model" && i + 1 < argc) model_path = argv[++i];
        else if (a == "--tsv" && i + 1 < argc) tsv_path = argv[++i];
        else if (a == "--out" && i + 1 < argc) out_path = argv[++i];
        else if (a == "--threads" && i + 1 < argc) threads = std::atoi(argv[++i]);
        else if (a == "--ngl" && i + 1 < argc) ngl = std::atoi(argv[++i]);
        else if (a == "--ubatch" && i + 1 < argc) n_ubatch = std::atoi(argv[++i]);
        else {
            std::cerr << "usage: llama_eg2_probe --model <gguf> --tsv <in.tsv> --out <out.json> [--threads 4] [--ngl 0] [--ubatch 5120]\n";
            return 2;
        }
    }
    if (model_path.empty() || tsv_path.empty() || out_path.empty()) {
        std::cerr << "missing required --model, --tsv, or --out\n";
        return 2;
    }

    std::vector<SeqInput> rows;
    if (!load_tsv(tsv_path, rows)) {
        std::cerr << "failed to load TSV inputs from " << tsv_path << "\n";
        return 1;
    }

    // Group contiguous rows with identical group key into one llama_batch (singleton or multi-seq batch).
    std::vector<std::vector<size_t>> batches;
    int max_batch_tokens = 0;
    int max_seqs = 1;
    for (size_t i = 0; i < rows.size(); ++i) {
        if (batches.empty() || rows[batches.back()[0]].group != rows[i].group) {
            batches.push_back({i});
        } else {
            batches.back().push_back(i);
        }
    }
    for (const auto & b : batches) {
        int tot = 0;
        for (size_t idx : b) tot += static_cast<int>(rows[idx].tokens.size());
        if (tot > max_batch_tokens) max_batch_tokens = tot;
        if (static_cast<int>(b.size()) > max_seqs) max_seqs = static_cast<int>(b.size());
    }
    if (n_ubatch < max_batch_tokens) n_ubatch = max_batch_tokens;

    ggml_backend_load_all();
    llama_backend_init();

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = ngl;
    llama_model * model = llama_model_load_from_file(model_path.c_str(), mparams);
    if (!model) {
        std::cerr << "failed to load GGUF model: " << model_path << "\n";
        llama_backend_free();
        return 1;
    }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = static_cast<uint32_t>(n_ubatch);
    cparams.n_batch = static_cast<uint32_t>(n_ubatch);
    cparams.n_ubatch = static_cast<uint32_t>(n_ubatch);
    cparams.n_seq_max = static_cast<uint32_t>(max_seqs);
    cparams.n_threads = threads;
    cparams.n_threads_batch = threads;
    cparams.embeddings = true;
    cparams.pooling_type = LLAMA_POOLING_TYPE_MEAN;
    cparams.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_DISABLED;

    llama_context * ctx = llama_init_from_model(model, cparams);
    if (!ctx) {
        std::cerr << "failed to create llama_context\n";
        llama_model_free(model);
        llama_backend_free();
        return 1;
    }

    const int n_embd = llama_model_n_embd_out(model);
    if (n_embd <= 0) {
        std::cerr << "invalid n_embd_out: " << n_embd << "\n";
        llama_free(ctx);
        llama_model_free(model);
        llama_backend_free();
        return 1;
    }

    llama_batch batch = llama_batch_init(n_ubatch, 0, 1);

    std::ofstream out(out_path);
    if (!out) {
        std::cerr << "failed to open output: " << out_path << "\n";
        llama_batch_free(batch);
        llama_free(ctx);
        llama_model_free(model);
        llama_backend_free();
        return 1;
    }
    out << "{\n  \"rows\": [\n";
    bool first_row = true;

    for (const auto & grp : batches) {
        batch.n_tokens = 0;
        for (size_t s = 0; s < grp.size(); ++s) {
            const auto & seq = rows[grp[s]];
            for (size_t p = 0; p < seq.tokens.size(); ++p) {
                int idx = batch.n_tokens++;
                batch.token[idx] = seq.tokens[p];
                batch.pos[idx] = static_cast<llama_pos>(p);
                batch.n_seq_id[idx] = 1;
                batch.seq_id[idx][0] = static_cast<llama_seq_id>(s);
                batch.logits[idx] = 1;
            }
        }
        if (llama_decode(ctx, batch) != 0) {
            std::cerr << "llama_decode failed on group " << rows[grp[0]].group << "\n";
            llama_batch_free(batch);
            llama_free(ctx);
            llama_model_free(model);
            llama_backend_free();
            return 1;
        }
        for (size_t s = 0; s < grp.size(); ++s) {
            const float * emb = llama_get_embeddings_seq(ctx, static_cast<llama_seq_id>(s));
            if (!emb) {
                std::cerr << "null embeddings for " << rows[grp[s]].id << "\n";
                return 1;
            }
            double ss = 0.0;
            for (int j = 0; j < n_embd; ++j) {
                if (!std::isfinite(emb[j])) {
                    std::cerr << "non-finite embedding element in " << rows[grp[s]].id << "\n";
                    return 1;
                }
                ss += static_cast<double>(emb[j]) * static_cast<double>(emb[j]);
            }
            double norm = std::sqrt(ss);
            if (!(norm > 0.0) || !std::isfinite(norm)) {
                std::cerr << "zero/invalid norm in " << rows[grp[s]].id << "\n";
                return 1;
            }
            if (!first_row) out << ",\n";
            first_row = false;
            out << "    {\"group\": \"" << rows[grp[s]].group << "\", \"id\": \"" << rows[grp[s]].id << "\", \"vector\": [";
            out << std::setprecision(9);
            for (int j = 0; j < n_embd; ++j) {
                if (j > 0) out << ",";
                float v = static_cast<float>(static_cast<double>(emb[j]) / norm);
                out << v;
            }
            out << "]}";
        }
    }
    out << "\n  ]\n}\n";
    out.close();

    llama_batch_free(batch);
    llama_free(ctx);
    llama_model_free(model);
    llama_backend_free();
    return 0;
}
