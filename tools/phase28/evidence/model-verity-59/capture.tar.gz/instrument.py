"""Overlay timing around production Source.runModel and Source.Close."""
import json
from pathlib import Path
import sys

repo = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
overlay = {}
candidate = sys.argv[3] == "head"

def replace(text, old, new):
    if text.count(old) != 1:
        raise ValueError(old)
    return text.replace(old, new)

def install(path, data):
    (out / path.name).write_text(data)
    overlay[str(path)] = str(out / path.name)

path = repo / "internal/semantic/source.go"
source = path.read_text()
source = replace(source, '"context"', '"context"\n"crypto/sha256"\n"encoding/binary"\n"encoding/hex"\n"encoding/json"\n"math"\n"os"')
source = replace(source, '\tcloseMu sync.Mutex', '\tbench verificationBench\n\tcloseMu sync.Mutex')
i, j = source.index("func (s *Source) runModel"), source.index("// runIndexes reads")
model = source[i:j]
model = replace(model, "defer close(s.model)", "defer close(s.model)\n mark := time.Now()")
model = replace(model, "if err != nil || ctx.Err() != nil", "s.bench.Verify = verificationElapsed(mark)\n if err != nil || ctx.Err() != nil")
model = replace(model, "emb, err := s.opt.Registry.Open", "mark = time.Now()\n emb, err := s.opt.Registry.Open")
model = replace(model, "\n\tif err != nil {\n\t\treturn\n\t}\n\ts.emb = emb", "\n s.bench.Open = verificationElapsed(mark)\n if err != nil {return}\n s.emb = emb")
model = replace(model, "vs, err := emb.Embed", "mark = time.Now()\n vs, err := emb.Embed")
model = replace(model, "if err != nil || len(vs) != 1", "s.bench.Embed = verificationElapsed(mark)\n if err != nil || len(vs) != 1")
source = source[:i] + model + source[j:]
source = replace(source, """	if s.emb != nil {
		_ = s.emb.Close()
		s.emb = nil
	}
}""", """	if s.emb != nil {
		mark := time.Now()
		_ = s.emb.Close()
		s.bench.Close = verificationElapsed(mark)
		s.emb = nil
	}
    s.writeVerificationBench()
}""")
source += '''
type verificationBench struct {
    Verify, Open, Embed, Close float64
    Hits int64
    QuerySHA256 string
}

func verificationElapsed(t time.Time) float64 {
    return float64(time.Since(t))/float64(time.Millisecond)
}

func (s *Source) writeVerificationBench() {
    path := os.Getenv("PBRAIN_BENCH_VERITY_RECORD")
    if path == "" { return }
    s.bench.Hits = ''' + ("embed.BenchmarkVerityHits()" if candidate else "0") + '''
    if len(s.query) > 0 {
        var data []byte
        for _, v := range s.query {
            data = binary.LittleEndian.AppendUint32(data, math.Float32bits(v))
        }
        sum := sha256.Sum256(data)
        s.bench.QuerySHA256 = hex.EncodeToString(sum[:])
    }
    report, err := json.Marshal(s.bench)
    if err != nil {panic(err)}
    if err := os.WriteFile(path, append(report, '\\n'), 0600); err != nil {panic(err)}
}
'''
install(path, source)
if candidate:
    path = repo / "internal/embed/embed.go"
    data = path.read_text()
    data = replace(data, '"sync"', '"sync"\n"sync/atomic"')
    data = replace(data, 'sealed = true', 'sealed = true\n if mode == ManagedSearch { benchmarkVerityHits.Add(1) }')
    data += "\nvar benchmarkVerityHits atomic.Int64\nfunc BenchmarkVerityHits() int64 { return benchmarkVerityHits.Load() }\n"
    install(path, data)

(out / "overlay.json").write_text(json.dumps({"Replace": overlay}, indent=2) + "\n")
