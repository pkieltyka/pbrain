"""Compare the production search path on d8384b1, sealed HEAD and unsealed HEAD."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import struct
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
models = {
    "bge": ("bge-small-en-v1.5", Path("/var/tmp/pbrain-phase28-bge-pax-fresh.rCsjGe/bge-model"),
            "bge.test", "BenchmarkBgeFirstQuery", "which conditions are needed to rebuild the index"),
    "google": ("embeddinggemma-2", Path("/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack"),
               "gemma2.test", "BenchmarkGemmaFirstQuery", "where is login state kept"),
    "q8": ("embeddinggemma-2-q8-0", Path("/var/tmp/pbrain-sync-trace.NSKyVs/q8-model"),
           "gemma2.test", "BenchmarkGemmaQ8FirstQuery", "where is login state kept"),
}


def preflight():
    while True:
        first = sample_cpu()
        time.sleep(5)
        second = sample_cpu()
        busy_pct = 100 * (second[1] - first[1]) / (second[0] - first[0])
        gpu = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip()
        row = {"at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "loadavg": Path("/proc/loadavg").read_text().strip(), "host_busy_pct": busy_pct, "gpu_processes": gpu}
        yield row


def sample_cpu():
    cpu = [int(x) for x in Path("/proc/stat").read_text().splitlines()[0].split()[1:9]]
    return sum(cpu), sum(cpu) - cpu[3] - cpu[4]


def require_quiet(out):
    clean = 0
    with out.open("w") as f:
        for i, row in enumerate(preflight()):
            print(json.dumps(row), file=f, flush=True)
            clean = clean + 1 if row["host_busy_pct"] <= 4 and not row["gpu_processes"] else 0
            if clean == 2:
                return
            if i >= 59:
                raise RuntimeError("machine stayed busy for five minutes")


def meta(model, rows):
    fingerprint = hashlib.sha256()
    for filename, _, digest, _ in rows:
        name = filename.encode()
        fingerprint.update(struct.pack("<Q", len(name)) + name + bytes.fromhex(digest))
    return model + "-" + fingerprint.hexdigest()[:16]


env = {**os.environ, "GOMAXPROCS": "4", "PBRAIN_ALLOW_GEMMA2": "1",
       "PBRAIN_TEST_BGE_MODEL": str(models["bge"][1]),
       "PBRAIN_TEST_GEMMA2_PACK": str(models["google"][1]),
       "PBRAIN_TEST_GEMMA2_Q8": str(models["q8"][1]),
       "CUDA_VISIBLE_DEVICES": "", "TZ": "UTC", "LC_ALL": "C",
       "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_NOSYSTEM": "1"}
for k in ("PBRAIN_TRACE", "PBRAIN_DIR", "PBRAIN_BRAIN", "PBRAIN_GPU_MEMORY", "PBRAIN_DEVICE",
          "PBRAIN_BENCH_VERITY_RECORD", "GOGC", "GOMEMLIMIT", "GODEBUG"):
    env.pop(k, None)


def run(binary, args, project, cache, label, record=None):
    run_env = {**env, "PBRAIN_CACHE": str(cache)}
    if record is not None:
        run_env["PBRAIN_BENCH_VERITY_RECORD"] = str(record)
    cmd = ["timeout", "-k", "5s", "60s", "taskset", "-c", "0-3", binary, *args]
    started = time.monotonic()
    p = subprocess.run(cmd, cwd=project, env=run_env, capture_output=True, check=False)
    wall = (time.monotonic() - started) * 1000
    with label.with_suffix(".stdout").open("wb") as f:
        f.write(p.stdout)
    with label.with_suffix(".stderr").open("wb") as f:
        f.write(p.stderr)
    if p.returncode:
        raise RuntimeError(f"{cmd}: exit {p.returncode}: {p.stderr.decode(errors='replace')}")
    return wall, p.stdout, p.stderr


def prime(d, names):
    for name in names:
        with (d / name).open("rb") as f:
            while f.read(8 << 20):
                pass


def evaluate(arm, out):
    model, weights, test, bench, query = models[arm]
    rows = [l.split("\t") for l in (root / (arm + ".tsv")).read_text().splitlines()]
    name = meta(model, rows)
    row_root = out / arm
    row_root.mkdir()
    require_quiet(row_root / "preflight.jsonl")
    project = row_root / "project"
    project.mkdir()
    base = root / "pbrain-base"
    head = root / "pbrain-head"
    caches = {mode: row_root / mode for mode in ("strict-cache", "sealed-cache")}
    for cache in caches.values():
        models_dir = cache / "models" / name
        models_dir.mkdir(parents=True)
        for filename, size, _, _ in rows:
            target = models_dir / filename
            subprocess.run(["cp", "--reflink=auto", weights / filename, target], check=True)
            assert target.stat().st_size == int(size)
    run(base, ["init"], project, caches["strict-cache"], row_root / "init")
    brain = project / "docs/brain"
    (brain / "pbrain.toml").write_text(f'[semantic]\nmodel = "{model}"\n')
    (brain / "notes").mkdir(exist_ok=True)
    for i, title, body in [
        (1, "Login state", "This project keeps login state in its session cookie. Clear the cookie to reset the login."),
        (2, "Rebuilding the index", "Rebuild the index when notes are added or changed. Sync updates the index."),
    ]:
        note = f"---\nkind: note\ntitle: {title}\ncreated: 2026-11-01T00:00:00Z\nauthor: agent:benchmark\n---\n\n{body}\n"
        (brain / "notes" / f"20261101-000000-note-{i:04d}.md").write_text(note)
    run(base, ["sync", "--device", "cpu", "--json"], project, caches["strict-cache"], row_root / "provision-strict")
    run(head, ["sync", "--device", "cpu", "--json"], project, caches["sealed-cache"], row_root / "provision-sealed")
    for cache in caches.values():
        prime(cache / "models" / name, [f[0] for f in rows])
    actual = {"baseline": (base, caches["strict-cache"]), "sealed": (head, caches["sealed-cache"]),
              "unsealed": (head, caches["strict-cache"])}
    measured = {}
    reference = None
    names = tuple(actual)
    with (row_root / "samples.jsonl").open("w") as log:
        for trial in range(5):
            for mode in names[trial % 3:] + names[:trial % 3]:
                binary, cache = actual[mode]
                label = row_root / f"{trial + 1}-{mode}"
                record = label.with_suffix(".json")
                wall, stdout, stderr = run(binary, ["search", "--semantic", "--json", query], project, cache, label, record)
                row = json.loads(record.read_text())
                json.loads(stdout)
                hits = len(rows) if mode == "sealed" else 0
                assert row["Hits"] == hits, (mode, row)
                assert row["QuerySHA256"] and row["Embed"] > 0 and row["Open"] > 0
                check = row["QuerySHA256"], stdout, stderr
                if reference is None:
                    reference = check
                assert reference == check, (arm, mode, trial)
                row["rule3_ms"] = sum(row[k] for k in ("Verify", "Open", "Embed", "Close"))
                row.update(arm=arm, mode=mode, trial=trial + 1, wall_ms=wall,
                           loadavg=Path("/proc/loadavg").read_text().strip())
                measured.setdefault(mode, []).append(row)
                print(json.dumps(row), file=log, flush=True)
                print(arm, mode, trial+1, f'{row["rule3_ms"]:.1f} ms', flush=True)
            label = row_root / f"{trial + 1}-raw"
            _, stdout, _ = run(root / test, ["-test.run", "^$", "-test.bench", "^"+bench+"$",
               "-test.benchtime", "1x", "-test.count", "1"], project, caches["strict-cache"], label)
            ns = re.search(rb"\s+(\d+) ns/op", stdout)
            assert ns is not None, stdout
            ms = int(ns.group(1)) / 1e6
            measured.setdefault("raw_verify", []).append({"rule3_ms": ms})
            print(json.dumps({"arm": arm, "mode": "raw_verify", "trial": trial + 1, "rule3_ms": ms}), file=log, flush=True)

    for mode, timing in measured.items():
        values = [r["rule3_ms"] for r in timing]
        result = {"ms": values, "median": statistics.median(values), "range": [min(values), max(values)]}
        if mode != "raw_verify":
            result.update(model_verify_median=statistics.median(r["Verify"] for r in timing),
                          wall_median=statistics.median(r["wall_ms"] for r in timing),
                          verity_hits=[r["Hits"] for r in timing])
        print(json.dumps({"arm": arm, "mode": mode, **result}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("out", type=Path)
    parser.add_argument("arms", nargs="*", default=list(models), choices=tuple(models))
    opts = parser.parse_args()
    opts.out.mkdir()
    for arm in opts.arms:
        evaluate(arm, opts.out)
