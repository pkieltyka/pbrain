#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
export PBRAIN_EVAL_OUTPUT="$scratch/evidence"
export PBRAIN_EVAL_TEST_BIN_DIR="$scratch/tests-eval"
export PBRAIN_EVAL_SAME_FILE=1
export PYTHONUNBUFFERED=1
export GOWORK=off CGO_ENABLED=0 GOMAXPROCS=4
unset GOFLAGS
mkdir -p "$PBRAIN_EVAL_TEST_BIN_DIR" "$scratch/eval-bin" "$PBRAIN_EVAL_OUTPUT"

cd "$scratch/eval-source"
python3 -c 'import json, sys; json.dump({"Replace": {sys.argv[1]: sys.argv[2]}}, sys.stdout)' \
    "$PWD/internal/embed/gemma2/gemma_eval_test.go" "$scratch/gemma_eval_test.go" > "$scratch/overlay.json"
if [[ ! -f $scratch/built ]]; then
    for device in cpu cuda; do
        tags=()
        if [[ $device == cuda ]]; then
            tags=(-tags cuda)
        fi
        taskset -c 16-31 go test -p 2 -trimpath -c -overlay="$scratch/overlay.json" \
            "${tags[@]}" -o "$PBRAIN_EVAL_TEST_BIN_DIR/gemma2-$device.test" ./internal/embed/gemma2
        taskset -c 16-31 go build -p 2 -trimpath -ldflags='-s -w' "${tags[@]}" \
            -o "$scratch/eval-bin/pbrain-$device" ./cmd/pbrain
    done
    go version -m "$PBRAIN_EVAL_TEST_BIN_DIR/"*.test > "$PBRAIN_EVAL_OUTPUT/test-build-info.log"
    sha256sum "$PBRAIN_EVAL_TEST_BIN_DIR/"*.test > "$PBRAIN_EVAL_OUTPUT/test-binaries.sha256"
    git -C /home/peter/Dev/pkieltyka/pbrain.worktrees/peter-lead-dev show "$(cat "$scratch/pin-commit"):go.mod" | cmp go.mod
    git -C /home/peter/Dev/pkieltyka/pbrain.worktrees/peter-lead-dev show "$(cat "$scratch/pin-commit"):go.sum" | cmp go.sum
    touch "$scratch/built"
fi
phase=${1:-run}
if [[ $phase == build ]]; then
    exit 0
fi

llama="$HOME/goinfer-logs/eg2-gguf-q8-q6/llama-8d60873df-cpu"
sha256sum -c "$llama/probe.sha256" > "$PBRAIN_EVAL_OUTPUT/reference-binary-check.log"
cd "$scratch"
if [[ ! -f $scratch/timing-complete ]]; then
    for arm in b-control c d; do
        python3 "$scratch/evaluate.py" prepare "$arm"
    done
    for trial in {1..5}; do
        for arm in b-control c d; do
            python3 "$scratch/evaluate.py" tests "$arm" cpu BenchmarkGemmaEvalFirstQuery --first "$trial"
        done
    done
    touch "$scratch/timing-complete"
fi
if [[ $phase == timing ]]; then
    exit 0
fi
if [[ ! -f $scratch/cpu-complete ]]; then
    for arm in c d; do
        python3 "$scratch/evaluate.py" tests "$arm" cpu TestGemmaEvalVectors
    done
    touch "$scratch/cpu-complete"
fi
if [[ $phase == cpu ]]; then
    exit 0
fi
for arm in c d; do
    python3 "$scratch/evaluate.py" tests "$arm" cuda TestGemmaEvalVectors
    python3 "$scratch/quality.py" reference "$arm"
done
touch "$PBRAIN_EVAL_OUTPUT/complete"
