"""Summarize the rerun of the first-query and same-file benchmarks."""
import json
import re
import statistics
import sys
from pathlib import Path

evidence = Path(sys.argv[1])
records = (json.loads(line) for line in (evidence / "timing.jsonl").read_text().splitlines())
perf = {}
for row in records:
    if "BenchmarkGemmaEvalFirstQuery" not in row["case"]:
        continue
    assert row["exit"] == 0 and row["device"] == "cpu"
    out = (evidence / row["case"] / "stdout").read_text()
    matches = re.findall(r"^BenchmarkGemmaEvalFirstQuery-4\s+1\s+(\d+(?:\.\d+)?) ns/op", out, re.M)
    assert len(matches) == 1, (row["case"], out)
    series = perf.setdefault(row["model"], {"samples_ms": [], "peak_host_mib": 0.0, "max_host_busy_pct": 0.0})
    series["samples_ms"].append(float(matches[0]) / 1e6)
    series["peak_host_mib"] = max(series["peak_host_mib"], row["host_peak_rss_kib"] / 1024)
    series["max_host_busy_pct"] = max(series["max_host_busy_pct"], row["preflight_host_busy_pct"])
for record in perf.values():
    values = record["samples_ms"]
    assert len(values) == 5
    record.update(min_ms=min(values), median_ms=statistics.median(values),
                  max_ms=max(values), samples_under_600=sum(v < 600 for v in values))

parity_file = evidence / "rule2-summary.jsonl"
parity = [json.loads(line) for line in parity_file.read_text().splitlines()] if parity_file.is_file() else []
if parity:
    assert len(parity) == 4
    assert all(r["texts"] == 81 and r["pairs"] == 162 for r in parity)
print(json.dumps({"first_query": perf, "rule2": parity}, indent=2, sort_keys=True))
