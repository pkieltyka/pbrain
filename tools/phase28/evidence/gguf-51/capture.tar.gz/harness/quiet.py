"""Confirm two quiet host and NVIDIA samples before a timed run."""
import argparse
import json
from pathlib import Path
import subprocess
import time


def counters():
    fields = [int(x) for x in Path("/proc/stat").read_text().splitlines()[0].split()[1:9]]
    return sum(fields), fields[3] + fields[4]


parser = argparse.ArgumentParser()
parser.add_argument("--max-busy-pct", type=float, default=4.0)
parser.add_argument("--attempts", type=int, default=9)
args = parser.parse_args()
consecutive = 0
for _ in range(args.attempts):
    total, idle = counters()
    time.sleep(5)
    after, free = counters()
    busy_pct = 100 * (1 - (free - idle) / (after - total))
    compute = subprocess.check_output(
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True
    ).strip()
    record = {"host_busy_pct": busy_pct, "nvidia_compute": compute,
              "loadavg": Path("/proc/loadavg").read_text().strip()}
    print(json.dumps(record), flush=True)
    consecutive = consecutive + 1 if busy_pct <= args.max_busy_pct and not compute else 0
    if consecutive == 2:
        break
else:
    raise SystemExit("desktop stayed busy")
