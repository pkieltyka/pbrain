"""Run the frozen release gates for the Q8 row on one index backend."""
import json
import sys
from pathlib import Path
from evaluate import evidence, measure, registry, repo

device = sys.argv[1]
assert device in ("cuda", "cpu")
model, pack, binaries = registry["c"]
case = f"q8-{device}-frozen-retrieval"
args = ["-stage", "check", "-model", model, "-model-path", str(pack),
        str(repo / "internal/semantic/calibrate/testdata/retrieval")]
sample, stdout = measure(case, "c", device, binaries / f"calibrate-{device}", args, repo, ok=(0, 1))
report = json.loads(stdout)
gate = report["model"]
assert gate["cutoff"] == .72 and len(report["expected_ranks"]) == 47
assert report["held_out_release_check"] and report["shared_output_stable_with_personal"]
counts = {name: sum(0 < rank <= end for rank in report["expected_ranks"])
          for name, end in [("first", 1), ("top_three", 3)]}
print(json.dumps({"device": device, "counts": counts, "gate": gate, "exit": sample["exit"]}))
assert sample["exit"] == 0 and gate["semantic_gate"]["pass"] and gate["combined_abstention_gate"]["pass"]
lines = (evidence / case / "stderr").read_text().splitlines()
index_device = "cuda:0" if device == "cuda" else "cpu"
sections = [part for line in lines if line.startswith("{")
            for part in json.loads(line).get("sections", []) if part["passages_embedded"] > 0]
assert sections and all(s["device"] == index_device for s in sections), sections
