#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
model=$(cat "$scratch/model-root")/q8
out="$scratch/evidence/provision"
mkdir -p "$out"
export PBRAIN_ALLOW_GEMMA2=1 GOMAXPROCS=4 CUDA_VISIBLE_DEVICES=""
unset PBRAIN_DEVICE PBRAIN_GPU_MEMORY PBRAIN_BRAIN PBRAIN_DIR
name=embeddinggemma-2-q8-0
file=embeddinggemma-2-Q8_0.gguf
folder=embeddinggemma-2-q8-0-49b6c94be1aac068
digest=6f1bd4ac6c5df7444f9cca7ca36cafe6cfa34cd6f49fefb1e0b4be8143aed8bc

if (( $# == 0 )); then set -- offline download auto; fi
for mode do
    binary="$scratch/eval-bin/pbrain-cpu"
    selector=cpu
    expected_device=cpu
    export CUDA_VISIBLE_DEVICES=""
    case "$mode" in
        offline|download) ;;
        auto)
            binary="$scratch/eval-bin/pbrain-cuda"
            selector=auto
            expected_device=cuda:0
            export LD_LIBRARY_PATH=/run/opengl-driver/lib
            CUDA_VISIBLE_DEVICES=$(nvidia-smi -i 0 --query-gpu=uuid --format=csv,noheader)
            export CUDA_VISIBLE_DEVICES
            ;;
        *) exit 2 ;;
    esac
    case_dir="$out/$mode"
    brain="$scratch/provision-$mode/docs/brain"
    mkdir "$case_dir"
    mkdir -p "$brain/notes"
    printf 'semantic.model = "%s"\n' "$name" > "$brain/pbrain.toml"
    if [[ $mode != download ]]; then
        printf 'model_path = "%s"\n' "$model" > "$brain/personal.toml"
    fi
    cat > "$brain/notes/session-storage.md" <<'NOTE'
---
kind: note
title: Session storage
created: 2026-01-01T00:00:00Z
author: agent:test
---

Authenticated sessions persist in Redis under their session keys.
NOTE
    export PBRAIN_CACHE="$scratch/provision-$mode-cache"
    python3 "$scratch/quiet.py" --max-busy-pct 5 --attempts 24 > "$case_dir/quiet.jsonl"
    timeout 400s taskset -c 0-3 "$binary" --brain "$brain" sync --device "$selector" --json \
        > "$case_dir/sync.json" 2> "$case_dir/sync.stderr"
    jq -e --arg name "$name" --arg device "$expected_device" '.model == $name and (.sections | length == 1) and
        (.sections[0] | .device == $device and .items == 1 and .passages_embedded == 1)' "$case_dir/sync.json"
    if [[ $mode == download ]]; then
        jq -se 'any(.[]; .notice.code == "model_download" and (.notice.message | contains("310 MB")))' "$case_dir/sync.stderr"
        printf '%s  %s\n' "$digest" "$PBRAIN_CACHE/models/$folder/$file" | sha256sum -c | tee "$case_dir/checksum.log"
        [[ $(find "$PBRAIN_CACHE/models/$folder" -maxdepth 1 -type f | wc -l) == 1 ]]
    else
        jq -se 'all(.[]; .notice.code != "model_download")' "$case_dir/sync.stderr"
        [[ ! -e "$PBRAIN_CACHE/models/$folder" ]]
    fi
    timeout 40s taskset -c 0-3 "$binary" --brain "$brain" sync --status --json > "$case_dir/status.json"
    jq -e --arg name "$name" '.model == $name and .model_present and .sections[0].indexed == 1' "$case_dir/status.json"
    timeout 40s taskset -c 0-3 "$binary" --brain "$brain" search "where is login state kept" --semantic --json \
        > "$case_dir/search.json" 2> "$case_dir/search.stderr"
    jq -e 'any(.results[]; .id == "session-storage" and .semantic)' "$case_dir/search.json"
    [[ ! -s "$case_dir/search.stderr" ]]
done
