"""Summarize the actual release candidate's Q8 registration gates."""
import json
import re
import statistics
import sys
from pathlib import Path

evidence = Path(sys.argv[1])
timing = [json.loads(line) for line in (evidence / "timing.jsonl").read_text().splitlines()]
bench = [row for row in timing if "BenchmarkGemmaQ8FirstQuery" in row["case"]]
assert len(bench) == 5 and all(row["device"] == "cpu" and row["exit"] == 0 for row in bench)
values = []
for row in bench:
    output = (evidence / row["case"] / "stdout").read_text()
    matches = re.findall(r"^BenchmarkGemmaQ8FirstQuery-4\s+1\s+(\d+) ns/op", output, re.M)
    assert len(matches) == 1
    values.append(int(matches[0]) / 1e6)

same_file = [json.loads(line) for line in (evidence / "rule2-summary.jsonl").read_text().splitlines()]
assert len(same_file) == 2 and all(row["pass"] and row["pairs"] == 162 for row in same_file)
cpu_cuda = json.loads((evidence / "cpu-cuda.json").read_text())
assert cpu_cuda["passages"] == 59 and min(cpu_cuda["minimum_cosines"].values()) >= .999

layouts = (evidence / "c-cuda-TestGemmaQ8CUDAByteLayouts-1/stdout").read_text()
assert layouts.count("all 59 vectors match the singleton bits") == 3 and "--- PASS:" in layouts
result = {
    "commit": (evidence / "pbrain-commit").read_text().strip(),
    "cpu_first_query": {
        "samples_ms": values,
        "median_ms": statistics.median(values),
        "range_ms": [min(values), max(values)],
        "worst_margin_ms": 600 - max(values),
        "under_600": sum(v < 600 for v in values),
        "peak_rss_mib": max(row["host_peak_rss_kib"] for row in bench) / 1024,
    },
    "same_file": same_file,
    "cpu_cuda": cpu_cuda,
    "cuda_layouts": {"passages": 59, "layouts_matching_singletons": 3},
}
checks = []
for device in ("cpu", "cuda"):
    path = evidence / f"{device}-retrieval-summary.json"
    if path.is_file() and path.stat().st_size > 0:
        row = json.loads(path.read_text())
        assert row["device"] == device and row["exit"] == 0
        checks.append(row)
result["retrieval"] = checks
provision = {}
for mode in ("offline", "auto", "download"):
    work = evidence / "provision" / mode
    if (work / "search.json").is_file():
        provision[mode] = {
            "sync": json.loads((work / "sync.json").read_text()),
            "status": json.loads((work / "status.json").read_text()),
            "semantic_hits": [r["id"] for r in json.loads((work / "search.json").read_text())["results"] if r.get("semantic")],
        }
result["provision"] = provision
print(json.dumps(result, indent=2, sort_keys=True))
