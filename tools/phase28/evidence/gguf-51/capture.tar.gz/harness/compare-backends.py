"""Compare the same prepared Q8 passages across the qualified backends."""
import json
from quality import cosine, vectors

cpu, cuda = (vectors("c", device) for device in ("cpu", "cuda"))
assert cpu.keys() == cuda.keys()
passages = [key for key in cpu if key.startswith("small/")]
assert len(passages) == 59
for key in cpu:
    assert cpu[key]["ids"] == cuda[key]["ids"], key
minima = {
    dim: min(cosine(cpu[key]["vector"], cuda[key]["vector"], dim) for key in passages)
    for dim in (512, 768)
}
assert min(minima.values()) >= .999
print(json.dumps({"passages": len(passages), "minimum_cosines": minima}))
