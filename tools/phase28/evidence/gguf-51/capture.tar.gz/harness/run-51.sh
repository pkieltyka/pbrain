#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
repo=$(realpath "$scratch/eval-source")
export PBRAIN_EVAL_OUTPUT="$scratch/evidence"
export PBRAIN_EVAL_TEST_BIN_DIR="$scratch/tests-eval"
export PBRAIN_EVAL_SAME_FILE=1 PYTHONUNBUFFERED=1
export CGO_ENABLED=0 GOMAXPROCS=4
unset GOFLAGS
mkdir -p "$PBRAIN_EVAL_OUTPUT" "$PBRAIN_EVAL_TEST_BIN_DIR" "$scratch/eval-bin"
cd "$repo"

phase=${1:-run}
if [[ $phase == build ]]; then
    git status --short
    [[ -z $(git status --porcelain) ]]
    git rev-parse HEAD > "$PBRAIN_EVAL_OUTPUT/pbrain-commit"
    python3 -c 'import json,sys; print(json.dumps({"Replace":{sys.argv[1]:sys.argv[2]}}))' \
        "$PWD/internal/embed/gemma2/gemma_eval_test.go" "$scratch/gemma_eval_test.go" > "$scratch/overlay.json"
    python3 "$scratch/calibrate-overlay.py" "$PWD/internal/semantic/calibrate" > "$scratch/calibrate-overlay.json"
    for device in cpu cuda; do
        tags=()
        if [[ $device == cuda ]]; then tags=(-tags cuda); fi
        taskset -c 4-7 go test -p 2 -trimpath -c "${tags[@]}" -overlay="$scratch/overlay.json" \
            -o "$PBRAIN_EVAL_TEST_BIN_DIR/gemma2-$device.test" ./internal/embed/gemma2
        taskset -c 4-7 go build -p 2 -trimpath "${tags[@]}" -o "$scratch/eval-bin/pbrain-$device" ./cmd/pbrain
        taskset -c 4-7 go build -p 2 -trimpath "${tags[@]}" -overlay="$scratch/calibrate-overlay.json" \
            -o "$scratch/eval-bin/calibrate-$device" ./internal/semantic/calibrate
    done
    go version -m "$PBRAIN_EVAL_TEST_BIN_DIR/"*.test "$scratch/eval-bin/"* > "$PBRAIN_EVAL_OUTPUT/build-info.log"
    sha256sum "$PBRAIN_EVAL_TEST_BIN_DIR/"*.test "$scratch/eval-bin/"* > "$PBRAIN_EVAL_OUTPUT/binary-sha256"
    exit
fi

[[ $(git rev-parse HEAD) == "$(cat "$PBRAIN_EVAL_OUTPUT/pbrain-commit")" ]]
if [[ $phase == parity ]]; then
    python3 "$scratch/quiet.py" --max-busy-pct 5 --attempts 24 > "$PBRAIN_EVAL_OUTPUT/parity-quiet.jsonl"
    {
        date --iso-8601=seconds
        uname -a
        lscpu | rg 'Model name:|Core\(s\) per socket:|Thread\(s\) per core:'
        rg '^MemTotal' /proc/meminfo
        nvidia-smi --query-gpu=uuid,name,driver_version,memory.total --format=csv
        cat /proc/loadavg
        go version
    } > "$PBRAIN_EVAL_OUTPUT/host.log"
    llama="$HOME/goinfer-logs/eg2-gguf-q8-q6/llama-8d60873df-cpu"
    sha256sum -c "$llama/probe.sha256" > "$PBRAIN_EVAL_OUTPUT/reference-binary-check.log"
    sha256sum internal/semantic/calibrate/testdata/retrieval/questions.json \
        tools/phase28/evidence/gemma-pax-22/fixture-paths.txt > "$PBRAIN_EVAL_OUTPUT/fixture-sha256"
    cd "$scratch"
    python3 evaluate.py prepare c
    timeout 130s python3 evaluate.py tests c cpu TestGemmaQ8Preparation
    timeout 300s python3 evaluate.py tests c cpu BenchmarkGemmaQ8FirstQuery --count 5
    timeout 130s python3 evaluate.py tests c cuda TestGemmaQ8CUDAByteLayouts
    timeout 150s python3 evaluate.py tests c cpu TestGemmaEvalVectors
    timeout 150s python3 evaluate.py tests c cuda TestGemmaEvalVectors
    timeout 180s python3 quality.py reference c
    python3 compare-backends.py > "$PBRAIN_EVAL_OUTPUT/cpu-cuda.json"
    jq -se 'length == 2 and all(.[]; .pass and .pairs == 162)' "$PBRAIN_EVAL_OUTPUT/rule2-summary.jsonl"
    touch "$PBRAIN_EVAL_OUTPUT/parity-complete"
elif [[ $phase == retrieval ]]; then
    cd "$scratch"
    for device in cpu cuda; do
        timeout 550s python3 calibrate-check.py "$device" | tee "$PBRAIN_EVAL_OUTPUT/$device-retrieval-summary.json"
    done
    touch "$PBRAIN_EVAL_OUTPUT/retrieval-complete"
else
    printf 'Unknown phase %s\n' "$phase" >&2
    exit 2
fi
