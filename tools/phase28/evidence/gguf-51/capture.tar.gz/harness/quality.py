"""Same-file reference and dense/product overlap for the Gemma evaluation."""
import argparse
import json
import math
from pathlib import Path
import statistics
import struct

from evaluate import append, evidence, measure, registry, rows, sha256


def jsonlines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def cosine(left, right, n=768):
    assert len(left) == len(right) == 768
    x, y = left[:n], right[:n]
    result = math.fsum(a * b for a, b in zip(x, y, strict=True))
    result /= math.sqrt(math.fsum(a * a for a in x) * math.fsum(b * b for b in y))
    if not math.isfinite(result):
        raise ValueError("non-finite cosine")
    return min(result, 1.0)


def vectors(arm, device):
    log = evidence / f"{arm}-{device}-TestGemmaEvalVectors-1/vectors.jsonl"
    dump = jsonlines(log)
    assert len(dump) in (81, 107, 129)
    return {row["key"]: row for row in dump}


def reference(arm):
    _, pack, _ = registry[arm]
    gguf, = pack.glob("*.gguf")
    prefixes = ("reference/", "small/")
    cpu = {key: row for key, row in vectors(arm, "cpu").items() if key.startswith(prefixes)}
    cuda = {key: row for key, row in vectors(arm, "cuda").items() if key.startswith(prefixes)}
    assert cpu.keys() == cuda.keys() and len(cpu) in (22, 81)
    out = evidence / f"{arm}-reference"
    out.mkdir()
    tsv = out / "prepared.tsv"
    with tsv.open("x") as handle:
        for key, row in cpu.items():
            assert row["ids"] == cuda[key]["ids"]
            ids = " ".join(map(str, row["ids"]))
            handle.write(f"{key}\t{key}\t{ids}\n")
    build = Path("/home/peter/goinfer-logs/eg2-gguf-q8-q6/llama-8d60873df-cpu")
    probe = build / "llama_eg2_probe"
    (out / "provenance.json").write_text(json.dumps({
        "llama_info": (build / "revision.txt").read_text(),
        "probe_sha256": sha256(probe),
        "gguf_sha256": sha256(gguf),
        "prepared_tsv_sha256": sha256(tsv),
    }, indent=2) + "\n")
    reference_file = out / "reference.json"
    measure(f"{arm}-reference", arm, "cpu", probe,
            ["--model", str(gguf), "--tsv", str(tsv), "--out", str(reference_file), "--threads", "4", "--ngl", "0"], out)
    ref = {row["id"]: row["vector"] for row in json.loads(reference_file.read_text())["rows"]}
    assert ref.keys() == cpu.keys()
    for device, arm_rows in (("cpu", cpu), ("cuda", cuda)):
        results = []
        for key, row in arm_rows.items():
            for n in (512, 768):
                result = {"id": key, "dimensions": n, "cosine": cosine(row["vector"], ref[key], n)}
                append(out / f"{device}-cosines.jsonl", result)
                results.append(result)
        worst = min(results, key=lambda value: value["cosine"])
        by_shape = {
            name: {str(n): min(row["cosine"] for row in results if row["dimensions"] == n and row["id"].startswith(name))
                   for n in (512, 768)}
            for name in prefixes if any(row["id"].startswith(name) for row in results)
        }
        append(evidence / "rule2-summary.jsonl", {
            "arm": arm, "device": device, "texts": len(arm_rows), "pairs": len(results),
            "worst": worst, "min_by_shape_and_dimension": by_shape,
            "below_0_999": sum(row["cosine"] < 0.999 for row in results), "pass": worst["cosine"] >= 0.999,
        })


def dense(arm, device):
    brain = evidence / f"{arm}-{device}-sync-small-1/corpus/docs/brain"
    _, passages = rows(brain)
    data = [(Path(row[0]).stem, struct.unpack("<768f", row[-1])) for row in passages]
    ranking = {}
    for name, q in vectors(arm, "cpu").items():
        if not name.startswith("query/"):
            continue
        rank = {}
        for key, v in data:
            sim = cosine(v, q["vector"])
            rank[key] = max(sim, rank.get(key, -math.inf))
        assert len(rank) == 32
        ranking[name.removeprefix("query/")] = sorted(rank, key=lambda ident: (-rank[ident], ident))[:10]
    return ranking


def outcomes(page):
    expected = set(page["expected"])
    seen = page["default_ids"]
    return {"first": bool(set(seen[:1]) & expected),
            "top3": bool(set(seen[:3]) & expected),
            "first_page": bool(set(seen) & expected)}


def product(report):
    model = json.loads(report.read_text())
    return model, {row["query_id"]: row for row in model["product_rankings"]}


def overlap(left, right, device, before, after):
    left_model, x = product(before)
    right_model, y = product(after)
    assert x.keys() == y.keys() and len(x) == 77
    lx, ly = [dense(arm, device) for arm in (left, right)]
    sums = {arm: {"negatives_empty": 0, "first": 0, "top3": 0, "first_page": 0} for arm in (left, right)}
    samples = []
    for key, a in x.items():
        b = y[key]
        assert a.get("expected") == b.get("expected")
        row = {"id": key, "split": "answerable" if a.get("expected") else "held-out"}
        if row["split"] == "answerable":
            for arm, page in ((left, a), (right, b)):
                got = outcomes(page)
                row[arm] = got
                for name, found in got.items():
                    sums[arm][name] += found
        else:
            for arm, page in ((left, a), (right, b)):
                empty = not page["default_ids"]
                row[arm] = {"empty": empty}
                sums[arm]["negatives_empty"] += empty
        p, q = set(a["top_ten_ids"]), set(b["top_ten_ids"])
        row.update({"left_top10": a["top_ten_ids"], "right_top10": b["top_ten_ids"],
                    "product_intersection": len(p & q),
                    "product_jaccard": len(p & q) / len(p | q) if p | q else None,
                    "left_dense": lx[key], "right_dense": ly[key],
                    "dense_overlap": len(set(lx[key]) & set(ly[key])) / 10})
        samples.append(row)
        append(evidence / f"quality-{left}-{right}-{device}.jsonl", row)
    stats = {}
    for split in ("answerable", "held-out"):
        group = [row for row in samples if row["split"] == split]
        jaccards = [row["product_jaccard"] for row in group if row["product_jaccard"] is not None]
        stats[split] = {"count": len(group), "mean_dense_overlap": statistics.mean(row["dense_overlap"] for row in group),
                        "mean_product_jaccard": statistics.mean(jaccards) if jaccards else None,
                        "both_empty": len(group) - len(jaccards), "changed": [row["id"] for row in group if row[left] != row[right]]}
    print(json.dumps({"control": left, "candidate": right,
                      "before": left_model["model"], "after": right_model["model"],
                      "outcomes": sums, "paired_overlap": stats}, indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    one = sub.add_parser("reference")
    one.add_argument("arm", choices=("c", "d"))
    paired = sub.add_parser("overlap")
    paired.add_argument("before", choices=registry)
    paired.add_argument("after", choices=registry)
    paired.add_argument("device", choices=("cpu", "cuda"))
    paired.add_argument("before_report", type=Path)
    paired.add_argument("after_report", type=Path)
    args = p.parse_args()
    if args.cmd == "reference":
        reference(args.arm)
    else:
        overlap(args.before, args.after, args.device, args.before_report, args.after_report)
