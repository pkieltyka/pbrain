"""Replay the release wiring at the registry cutoff and name the index device."""
import json
from pathlib import Path
import sys

scratch = Path(__file__).resolve().parent
pkg = Path(sys.argv[1]).resolve()
replace = {}
for name in ("main.go", "model.go"):
    source = (pkg / name).read_text()
    if name == "main.go":
        old = """cutoff, err := s.calibrateCutoff(f.questions)
        if err != nil {
            return report{}, err
        }""".replace("        ", "\t\t").replace("    return", "\treturn")
        # The acceptance run uses the release row's cutoff without refitting it.
        assert source.count(old) == 1, old
        source = source.replace(old, "row, _ := s.model.registry.Lookup(s.model.name)\n\t\tcutoff := row.Cutoff", 1)
        key = 'Model              *modelReport `json:"model,omitempty"`'
        assert source.count(key) == 1
        source = source.replace(key, key + '\n\tExpectedRanks []int `json:"expected_ranks"`', 1)
        key = "result.Model.BM25WithModel = result.Model.Semantic.Pass && result.Partial.Pass && result.Model.Combined.Pass"
        assert source.count(key) == 1
        source = source.replace(key, key + """
        arm := result.arm(hybrid)
        for _, q := range qs {
            if q.Kind != answerable { continue }
            got, err := decodePage(arm.transcript[q.ID][0])
            if err != nil { return report{}, err }
            at := slices.IndexFunc(got.page.Results, func(hit searchHit) bool {
                return slices.Contains(q.Expect,hit.ID)
            })
            result.ExpectedRanks = append(result.ExpectedRanks, at + 1)
        }
        """.replace("at := slices.IndexFunc(got.page.Results, func(hit searchHit) bool {\n                return slices.Contains(q.Expect,hit.ID)\n            })", """at := -1
            for i, hit := range got.page.Results {
                if slices.Contains(q.Expect, hit.ID) { at = i; break }
            }"""), 1)
    else:
        old = """if _, err := s.command(args...); err != nil {
        return err
    }""".replace("    ", "\t")
        assert source.count(old) == 1, old
        source = source.replace(old, """built, err := s.command(append(args, "--device", os.Getenv("PBRAIN_Q8_CALIBRATE_DEVICE"))...)
        if err != nil { return err }
        fmt.Fprintln(os.Stderr, string(built.out))""", 1)
    staged = scratch / f"calibrate-{name}"
    staged.write_text(source)
    replace[str(pkg / name)] = str(staged)
print(json.dumps({"Replace": replace}))
