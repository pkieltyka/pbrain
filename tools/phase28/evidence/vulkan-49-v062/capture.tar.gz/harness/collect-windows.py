"""Locate the cache-write bursts produced by successive Embed calls."""
import json
from itertools import groupby
import os
from pathlib import Path
import re
import sys
import time

root = Path(__file__).resolve().parent / "full"
start_file = root / "process-start-ns"
if len(sys.argv) == 2:
    pid = int(sys.argv[1])
    after_comm = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
    tick_hz = os.sysconf("SC_CLK_TCK")
    uptime = float(Path("/proc/uptime").read_text().split()[0])
    started = int(after_comm[19]) / tick_hz
    start_file.write_text(str(time.time_ns() - round((uptime - started) * 1e9)) + "\n")
    raise SystemExit()

start = int(start_file.read_text())
stamps = sorted(
    (path.stat().st_mtime_ns, path.name)
    for path in (root / "cache/vectors").glob("*/*/*")
    if re.fullmatch(r"[0-9a-f]{64}", path.name) and path.is_file()
)
bursts = []
planned = []
if len(sys.argv) == 3 and sys.argv[1] == "--exact":
    lookup = {key: when for when, key in stamps}
    rows = json.loads(Path(sys.argv[2]).read_text())
    assert len(lookup) == len(rows)
    for index, group in groupby(rows, key=lambda row: row["window"]):
        assert index == len(bursts) + 1
        captured = list(group)
        planned.append(captured[0]["planned"])
        bursts.append(sorted((lookup[row["digest"]], row["digest"]) for row in captured))
else:
    for when, key in stamps:
        if not bursts or when - bursts[-1][-1][0] > 1_000_000_000:
            bursts.append([])
        bursts[-1].append((when, key))
previous = start
for index, rows in enumerate(bursts, 1):
    first, finish = rows[0][0], rows[-1][0]
    interval = (finish - previous) / 1e9
    print(json.dumps({
        "window": index, "count": len(rows), "planned": planned[index - 1] if planned else None,
        "digests": [key for _, key in rows],
        "finish_s": (finish - start) / 1e9, "interval_s": interval,
        "passages_per_s": len(rows) / interval, "cache_write_span_s": (finish - first) / 1e9,
    }))
    previous = finish
