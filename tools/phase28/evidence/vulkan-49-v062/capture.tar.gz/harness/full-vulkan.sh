#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
[[ -f "$scratch/gate-a.complete" && -f "$scratch/gate-b.complete" ]]
card=/sys/bus/pci/devices/0000:0c:00.0
[[ $(cat "$card/device") == 0x7590 ]]
export LD_LIBRARY_PATH=/nix/store/1l0a4cq8ahhpgwx0byq2zcsi316mlzm1-vulkan-loader-1.4.363.0/lib:/run/opengl-driver/lib
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_NOSYSTEM=1 LC_ALL=C TZ=UTC
unset VK_DRIVER_FILES VK_ICD_FILENAMES DRI_PRIME PBRAIN_{DEVICE,BRAIN,DIR,PROFILE_DIR} GODEBUG GOGC GOMEMLIMIT
case_dir="$scratch/full"
mkdir "$case_dir"
python3 - "$case_dir" <<'PY'
from pathlib import Path
import sys
sys.path.insert(0, "/var/tmp/pbrain-sync-43.XW3O3B")
from measure import prepare
prepare(Path(sys.argv[1]), "gemma", "2cbd38cde77fdc6f1d67949e50efd40d261d9f0a79d6bda5a759a854218db490")
PY
cd "$case_dir/corpus"
export PBRAIN_CACHE="$case_dir/cache"
python3 "$scratch/quiet.py" | tee "$case_dir/quiet.jsonl"
date --iso-8601=seconds
cat /proc/loadavg
nvidia-smi --query-compute-apps=pid,used_memory --format=csv
uuid=$(jq -er '.devices[] | select(.backend == "vulkan") | .persistent' "$scratch/discovery/stdout")
python3 "$scratch/amd-guard.py" --seconds 10800 --budget-mib 1024 "$card" "$case_dir/capture" \
    "$scratch/pbrain-dual" --personal sync --device "$uuid" --json
jq -e '.sections | map([.device, .items, .passages_embedded, .passages_reused]) ==
    [["vulkan:0", 4500, 43642, 0], ["vulkan:0", 500, 4869, 0]]' "$case_dir/capture/stdout"
jq -se 'map(select(.notice.code == "embedding_device")) | length == 1 and
    all(.[]; .notice.message | startswith("vulkan:0") and endswith("1024 MiB a batch"))' \
    <(sed -n '/^{/p' "$case_dir/capture/stderr")
touch "$case_dir/complete"
