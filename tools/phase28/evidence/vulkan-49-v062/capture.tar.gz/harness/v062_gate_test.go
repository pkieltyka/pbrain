//go:build linux && amd64 && vulkan && cuda

package gemma2

import (
	"encoding/json"
	"os"
	"slices"
	"testing"
	"time"

	"github.com/pkieltyka/pbrain/internal/embed"
)

func TestSavedVulkanV062(t *testing.T) {
	pack := fixtureDir(t, "PBRAIN_TEST_GEMMA2_PACK")
	wantUUID := os.Getenv("PBRAIN_TEST_VULKAN_DEVICE")
	if wantUUID == "" || os.Getenv("PBRAIN_GPU_MEMORY") != "1024" {
		t.Fatal("run with the AMD memory guard and explicit UUID")
	}
	raw, err := os.ReadFile(os.Getenv("PBRAIN_SAVED_SHAPE"))
	if err != nil {
		t.Fatal(err)
	}
	var saved struct {
		IDs [][]int `json:"prepared_ids"`
	}
	if err := json.Unmarshal(raw, &saved); err != nil || len(saved.IDs) != 59 {
		t.Fatalf("saved input: %d passages, %v", len(saved.IDs), err)
	}
	texts := batchFixture(t)
	if len(texts) != len(saved.IDs) {
		t.Fatalf("current fixture changed: %d passages", len(texts))
	}
	ctx := t.Context()
	entry := Entry()
	reg := embed.NewRegistry(entry)
	cpu := realEncoder(t)
	want := make([][]float32, len(texts))
	for i, text := range texts {
		ids, err := cpu.tokenIDs(embed.Document, text)
		if err != nil || !slices.Equal(ids, saved.IDs[i]) {
			t.Fatalf("saved IDs changed at passage %d: %v", i, err)
		}
		want[i], err = cpu.embedIDs(ctx, ids)
		if err != nil {
			t.Fatal(err)
		}
	}
	if err := cpu.Close(); err != nil {
		t.Fatal(err)
	}
	emb, err := reg.Open(ctx, verified(t, pack, entry.Model), embed.OpenOptions{Device: wantUUID, MemoryBudget: gib})
	if err != nil {
		t.Fatal(err)
	}
	gpu := emb.(*encoder)
	t.Cleanup(func() { _ = gpu.Close() })
	if gpu.Info().Device != "vulkan:0" || gpu.Info().Budget != gib {
		t.Fatalf("unexpected device or budget: %+v", gpu.Info())
	}
	remaining := saved.IDs
	for i, expected := range [][2]int{{55, 7712}, {4, 1559}} {
		size := batchSize(remaining, int(gpu.Info().Budget/vulkanBytesPerPosition))
		total := 0
		for _, ids := range remaining[:size] {
			total += len(ids)
		}
		if size != expected[0] || total != expected[1] {
			t.Fatalf("partition %d = %d/%d, want %d/%d", i, size, total, expected[0], expected[1])
		}
		remaining = remaining[size:]
		t.Logf("partition %d: %d inputs, %d positions", i+1, size, total)
	}
	if len(remaining) != 0 {
		t.Fatal("unexpected extra partition")
	}
	start := time.Now()
	got, err := gpu.Embed(ctx, embed.Document, texts)
	elapsed := time.Since(start)
	if err != nil {
		t.Fatal(err)
	}
	checkGateCosines(t, "CPU/Vulkan saved batch", want, got)
	t.Logf("59 passages embedded in %.3f s (%.2f passages/s)", elapsed.Seconds(), 59/elapsed.Seconds())
	if err := gpu.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestCUDAParityV062(t *testing.T) {
	pack := fixtureDir(t, "PBRAIN_TEST_GEMMA2_PACK")
	ctx := t.Context()
	entry := Entry()
	reg := embed.NewRegistry(entry)
	texts := batchFixture(t)
	if len(texts) != 59 {
		t.Fatalf("current fixture changed: %d passages", len(texts))
	}
	encode := func(selector string) [][]float32 {
		t.Helper()
		emb, err := reg.Open(ctx, verified(t, pack, entry.Model), embed.OpenOptions{Device: selector, MemoryBudget: gib})
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() { _ = emb.Close() })
		vectors, err := emb.Embed(ctx, embed.Document, texts)
		if err != nil {
			t.Fatalf("%s: %v", selector, err)
		}
		t.Logf("selector %q opened %s", selector, emb.Info().Device)
		if err := emb.Close(); err != nil {
			t.Fatal(err)
		}
		return vectors
	}
	checkGateCosines(t, "CPU/CUDA", encode(""), encode("cuda:0"))
}

func checkGateCosines(t *testing.T, label string, want, got [][]float32) {
	t.Helper()
	if len(got) != len(want) {
		t.Fatalf("%s: %d vectors, want %d", label, len(got), len(want))
	}
	minimum := 1.0
	for i := range want {
		for _, dim := range []int{512, 768} {
			score := similarity(want[i][:dim], got[i][:dim])
			minimum = min(minimum, score)
			if !(score >= .999) {
				t.Errorf("%s passage %d (%d dimensions): %.15f", label, i, dim, score)
			}
		}
	}
	t.Logf("%s: %d matched passages, minimum cosine %.15f", label, len(got), minimum)
}
