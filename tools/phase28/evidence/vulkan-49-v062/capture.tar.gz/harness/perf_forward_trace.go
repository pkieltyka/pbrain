package gemma2

import "time"

var observeV062Forward func([][]int, time.Duration)
