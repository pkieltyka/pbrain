"""Interrupt the one full sync at 30 minutes, leaving its monitor to reap it."""
import os
from pathlib import Path
import select
import signal
import sys
import time

pid = int(sys.argv[1])
executable = str(Path(__file__).parent / "pbrain-dual")
proc = Path("/proc") / str(pid)
fd = os.pidfd_open(pid)
try:
    assert os.readlink(proc / "exe") == executable
    assert "pbrain-vulkan-49-v062.service" in (proc / "cgroup").read_text()
    after_comm = (proc / "stat").read_text().rsplit(")", 1)[1].split()
    started = int(after_comm[19]) / os.sysconf("SC_CLK_TCK")
    now = float(Path("/proc/uptime").read_text().split()[0])
    remaining = max(0, 1800 - (now - started))
    print(f"{time.strftime('%FT%T%z')} PID {pid}, interrupt scheduled in {remaining:.3f}s", flush=True)
    poll = select.poll()
    poll.register(fd, select.POLLIN)
    if not poll.poll(int(remaining * 1000)):
        signal.pidfd_send_signal(fd, signal.SIGINT)
        print(f"{time.strftime('%FT%T%z')} sent SIGINT to full sync PID {pid}", flush=True)
finally:
    os.close(fd)
