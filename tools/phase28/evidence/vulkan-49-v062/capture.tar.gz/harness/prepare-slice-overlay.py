"""Overlay timestamp counters at both production Gemma forward call sites."""
import json
from pathlib import Path
import sys

out = Path(__file__).resolve().parent
pkg = Path(sys.argv[1]).resolve()
replace = {}
for file, statement, ids in [
    ("gemma2.go", "v, err := e.model.EmbedIDs(ids)", "[][]int{ids}"),
    ("batch.go", "vs, err := e.model.EmbedIDsBatch(ids[:n])", "ids[:n]"),
]:
    source = (pkg / file).read_text()
    assert source.count(statement) == 1
    source = source.replace('"context"\n', '"context"\n"time"\n')
    source = source.replace(
        statement,
        f"perfStart := time.Now()\n{statement}\n"
        f"if observeV062Forward != nil {{ observeV062Forward({ids}, time.Since(perfStart)) }}",
    )
    dest = out / f"{file}.instrumented.go"
    dest.write_text(source)
    replace[str(pkg / file)] = str(dest)
for file in ("full_slice_v062_test.go", "perf_forward_trace.go"):
    replace[str(pkg / file)] = str(out / file)
print(json.dumps({"Replace": replace}))
