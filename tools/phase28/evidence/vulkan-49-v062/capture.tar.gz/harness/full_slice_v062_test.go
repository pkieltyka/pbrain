//go:build linux && amd64 && vulkan && cuda

package gemma2

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io/fs"
	"os"
	"path/filepath"
	"runtime"
	"slices"
	"strings"
	"testing"
	"time"

	"github.com/pkieltyka/goinfer/tokenizer"
	"github.com/pkieltyka/pbrain/internal/embed"
	"github.com/pkieltyka/pbrain/internal/item"
	"github.com/pkieltyka/pbrain/internal/semantic"
)

type capturedWindow struct {
	Window  int      `json:"window"`
	Digests []string `json:"digests"`
}

type capturedPassage struct {
	Path      string `json:"path"`
	Ordinal   int    `json:"ordinal"`
	Digest    string `json:"digest"`
	Positions int    `json:"positions"`
	Text      string `json:"text"`
	Window    int    `json:"window"`
	Planned   int    `json:"planned"`
}

func TestVulkanFullWindowShapes(t *testing.T) {
	root := os.Getenv("PBRAIN_FULL_BRAIN")
	pack := os.Getenv("PBRAIN_TEST_GEMMA2_PACK")
	data, err := os.ReadFile(filepath.Join(pack, "tokenizer.bin"))
	if err != nil {
		t.Fatal(err)
	}
	files := Entry().Model.Files
	key := slices.IndexFunc(files, func(f embed.File) bool { return f.Name == "tokenizer.bin" })
	if key < 0 || sha256.Sum256(data) != files[key].SHA256 {
		t.Fatal("could not verify the pinned tokenizer")
	}
	tok, err := tokenizer.LoadPack(data)
	if err != nil {
		t.Fatal(err)
	}
	bos, _ := tok.TokenID("<bos>")
	eos, _ := tok.TokenID("<eos>")
	e := &encoder{tokenizer: tok, bos: bos, eos: eos}

	windowsFile, err := os.Open(os.Getenv("PBRAIN_WINDOWS"))
	if err != nil {
		t.Fatal(err)
	}
	defer windowsFile.Close()
	observed := make(map[string]bool)
	scan := bufio.NewScanner(windowsFile)
	for scan.Scan() {
		var row capturedWindow
		if err := json.Unmarshal(scan.Bytes(), &row); err != nil {
			t.Fatal(err)
		}
		for _, digest := range row.Digests {
			if observed[digest] {
				t.Fatalf("duplicate cached digest %s", digest)
			}
			observed[digest] = true
		}
	}
	total := len(observed)
	if err := scan.Err(); err != nil || total < 200 {
		t.Fatalf("need at least the first 200 completed passages: %v", err)
	}
	passages := make([]capturedPassage, 0, total)
	seen := make(map[string]bool)
	var pending []capturedPassage
	items, ordinalWindow := 0, 0
	err = filepath.WalkDir(root, func(path string, entry fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if entry.IsDir() {
			if path != root && (entry.Name() == "personal" || strings.HasPrefix(entry.Name(), ".")) {
				return filepath.SkipDir
			}
			return nil
		}
		if filepath.Ext(path) != ".md" {
			return nil
		}
		contents, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		h, off, _, err := item.Parse(strings.TrimSuffix(entry.Name(), ".md"), contents)
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		for ordinal, p := range semantic.Passages(h.Title, contents[off:]) {
			digest := hex.EncodeToString(p.Digest[:])
			if seen[digest] {
				continue
			}
			seen[digest] = true
			ids, err := e.tokenIDs(embed.Document, p.Text)
			if err != nil {
				return err
			}
			pending = append(pending, capturedPassage{
				Path: rel, Ordinal: ordinal, Digest: digest, Positions: len(ids), Text: p.Text,
			})
		}
		items++
		if len(pending) >= batchInputs || items >= batchInputs {
			for chunk := range slices.Chunk(pending, batchInputs) {
				ordinalWindow++
				for _, row := range chunk {
					if !observed[row.Digest] {
						return &fs.PathError{Op: "match captured window digest " + row.Digest, Path: row.Path, Err: fs.ErrNotExist}
					}
					row.Window = ordinalWindow
					row.Planned = len(chunk)
					passages = append(passages, row)
					if len(passages) == total {
						return fs.SkipAll
					}
				}
			}
			pending = pending[:0]
			items = 0
		}
		return nil
	})
	if err != nil || len(passages) != total {
		t.Fatalf("reconstructed %d / %d cached passages: %v", len(passages), total, err)
	}
	writePerfJSON(t, os.Getenv("PBRAIN_WINDOW_PASSAGES"), passages)
	t.Logf("matched %d cache digests across %d scheduled embed windows in production passage order", total, ordinalWindow)
}

func writePerfJSON(t *testing.T, path string, value any) {
	t.Helper()
	raw, err := json.Marshal(value)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, append(raw, '\n'), 0o600); err != nil {
		t.Fatal(err)
	}
}

func TestVulkanMatchedSliceV062(t *testing.T) {
	data, err := os.ReadFile(os.Getenv("PBRAIN_WINDOW_PASSAGES"))
	if err != nil {
		t.Fatal(err)
	}
	var all []capturedPassage
	if err := json.Unmarshal(data, &all); err != nil || len(all) < 200 {
		t.Fatalf("invalid matched slice: %v", err)
	}
	fixed := all[:200]
	texts := make([]string, len(fixed))
	count := 0
	for i, row := range fixed {
		texts[i] = row.Text
		count += row.Positions
	}
	entry := Entry()
	pack := fixtureDir(t, "PBRAIN_TEST_GEMMA2_PACK")
	selector := os.Getenv("PBRAIN_SLICE_DEVICE")
	var budget int64
	if selector != "" {
		if os.Getenv("PBRAIN_GPU_MEMORY") != "1024" {
			t.Fatal("set the 1 GiB workspace explicitly")
		}
		budget = gib
	}
	reg := embed.NewRegistry(entry)
	emb, err := reg.Open(t.Context(), verified(t, pack, entry.Model), embed.OpenOptions{Device: selector, MemoryBudget: budget})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = emb.Close() })
	wantDevice := selector
	if selector == "" {
		wantDevice = "cpu"
	} else if strings.HasPrefix(selector, "vulkan:") {
		wantDevice = "vulkan:0"
	}
	if info := emb.Info(); info.Device != wantDevice || info.Budget != budget {
		t.Fatalf("matched run opened %+v, expected %s with budget %d", info, wantDevice, budget)
	}
	type forward struct {
		Positions []int `json:"positions"`
		ElapsedNS int64 `json:"elapsed_ns"`
	}
	var trace []forward
	observeV062Forward = func(ids [][]int, duration time.Duration) {
		lengths := make([]int, len(ids))
		for i, row := range ids {
			lengths[i] = len(row)
		}
		trace = append(trace, forward{lengths, duration.Nanoseconds()})
	}
	defer func() { observeV062Forward = nil }()

	t.Logf("measuring %s at GOMAXPROCS=%d, %d inputs, %d positions", wantDevice, runtime.GOMAXPROCS(0), len(texts), count)
	start := time.Now()
	got, err := emb.Embed(t.Context(), embed.Document, texts)
	elapsed := time.Since(start)
	if err != nil || len(got) != len(fixed) {
		t.Fatalf("%s returned %d/%d vectors: %v", wantDevice, len(got), len(fixed), err)
	}
	var offset int
	for _, call := range trace {
		for _, length := range call.Positions {
			if offset >= len(fixed) || fixed[offset].Positions != length {
				t.Fatalf("forward %d diverges from the fixed input token counts", offset)
			}
			offset++
		}
	}
	if offset != len(fixed) {
		t.Fatalf("timed %d of %d inputs", offset, len(fixed))
	}
	writePerfJSON(t, os.Getenv("PBRAIN_SLICE_RESULT"), map[string]any{
		"device": emb.Info(), "gomaxprocs": runtime.GOMAXPROCS(0), "inputs": len(fixed), "positions": count,
		"elapsed_s": elapsed.Seconds(), "passages_per_s": float64(len(fixed)) / elapsed.Seconds(), "forwards": trace,
	})
	t.Logf("%s: %.3f s, %.3f passages/s, %d forwards", wantDevice, elapsed.Seconds(), float64(len(fixed))/elapsed.Seconds(), len(trace))
	if err := emb.Close(); err != nil {
		t.Fatal(err)
	}
}
