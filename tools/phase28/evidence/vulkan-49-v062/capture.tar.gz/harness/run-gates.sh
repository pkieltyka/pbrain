#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
card=/sys/bus/pci/devices/0000:0c:00.0
export LD_LIBRARY_PATH=/nix/store/1l0a4cq8ahhpgwx0byq2zcsi316mlzm1-vulkan-loader-1.4.363.0/lib:/run/opengl-driver/lib
export PBRAIN_TEST_GEMMA2_PACK=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
export PBRAIN_SAVED_SHAPE=/var/tmp/pbrain-vulkan-49/exact-batch-shape.json
unset VK_DRIVER_FILES VK_ICD_FILENAMES DRI_PRIME PBRAIN_DEVICE PBRAIN_BRAIN CUDA_VISIBLE_DEVICES
[[ $(cat "$card/device") == 0x7590 ]]
sha256sum "$PBRAIN_SAVED_SHAPE"
uname -a
nvidia-smi --query-gpu=uuid,name,driver_version --format=csv
nvidia-smi --query-compute-apps=pid,used_memory --format=csv
date --iso-8601=seconds
python3 "$scratch/amd-guard.py" --seconds 30 --budget-mib 1024 --discovery-only "$card" "$scratch/discovery" \
    "$scratch/pbrain-dual" devices --json
jq -e '[.devices[].id] == ["cuda:0", "vulkan:0", "cpu"]' "$scratch/discovery/stdout"
PBRAIN_TEST_VULKAN_DEVICE=$(jq -er '.devices[] | select(.backend == "vulkan") | .persistent' "$scratch/discovery/stdout")
export PBRAIN_TEST_VULKAN_DEVICE
[[ "$PBRAIN_TEST_VULKAN_DEVICE" == vulkan:000000000c0000000000000000000000 ]]
cd internal/embed/gemma2
for phase in a b; do
    name=TestSavedVulkanV062
    if [[ $phase == b ]]; then
        name=TestGemmaVulkan
    fi
    date --iso-8601=seconds
    printf 'Gate %s / %s\n' "$phase" "$name"
    if python3 "$scratch/amd-guard.py" --seconds 300 --budget-mib 1024 "$card" "$scratch/gate-$phase" \
        "$scratch/gemma2-dual.test" -test.run "^$name$" -test.v -test.timeout=290s; then
        status=0
    else
        status=$?
    fi
    cat "$scratch/gate-$phase/stdout" "$scratch/gate-$phase/stderr"
    if [[ $status != 0 ]]; then
        cat "$scratch/gate-$phase/kernel.log"
        exit "$status"
    fi
    grep -q -- "--- PASS: $name" "$scratch/gate-$phase/stdout"
    touch "$scratch/gate-$phase.complete"
done
