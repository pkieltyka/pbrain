#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
root="$scratch/full"
mkdir -p "$scratch/slice"
jq -se 'last.exit == -2 and last.stop_reason == null' "$root/capture/vram.jsonl"
grep -q 'sent SIGINT' "$root/interrupt.log"

export CGO_ENABLED=0
python3 "$scratch/prepare-slice-overlay.py" "$PWD/internal/embed/gemma2" > "$scratch/slice/overlay.json"
GOMAXPROCS=4 taskset -c 4-7 go test -p 2 -c -trimpath -tags 'cuda vulkan' \
    -overlay="$scratch/slice/overlay.json" -o "$scratch/slice/bench.test" ./internal/embed/gemma2
go version -m "$scratch/slice/bench.test" > "$scratch/slice/build-info.log"
sha256sum "$scratch/slice/bench.test" > "$scratch/slice/binary.sha256"
python3 "$scratch/collect-windows.py" > "$scratch/slice/cache-bursts.jsonl"
export PBRAIN_FULL_BRAIN="$root/corpus/docs/brain"
export PBRAIN_WINDOWS="$scratch/slice/cache-bursts.jsonl"
export PBRAIN_WINDOW_PASSAGES="$scratch/slice/passages.json"
export PBRAIN_TEST_GEMMA2_PACK=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
export PBRAIN_ALLOW_GEMMA2=1 PBRAIN_GPU_MEMORY=1024
unset GOMAXPROCS VK_DRIVER_FILES VK_ICD_FILENAMES DRI_PRIME PBRAIN_DEVICE
cd internal/embed/gemma2
GOMAXPROCS=4 timeout 30s taskset -c 4-7 "$scratch/slice/bench.test" \
    -test.run '^TestVulkanFullWindowShapes$' -test.v -test.timeout=28s > "$scratch/slice/window-shapes.log"
python3 "$scratch/collect-windows.py" --exact "$PBRAIN_WINDOW_PASSAGES" > "$scratch/slice/windows.jsonl"

base="$scratch/slice"
card=/sys/bus/pci/devices/0000:0c:00.0
args=(-test.run '^TestVulkanMatchedSliceV062$' -test.v -test.timeout=590s)
LD_LIBRARY_PATH=/nix/store/1l0a4cq8ahhpgwx0byq2zcsi316mlzm1-vulkan-loader-1.4.363.0/lib:/run/opengl-driver/lib
export LD_LIBRARY_PATH
for mode in vulkan cuda cpu; do
    if [[ -f "$base/$mode.complete" ]]; then
        continue
    fi
    printf '%s %s preflight\n' "$(date --iso-8601=seconds)" "$mode"
    python3 "$scratch/quiet.py" --max-busy-pct 5 --attempts 24 > "$base/$mode-quiet.jsonl"
    export PBRAIN_SLICE_RESULT="$base/$mode.json"
    case "$mode" in
        vulkan)
            [[ $(cat "$card/device") == 0x7590 ]]
            export PBRAIN_SLICE_DEVICE=vulkan:000000000c0000000000000000000000
            python3 "$scratch/amd-guard.py" --default-workers --seconds 600 --budget-mib 1024 "$card" "$base/vulkan" \
                "$base/bench.test" "${args[@]}"
            grep -q -- '--- PASS: TestVulkanMatchedSliceV062' "$base/vulkan/stdout"
            ;;
        cuda)
            export PBRAIN_SLICE_DEVICE=cuda:0
            CUDA_VISIBLE_DEVICES=$(nvidia-smi -i 0 --query-gpu=uuid --format=csv,noheader) \
                LD_LIBRARY_PATH=/run/opengl-driver/lib \
                timeout 600s "$base/bench.test" "${args[@]}" > "$base/cuda.log" 2>&1
            grep -q -- '--- PASS: TestVulkanMatchedSliceV062' "$base/cuda.log"
            ;;
        cpu)
            export PBRAIN_SLICE_DEVICE=""
            CUDA_VISIBLE_DEVICES="" LD_LIBRARY_PATH=/run/opengl-driver/lib \
                timeout 600s "$base/bench.test" "${args[@]}" > "$base/cpu.log" 2>&1
            grep -q -- '--- PASS: TestVulkanMatchedSliceV062' "$base/cpu.log"
            ;;
    esac
    jq -c 'del(.forwards)' "$PBRAIN_SLICE_RESULT"
    touch "$base/$mode.complete"
done
touch "$base/complete"
