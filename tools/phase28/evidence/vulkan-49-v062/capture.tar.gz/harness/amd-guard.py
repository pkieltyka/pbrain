"""Run one explicitly selected AMD test with pax's 4 GiB process cap."""
import argparse
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import time
import re


cap = 4 << 30
fault = re.compile(r"0c:00\.0.*(ring .*(timeout|reset)|GPU reset|DEVICE_LOST)", re.IGNORECASE)
device_lost = re.compile(r"device (?:vulkan:\S+ )?(?:was )?lost|VkResult -4\b", re.IGNORECASE)


def kernel_since(cursor, follow=False):
    args = ["journalctl", "-k", "-o", "short-iso-precise", "--no-pager", "--after-cursor", cursor]
    if follow:
        args.append("--follow")
    return args


def device_used(device):
    return int((device / "mem_info_vram_used").read_text())


def process_used(pid, device):
    info = Path(f"/proc/{pid}/fdinfo")
    clients = {}
    try:
        entries = list(info.iterdir())
    except FileNotFoundError:
        return None
    for fd in entries:
        try:
            fields = dict(line.split(":", 1) for line in fd.read_text().splitlines() if ":" in line)
        except FileNotFoundError:
            continue
        if fields.get("drm-driver", "").strip() != "amdgpu":
            continue
        if fields.get("drm-pdev", "").strip() != device.name:
            continue
        client = fields.get("drm-client-id")
        if client is None:
            continue
        counts = []
        for name in ("drm-memory-vram", "drm-resident-vram"):
            if name in fields:
                number, unit = fields[name].strip().split()
                multiplier = {"B": 1, "KiB": 1 << 10, "MiB": 1 << 20}[unit]
                counts.append(int(number) * multiplier)
        if counts:
            clients[client] = max(clients.get(client, 0), *counts)
    return sum(clients.values()) if clients else None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("device", type=Path, help="PCI device or DRM card's device symlink")
    parser.add_argument("output", type=Path)
    parser.add_argument("--budget-mib", type=int, default=512)
    parser.add_argument("--seconds", type=int, required=True)
    parser.add_argument("--default-workers", action="store_true")
    parser.add_argument("--discovery-only", action="store_true")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    opts = parser.parse_args()
    device = opts.device.resolve(strict=True)
    if (device / "vendor").read_text().strip() != "0x1002":
        parser.error("the selected device must be AMD")
    if not 1 <= opts.budget_mib <= 1024:
        parser.error("the short AMD tests use at most 1 GiB of batch workspace")
    if not opts.command:
        parser.error("a monitored command is required")
    if not 1 <= opts.seconds <= 10800:
        parser.error("set a positive time limit of at most three hours")
    opts.output.mkdir(parents=True)
    idle = []
    for _ in range(10):
        idle.append(device_used(device))
        time.sleep(0.1)
    total = int((device / "mem_info_vram_total").read_text())
    planned = (512 + opts.budget_mib) << 20  # model upload, staging and selected workspace
    if not opts.discovery_only and total - max(idle) < planned:
        raise RuntimeError(f"free device memory is smaller than the {planned >> 20} MiB planned working set")
    monitor = opts.output / "vram.jsonl"
    env = {**os.environ, "PBRAIN_GPU_MEMORY": str(opts.budget_mib), "PBRAIN_ALLOW_GEMMA2": "1",
           "GOMAXPROCS": "4"}
    if not opts.discovery_only:
        env["CUDA_VISIBLE_DEVICES"] = ""
    if opts.default_workers:
        env.pop("GOMAXPROCS", None)
        command = opts.command
    else:
        command = ["taskset", "-c", "0-3", *opts.command]
    reason = None
    high = 0
    before = subprocess.check_output(
        ["journalctl", "-k", "-n", "1", "--show-cursor", "-o", "short-iso-precise", "--no-pager"], text=True
    )
    cursor = before.rsplit("-- cursor: ", 1)[1].strip()
    (opts.output / "journal-before").write_text(before)
    journal = opts.output / "kernel-follow.log"
    with journal.open("wb") as journal_out, subprocess.Popen(kernel_since(cursor, follow=True), stdout=journal_out) as watcher:
        try:
            reason, status, high = run(opts, env, command, monitor, device, total, idle, journal, watcher)
        finally:
            watcher.terminate()
    after = subprocess.check_output(kernel_since(cursor), text=True)
    (opts.output / "kernel.log").write_text(after)
    if fault.search(after):
        reason = "kernel reset or ring timeout"
    elif any(device_lost.search((opts.output / stream).read_text(errors="replace"))
             for stream in ("stdout", "stderr")):
        reason = "device lost"
    result = {"phase": "result", "exit": status, "peak_share_bytes": high, "stop_reason": reason}
    with monitor.open("a") as log:
        print(json.dumps(result), file=log)
    print(json.dumps(result))
    if reason is not None or status != 0 or (high == 0 and not opts.discovery_only):
        raise SystemExit(1)


def run(opts, env, command, monitor, device, total, idle, journal, watcher):
    reason = None
    high = 0
    start = time.monotonic()
    with monitor.open("x") as log, (opts.output / "stdout").open("xb") as stdout, \
            (opts.output / "stderr").open("xb") as stderr, journal.open() as journal_in:
        print(json.dumps({"phase": "preflight", "device": str(device), "idle_bytes": idle,
                          "total_bytes": total, "limit_bytes": cap, "budget_mib": opts.budget_mib,
                          "discovery_only": opts.discovery_only,
                          "seconds_limit": opts.seconds, "command": command,
                          "loadavg": Path("/proc/loadavg").read_text().strip()}), file=log, flush=True)
        with subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr) as proc:
            pidfd = os.pidfd_open(proc.pid)
            try:
                poll = select.poll()
                poll.register(pidfd, select.POLLIN)
                while not poll.poll(25):
                    device_total = device_used(device)
                    process_total = process_used(proc.pid, device)
                    share = max(0, device_total - min(idle), process_total or 0)
                    high = max(high, share)
                    elapsed = time.monotonic() - start
                    print(json.dumps({"elapsed_s": elapsed, "device_used_bytes": device_total,
                                      "process_vram_bytes": process_total, "guard_share_bytes": share}),
                          file=log, flush=True)
                    if fault.search(journal_in.read()):
                        reason = "kernel reset or ring timeout"
                    elif watcher.poll() is not None:
                        reason = "kernel monitor exited"
                    elif share > cap:
                        reason = "VRAM cap"
                    elif elapsed >= opts.seconds:
                        reason = "time limit"
                    if reason:
                        signal.pidfd_send_signal(pidfd, signal.SIGKILL)
                        break
            except BaseException:
                signal.pidfd_send_signal(pidfd, signal.SIGKILL)
                raise
            finally:
                os.close(pidfd)
            _, raw_status, usage = os.wait4(proc.pid, 0)
            status = proc.returncode = os.waitstatus_to_exitcode(raw_status)
            print(json.dumps({"phase": "timing", "wall_s": time.monotonic() - start,
                              "peak_rss_kib": usage.ru_maxrss}), file=log)
    return reason, status, high


if __name__ == "__main__":
    main()
