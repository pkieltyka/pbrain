"""Summarize production cache windows and matched adapter calls on one slice."""
import json
import math
from pathlib import Path
from statistics import correlation, median
import sys


bounds = (128, 256, 512, 768, 1024)


def mix(positions):
    order = sorted(positions)
    return {
        "positions_total": sum(order),
        "min": order[0],
        "median": median(order),
        "p90": order[math.ceil(len(order) * 0.9) - 1],
        "max": order[-1],
        "histogram": {
            str(bound): sum(prior < p <= bound for p in order)
            for prior, bound in zip((0, *bounds), (*bounds, math.inf), strict=True)
        },
    }


def summarize_forwards(row):
    forwards = []
    for n, trace in enumerate(row["forwards"], 1):
        lengths = trace["positions"]
        elapsed = trace["elapsed_ns"] / 1e6
        forwards.append({
            "ordinal": n,
            "inputs": len(lengths),
            "elapsed_ms": elapsed,
            "ms_per_input": elapsed / len(lengths),
            "mean_positions_per_input": sum(lengths) / len(lengths),
            "work_proxy": sum(p * p for p in lengths),
            **mix(lengths),
        })
    means = [f["mean_positions_per_input"] for f in forwards]
    input_counts = [f["inputs"] for f in forwards]
    per_input = [f["ms_per_input"] for f in forwards]
    duration = [f["elapsed_ms"] for f in forwards]
    return {
        "run": {k: v for k, v in row.items() if k != "forwards"},
        "forward_count": len(forwards),
        "forward_ms": sum(duration),
        "median_ms_per_input_per_call": median(per_input),
        "range_ms_per_input_per_call": [min(per_input), max(per_input)],
        "mean_positions_vs_ms_per_input_r": correlation(means, per_input) if min(means) < max(means) else None,
        "input_count_vs_call_ms_r": correlation(input_counts, duration) if min(input_counts) < max(input_counts) else None,
        "by_forward": forwards,
    }


def main():
    base = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "slice"
    windows = [json.loads(line) for line in (base / "windows.jsonl").read_text().splitlines()]
    expected = json.loads((base / "passages.json").read_text())
    offset = 0
    summaries = []
    for row in windows:
        end = offset + row["count"]
        item = {k: v for k, v in row.items() if k != "digests"}
        ns = [p["positions"] for p in expected[offset:end]]
        assert len(ns) == row["count"]
        summaries.append(item | mix(ns))
        offset = end
    assert offset == len(expected)
    fixed = expected[:200]
    output = {
        "windows": summaries,
        "fixed_slice": mix([p["positions"] for p in fixed]),
        "measurements": {
            device: summarize_forwards(json.loads((base / f"{device}.json").read_text()))
            for device in ("vulkan", "cuda", "cpu") if (base / f"{device}.json").exists()
        },
    }
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
