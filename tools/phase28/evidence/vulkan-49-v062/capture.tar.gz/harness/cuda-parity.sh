#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
uuid=$(nvidia-smi -i 0 --query-gpu=uuid --format=csv,noheader)
[[ -z $(nvidia-smi -i "$uuid" --query-compute-apps=pid --format=csv,noheader) ]]
date --iso-8601=seconds
cat /proc/loadavg
nvidia-smi -i "$uuid" --query-gpu=uuid,name,driver_version,memory.free,utilization.gpu --format=csv
export CUDA_VISIBLE_DEVICES="$uuid" LD_LIBRARY_PATH=/run/opengl-driver/lib
export GOMAXPROCS=4 PBRAIN_ALLOW_GEMMA2=1
export PBRAIN_TEST_GEMMA2_PACK=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
cd internal/embed/gemma2
timeout 300s taskset -c 0-3 "$scratch/gemma2-dual.test" \
    -test.run '^(TestCUDAParityV062|TestGemmaParity|TestGemmaBatchSameBytes)$' -test.v -test.timeout=290s
