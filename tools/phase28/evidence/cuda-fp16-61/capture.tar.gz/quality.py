"""Real sync, row parity, and the frozen search admission gates for #61."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sqlite3
import statistics
import struct
import subprocess

from qualification import ENV, GPU, ROOT, quiet, run

repo = Path(os.environ.get("PBRAIN_FP16_REPO", Path.cwd())).resolve()
fixture = repo / "internal/semantic/calibrate/testdata/retrieval"
weights = Path("/var/tmp/pbrain-verity-59.FXgeNi/measurement")
paths = (repo / "tools/phase28/evidence/gemma-pax-22/fixture-paths.txt").read_text().splitlines()
content = Path(ROOT / "quality")
binary = ROOT / "pbrain-candidate"
models = {"google":"embeddinggemma-2", "q8":"embeddinggemma-2-q8-0"}

def records(mode):
    return [json.loads(l) for l in mode.read_text().splitlines()]

def write(path,d):
    path.write_text(json.dumps(d,indent=2)+"\n")

def vector_digest(payload):
    return hashlib.sha256(payload).hexdigest()

def equal_file_tree(left,right):
    values=lambda root:{str(f.relative_to(root)):vector_digest(f.read_bytes()) for f in root.rglob("*") if f.is_file()}
    a,b = values(left),values(right)
    assert a and a==b
    return a

def setup(row,scope,mode):
    model = models[row]
    cache_mode = "fp16" if mode.startswith("fp16") else "fp32"
    out = content / row / scope / mode
    project = out/"project"
    brain = project/"docs/brain"
    brain.mkdir(parents=True)
    entries=paths if scope=="parity" else sorted(str(f.relative_to(fixture/"brain")) for f in (fixture/"brain").rglob("*.md"))
    signature=hashlib.sha256()
    for rel in entries:
        doc=(fixture/"brain"/rel).read_bytes()
        p=brain/rel
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(doc)
        signature.update(os.fsencode(rel)+b"\0"+hashlib.sha256(doc).digest())
    (brain/"pbrain.toml").write_text(f'[semantic]\nmodel = "{model}"\ncuda_precision = "{cache_mode}"\n')
    cache=out/"cache"
    dst=cache/"models"
    dst.mkdir(parents=True)
    sealed=weights/row/"sealed-cache/models"
    source=next(x for x in sealed.iterdir() if x.is_dir())
    (dst/source.name).mkdir()
    for f in source.iterdir():
        os.link(f,dst/source.name/f.name)
    env=dict(ENV,PBRAIN_CACHE=str(cache),PBRAIN_TRACE=str(out/"sync-trace.jsonl"))
    argv=[ROOT/"pbrain-split" if mode=="fp16-split" else binary, "sync","--device", "cpu" if mode=="cpu" else "cuda:"+GPU,"--json"]
    if mode=="fp16-split":
        env["PBRAIN_FP16_INJECT_OOM"]="1"
    device_measurement=run(out,argv,env,cwd=project)
    sections=json.loads((out/"stdout").read_text())["sections"]
    assert len(sections)==1 and sections[0]["items"]==len(entries)
    assert sections[0]["passages_reused"]==0 and sections[0]["passages_embedded"]==(59 if scope=="parity" else 62)
    assert sections[0]["device"]==("cpu" if mode=="cpu" else "cuda:0"),sections
    assert "cuda_precision_fallback" not in (out/"stderr").read_text()
    mf=json.loads((brain/".pbrain/index/manifest").read_text())
    assert mf.get("cuda_precision_request","fp32")==cache_mode
    trace=records(out/"sync-trace.jsonl")
    forwards=[r for r in trace if r["span"]=="forward"]
    failed=[r for r in forwards if r.get("failed")]
    assert len(failed)==(mode=="fp16-split")
    assert all(r["total_positions"]<=8192 and r["inputs"]<=256 for r in forwards)
    assert sum(r["inputs"] for r in forwards if not r.get("failed"))==sections[0]["passages_embedded"]
    if failed:
        assert max(r["total_positions"] for r in forwards[forwards.index(failed[0])+1:])<=failed[0]["total_positions"]//2
    result={"model":row,"scope":scope,"mode":mode,"fixture_sha256":signature.hexdigest(),
            "count":sections[0]["passages_embedded"],"manifest":mf,"measurement":device_measurement,"shapes":forwards}
    write(out/"summary.json",result)
    print(json.dumps(result),flush=True)
    return out

def data(out):
    dir=out/"project/docs/brain/.pbrain/index"
    meta=json.loads((dir/"manifest").read_text())
    with sqlite3.connect((dir/meta["db"]).as_uri()+"?mode=ro&immutable=1",uri=True) as c:
        assert c.execute("PRAGMA quick_check").fetchall()==[("ok",)]
        items=c.execute("select path,content,crc,size from item order by path").fetchall()
        rows=c.execute("select item.path,ord,start,stop,digest,vector from passage join item on item_id=item.id order by item.path, ord").fetchall()
    return items,rows

def cosine(a,b):
    u,v=[struct.unpack("<768f",s) for s in (a,b)]
    assert all(math.isfinite(x) for x in u+v)
    norm_u,norm_v=[math.fsum(x*x for x in vec)**.5 for vec in (u,v)]
    assert abs(norm_u-1)<1e-5 and abs(norm_v-1)<1e-5
    return math.fsum(x*y for x,y in zip(u,v))/(norm_u*norm_v)

def verify_vectors(row, runs):
    p = {k:data(d) for k,d in runs.items()}
    reports=[]
    for left,right in (("fp16","fp32"),("fp16","cpu"),("fp32","cpu"),("fp16","fp16-split")):
        a,b=p[left],p[right]
        assert a[0]==b[0] and len(a[1])==len(b[1])==59
        pair=[]
        for av,bv in zip(a[1],b[1]):
            assert av[:-1]==bv[:-1]
            cos=cosine(av[-1],bv[-1])
            pair.append({"path":av[0],"ord":av[1],"passage_digest":av[4].hex(),
                         "cosine":cos,"identical":av[-1]==bv[-1]})
        cos=[x["cosine"] for x in pair]
        identities=sum(x["identical"] for x in pair)
        assert min(cos)>=0.999 and (right!="fp16-split" or identities==59)
        report={"row":row,"left":left,"right":right,"count":len(pair),"identical":identities,
                "minimum":min(cos),"median":statistics.median(cos),"pairs":pair}
        reports.append(report)
    files=equal_file_tree(runs["fp16"]/"cache/vectors",runs["fp16-split"]/"cache/vectors")
    assert len(files)==59
    write(content/row/"parity-report.json",dict(comparisons=reports,identical_vector_cache_files=files))

def search(case,q,flags):
    env=dict(ENV,CUDA_VISIBLE_DEVICES="",PBRAIN_CACHE=str(case/"cache"))
    cmd=["timeout","-k","5s","15s","taskset","-c","0-3",binary,"search","--json",*flags,"--",q["q"]]
    p=subprocess.run(cmd,env=env,cwd=case/"project",check=True,capture_output=True,text=True)
    assert "semantic_not_ready" not in p.stderr and "semantic_partial" not in p.stderr, p.stderr
    page=json.loads(p.stdout)
    ids=[x["id"] for x in (page.get("results") or [])]
    rank=next((i+1 for i,id in enumerate(ids) if id in q.get("expect",[])),None)
    return dict(ids=ids,expected_rank=rank,stderr=p.stderr)

def ranking(row):
    d=content/row
    quiet(d/"ranking-quiet.jsonl")
    questions=[q for q in json.loads((fixture/"questions.json").read_text())
               if q["kind"]=="answerable" or q["half"]=="held-out"]
    assert sum(q["kind"]=="answerable" for q in questions)==47 and len(questions)==77
    results={}
    for q in questions:
        cases={}
        cases["strict"]=search(d/"retrieval/fp32",q,[])
        for mode in ("fp32","fp16"):
            for label,flags in (("hybrid",["--semantic"]),("combined",["--semantic","--bm25"])):
                cases[f"{mode}-{label}"]=search(d/"retrieval"/mode,q,flags)
        results[q["id"]]=cases
    write(d/"ranks.json",results)
    counts={}
    changes=[]
    failures=[]
    for mode in ("strict","fp32-hybrid","fp16-hybrid","fp32-combined","fp16-combined"):
        is_answer=lambda q:q["kind"]=="answerable"
        ranks=[results[q["id"]][mode]["expected_rank"] for q in questions if is_answer(q)]
        answers=[q for q in questions if not is_answer(q) and results[q["id"]][mode]["ids"]]
        counts[mode]={"first":sum(x==1 for x in ranks),"top_three":sum(x is not None and x<=3 for x in ranks),
                      "expected_on_page":sum(x is not None for x in ranks),"empty":30-len(answers),
                      "nonempty_negative_ids":[q["id"] for q in answers]}
        if mode.startswith("fp16") and (len(answers)>1 or any(q.get("regression") for q in answers)):
            failures.append(mode+" abstention gate")
    for q in questions:
        cases=results[q["id"]]
        if q["kind"]=="answerable" and cases["strict"]["expected_rank"] is not None and cases["fp16-hybrid"]["expected_rank"] is None:
            failures.append(q["id"]+" lost strict expected hit")
        for label in ("hybrid","combined"):
            before,after=[cases[f"{mode}-{label}"] for mode in ("fp32","fp16")]
            if before!=after:
                changes.append({"label":label,"question":q["id"],"before":before,"after":after})
            br,ar=before["expected_rank"],after["expected_rank"]
            if br is not None and (ar is None or br<=3<ar or br==1!=ar):
                failures.append(f'{q["id"]} {label} lost expected rank {br}->{ar}')
            if q["kind"]=="unanswerable" and not before["ids"] and after["ids"]:
                failures.append(f'{q["id"]} {label} new false answer')
    if counts["fp16-hybrid"]["expected_on_page"] <= counts["strict"]["expected_on_page"]:
        failures.append("hybrid gain gate")
    report=dict(row=row,counts=counts,changes=changes,failures=failures)
    write(d/"rank-summary.json",report)
    print(json.dumps(report),flush=True)
    return [f"{row}: {reason}" for reason in failures]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("stage",choices=("build","rank"))
    ns=parser.parse_args()
    failures = []
    for row in models:
        if ns.stage=="build":
            runs={m:setup(row,"parity",m) for m in ("fp32","fp16","fp16-split","cpu")}
            verify_vectors(row,runs)
            for m in ("fp32","fp16"):
                setup(row,"retrieval",m)
        else:
            failures.extend(ranking(row))
    if failures:
        raise RuntimeError(f"retrieval gate failures: {failures}")

if __name__=="__main__":
    main()
