"""Check the default and the project opt-out under release tags."""
import json
from pathlib import Path

from qualification import ENV, GPU, PACKS, ROOT, run

note = """---
kind: note
title: CUDA release check
created: 2026-11-23T00:00:00Z
author: agent:ci
---
The same note is indexed after changing GPU precision.
"""

def rollout():
    report = []
    for arm, model in (("google", "embeddinggemma-2"), ("q8", "embeddinggemma-2-q8-0")):
        project = ROOT / "rollout" / arm / "project"
        brain = project / "docs/brain"
        (brain / "notes").mkdir(parents=True)
        (brain / "notes/check.md").write_text(note)
        (brain / "personal.toml").write_text("model_path = " + json.dumps(PACKS[arm]) + "\n")
        for requested, selector in (("", "cuda-eg2-fp16"), ("fp32", "cuda"), ("fp16", "cuda-eg2-fp16")):
            case = ROOT / "rollout" / arm / (requested or "default")
            config = f'[semantic]\nmodel = "{model}"\n'
            if requested:
                config += f'cuda_precision = "{requested}"\n'
            (brain / "pbrain.toml").write_text(config)
            env = dict(ENV, PBRAIN_CACHE=str(project.parent/"cache"), PBRAIN_TRACE=str(case/"trace.jsonl"),
                       PBRAIN_FP16_SELECTOR_OUT=str(case/"selector.txt"))
            measured = run(case, [ROOT/"pbrain-selector-check", "sync", "--json"], env, cwd=project)
            manifest = json.loads((brain/".pbrain/index/manifest").read_text())
            result = json.loads((case/"stdout").read_text())["sections"][0]
            err = (case/"stderr").read_text()
            assert result["items"] == 1
            if requested != "fp16":
                assert result["passages_embedded"] == 1 and result["passages_reused"] == 0 and result["device"] == "cuda:0"
                assert (case/"selector.txt").read_text() == f"{selector} cuda:{GPU}\n"
                assert "cuda_precision_fallback" not in err
            else:
                assert result["passages_embedded"] == 0 and result["passages_reused"] == 1
                assert not (case/"selector.txt").exists()
            assert manifest.get("cuda_precision_request","fp32") == (requested or "fp16")
            report.append(dict(row=arm, request=requested or "default", selector=selector if requested!="fp16" else None,
                               manifest=manifest, result=result, measurement=measured))
        a,b,c = report[-3:]
        assert a["manifest"]["fingerprint"] == c["manifest"]["fingerprint"] != b["manifest"]["fingerprint"]
    (ROOT/"rollout.json").write_text(json.dumps(report,indent=2)+"\n")

if __name__ == "__main__":
    rollout()
