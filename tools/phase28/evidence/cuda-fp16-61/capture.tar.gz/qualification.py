"""Bounded hardware checks for the precision rollout."""
import csv
import json
import os
from pathlib import Path
import subprocess
import time


ROOT = Path(__file__).resolve().parent
GPU = subprocess.check_output(["nvidia-smi", "-i", "0", "--query-gpu=uuid", "--format=csv,noheader"], text=True).strip()
ENV = dict(os.environ, PBRAIN_ALLOW_GEMMA2="1", CUDA_VISIBLE_DEVICES=GPU,
           LD_LIBRARY_PATH="/run/opengl-driver/lib", GOMAXPROCS="4", LC_ALL="C", TZ="UTC",
           GIT_CONFIG_GLOBAL="/dev/null", GIT_CONFIG_NOSYSTEM="1")
for key in ("PBRAIN_TRACE", "PBRAIN_GPU_MEMORY", "PBRAIN_DEVICE", "PBRAIN_DIR", "PBRAIN_BRAIN", "GOGC", "GOMEMLIMIT", "GODEBUG"):
    ENV.pop(key,None)
PACKS = {"google":"/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack",
         "q8":"/var/tmp/pbrain-sync-trace.NSKyVs/q8-model"}


def quiet(path):
    with path.open("w") as file:
        subprocess.run(["python3","/var/tmp/pbrain-q8-master84.MnCK65/quiet.py",
                        "--max-busy-pct","4","--attempts","60"],stdout=file,check=True)


def run(out, argv, env, cwd=None):
    out.mkdir(parents=True, exist_ok=True)
    quiet(out/"quiet.jsonl")
    assert not subprocess.check_output(["nvidia-smi","-i",GPU,"--query-compute-apps=pid","--format=csv,noheader"],text=True).strip()
    with (out/"stdout").open("w") as stdout, (out/"stderr").open("w") as stderr, (out/"gpu.csv").open("w") as samples:
        monitor = subprocess.Popen(["stdbuf","-oL","nvidia-smi","-i",GPU,
                                    "--query-gpu=timestamp,memory.used,utilization.gpu","--format=csv,noheader,nounits","-lms","100"],
                                   stdout=samples,env=ENV)
        try:
            started=time.monotonic()
            p = subprocess.run(["time","-o",out/"rss","-f","%M","timeout","-s","INT","-k","5s","115s",
                                "taskset","-c","0-3",*argv],env=env,cwd=cwd,stdout=stdout,stderr=stderr)
            wall=time.monotonic()-started
        finally:
            monitor.terminate()
            monitor.wait(timeout=5)
    if p.returncode:
        raise RuntimeError(f"{out}: exit {p.returncode}: {(out/'stdout').read_text()} / {(out/'stderr').read_text()}")
    samples=[(int(r[1]),int(r[2])) for r in csv.reader((out/"gpu.csv").open())]
    result={"wall_s":wall,"host_peak_mib":int((out/"rss").read_text().strip())/1024,
            "device_peak_mib":max(x[0] for x in samples),"gpu_samples":len(samples)}
    (out/"measurement.json").write_text(json.dumps(result)+"\n")
    return result


if __name__=="__main__":
    layout = ROOT/"layout"
    test_env = dict(ENV, PBRAIN_TEST_GEMMA2_PACK=PACKS["google"], PBRAIN_TEST_GEMMA2_Q8=PACKS["q8"],
                    PBRAIN_FP16_TRACE_DIR=str(layout/"actual"))
    result = run(layout/"actual",[layout/"gemma2.test","-test.run","^TestGemmaFP16ByteLayouts$","-test.v"],test_env,cwd=Path.cwd()/"internal/embed/gemma2")
    test = (layout/"actual/stdout").read_text()
    assert test.count("certified OOM split: 59 bit-identical vectors")==2,test
    print(json.dumps(dict(case="layout", **result)),flush=True)
    for row,pack in PACKS.items():
        for precision in ("fp32","fp16"):
            prefix=ROOT/"adapter"/f"{row}-{precision}"
            slice_env=dict(ENV, PBRAIN_TEST_GEMMA2_PACK=pack, PBRAIN_SLICE_ARM=row,
                PBRAIN_SLICE="/var/tmp/pbrain-sync-trace.NSKyVs/passages-200.json", PBRAIN_FP16_REPLAY_PRECISION=precision,
                PBRAIN_SLICE_DEVICE="cuda:"+GPU, PBRAIN_TRACE=str(prefix/"trace.jsonl"),
                PBRAIN_SLICE_IDS=str(prefix/"prepared-ids.tsv"))
            result = run(prefix,[ROOT/"adapter/slice.test","-test.run","^TestTraceSlice$","-test.v"],slice_env)
            trace = [json.loads(l) for l in (prefix/"trace.jsonl").read_text().splitlines()]
            forwards = [x for x in trace if x["span"]=="forward"]
            assert len(forwards)==13 and sum(x["inputs"] for x in forwards)==200
            assert sum(x["total_positions"] for x in forwards)==100066 and max(x["total_positions"] for x in forwards)<=8192
            assert all(x["device"]=="cuda:0" and not x.get("failed") for x in forwards)
            assert (prefix/"prepared-ids.tsv").read_bytes()==Path("/var/tmp/pbrain-sync-trace.NSKyVs/prepared-ids.tsv").read_bytes()
            measured=trace[-1]["spans"]
            result.update(row=row,precision=precision,positions_per_s=100066/(measured["slice_embed"]["ms"]/1000),
                          forward_positions_per_s=100066/(measured["forward"]["ms"]/1000),spans=measured)
            print(json.dumps(dict(case="adapter",**result)),flush=True)
