#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
binary=${1:-"$scratch/pbrain-arm64-fp16"}
case_dir="$scratch/arm64-smoke-release"
mkdir "$case_dir"
cd "$case_dir"
export CUDA_VISIBLE_DEVICES= GOMAXPROCS=2 PBRAIN_ALLOW_GEMMA2=1 PBRAIN_CACHE="$case_dir/cache" VK_DRIVER_FILES=/dev/null
unset PBRAIN_DEVICE PBRAIN_GPU_MEMORY PBRAIN_TRACE
pack=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
arm_lib="$scratch/arm64-libc/root/usr/lib/aarch64-linux-gnu"
run=(timeout -s INT -k 5s 115s taskset -c 4,5 qemu-aarch64 "$arm_lib/ld-linux-aarch64.so.1" --library-path "$arm_lib")
"${run[@]}" "$binary" --version
"${run[@]}" "$binary" devices --json >devices.json
jq -se 'length == 1 and ([.[0].devices[].id] == ["cpu"])' devices.json >/dev/null
"${run[@]}" "$binary" init
printf '[semantic]\nmodel = "embeddinggemma-2"\n' >docs/brain/pbrain.toml
printf 'model_path = %s\n' "$(jq -n --arg p "$pack" '$p')" >docs/brain/personal.toml
mkdir -p docs/brain/notes
cat >docs/brain/notes/smoke.md <<'NOTE'
---
kind: note
title: ARM64 GPU release smoke test
created: 2026-11-23T00:00:00Z
author: agent:ci
---
This release can sync without a GPU driver.
NOTE
"${run[@]}" "$binary" sync --json >sync.json 2>sync.stderr
jq -se 'length == 1 and .[0].model == "embeddinggemma-2" and
        (.[0].sections[0] | .device == "cpu" and .passages_embedded == 1)' sync.json >/dev/null
jq -Rn '[inputs | fromjson? | objects] | any(.notice.code == "cpu_fallback" and
        .notice.message == "embedding on the CPU, which is slow: no usable GPU was found")' sync.stderr | grep -qx true
cat devices.json sync.json sync.stderr docs/brain/.pbrain/index/manifest
