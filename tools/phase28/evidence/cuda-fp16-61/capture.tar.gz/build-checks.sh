#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
export GOMAXPROCS=2 CGO_ENABLED=0 CUDA_VISIBLE_DEVICES= VK_DRIVER_FILES=/dev/null VK_ICD_FILENAMES=/dev/null
unset PBRAIN_ALLOW_GEMMA2 PBRAIN_TEST_GEMMA2_PACK PBRAIN_TEST_GEMMA2_Q8 PBRAIN_TEST_GEMMA2_SOURCE PBRAIN_VULKAN_TEST_DEVICE PBRAIN_TRACE
taskset -c 4,5 go test -p 2 -count=1 -run 'TestIndexProfilesAcrossSyncs|TestManifestPrecisionMarker|TestManifestProfileMismatch|TestSyncPrecisionNoticeOnce|TestCUDAProfileFingerprints|TestCUDADriverImportBoundary|TestFP16CapabilitySelection|TestReleaseConfig|TestReadProjectSettings' ./internal/brain ./internal/buildcheck ./internal/cli ./internal/embed/gemma2 ./internal/semantic
GOOS=linux GOARCH=arm64 taskset -c 4,5 go build -p 2 -trimpath -ldflags '-s -w' -tags 'cuda eg2_combined eg2_fp16' -o "$scratch/pbrain-arm64-fp16" ./cmd/pbrain
GOOS=linux GOARCH=arm64 taskset -c 4,5 go vet -p 2 -tags 'cuda eg2_combined eg2_fp16' ./...
go version -m "$scratch/pbrain-arm64-fp16"
readelf -l "$scratch/pbrain-arm64-fp16"
timeout -s TERM -k 5s 20s taskset -c 4,5 qemu-aarch64 "$scratch/pbrain-arm64-fp16" --version
timeout -s TERM -k 5s 20s taskset -c 4,5 qemu-aarch64 "$scratch/pbrain-arm64-fp16" devices --json
