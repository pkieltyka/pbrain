"""Paired, bounded real pbrain syncs on a fixed subset of the #43 fixture."""
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import time

root = Path(__file__).resolve().parent
binary = root / "pbrain"
source = Path("/var/tmp/pbrain-phase28-bge-34.rb61v3/corpus/docs/brain")
models = {
    "google": ("embeddinggemma-2", "/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack"),
    "q8": ("embeddinggemma-2-q8-0", "/var/tmp/pbrain-sync-trace.NSKyVs/q8-model"),
}
date_sorted = sorted(p for p in source.rglob("*.md") if p.relative_to(source).parts[0] != "personal")
notes = [p.relative_to(source) for p in date_sorted[:22]]
digest = hashlib.sha256()
for note in notes:
    digest.update(os.fsencode(str(note)) + b"\0" + hashlib.sha256((source/note).read_bytes()).digest())
(root/"fixture.json").write_text(json.dumps({"source":str(source), "count":len(notes),
    "digested_path_sha256":digest.hexdigest(), "notes":[str(p) for p in notes]},indent=2)+"\n")
gpu = subprocess.check_output(["nvidia-smi","-i","0","--query-gpu=uuid","--format=csv,noheader"], text=True).strip()
env = dict(os.environ, GOMAXPROCS="4", PBRAIN_ALLOW_GEMMA2="1", CUDA_VISIBLE_DEVICES=gpu,
           LD_LIBRARY_PATH="/run/opengl-driver/lib", GIT_CONFIG_GLOBAL="/dev/null",
           GIT_CONFIG_NOSYSTEM="1", LC_ALL="C", TZ="UTC")
for key in ("PBRAIN_TRACE","PBRAIN_DEVICE","PBRAIN_GPU_MEMORY","PBRAIN_DIR","PBRAIN_BRAIN","GODEBUG","GOGC","GOMEMLIMIT"):
    env.pop(key,None)

def run(arm, precision, trial):
    model, model_path = models[arm]
    out = root / f"{arm}-{precision}-{trial}"
    out.mkdir()
    project = out / "project"
    project.mkdir()
    run_env = dict(env, PBRAIN_CACHE=str(out / "cache"))
    cli = ["taskset","-c","0-3",binary]
    subprocess.run(cli+["init"],cwd=project,env=run_env,check=True,capture_output=True)
    brain = project / "docs/brain"
    for note in notes:
        path = brain / note
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / note, path)
    (brain/"pbrain.toml").write_text(f'[semantic]\nmodel = "{model}"\ncuda_precision = "{precision}"\n')
    (brain/"personal.toml").write_text(f'model_path = "{model_path}"\n')
    with (out/"quiet.jsonl").open("w") as f:
        subprocess.run(["python3","/var/tmp/pbrain-q8-master84.MnCK65/quiet.py",
                        "--max-busy-pct","4","--attempts","60"],stdout=f,check=True)
    assert not subprocess.check_output(["nvidia-smi", "-i",gpu,"--query-compute-apps=pid","--format=csv,noheader"],text=True).strip()
    with (out/"preflight.txt").open("w") as f:
        print(Path("/proc/loadavg").read_text().strip(),file=f,flush=True)
        subprocess.run(["nvidia-smi","-i",gpu,"--query-gpu=name,memory.total,memory.free,driver_version",
                        "--format=csv,noheader"],stdout=f,check=True)
    run_env["PBRAIN_TRACE"] = str(out/"trace.jsonl")
    cmd = ["time","-o",str(out/"rss"),"-f","%M","timeout","-s","INT","-k","5s","115s",*cli,
           "sync","--device","cuda:"+gpu,"--json"]
    with (out/"gpu.csv").open("w") as samples, (out/"stdout").open("w") as stdout, (out/"stderr").open("w") as stderr:
        monitor = subprocess.Popen(["stdbuf","-oL","nvidia-smi","-i",gpu,
                                    "--query-gpu=timestamp,memory.used,utilization.gpu","--format=csv,noheader,nounits","-lms","100"],
                                   stdout=samples,env=run_env)
        try:
            t = time.monotonic()
            result = subprocess.run(cmd,cwd=project,env=run_env,stdout=stdout,stderr=stderr)
            wall = time.monotonic() - t
        finally:
            monitor.terminate()
            monitor.wait(timeout=5)
    if result.returncode != 0:
        raise RuntimeError(f"{out}: exit {result.returncode}\n{(out/'stderr').read_text()}")
    trace = [json.loads(line) for line in (out/"trace.jsonl").read_text().splitlines()]
    final = trace[-1]
    forwards = [e for e in trace if e["span"] == "forward"]
    stored = json.loads((out/"stdout").read_text())["sections"][0]
    assert stored["items"] == len(notes) and stored["passages_embedded"] == sum(e["inputs"] for e in forwards)
    assert all(e["device"] == "cuda:0" and not e.get("failed") and e["total_positions"]<=8192 for e in forwards)
    assert stored["passages_reused"] == 0 and final["model_opens"] == final["accelerator_attaches"] == 1
    assert "cuda_precision_fallback" not in (out/"stderr").read_text()
    index = brain/".pbrain/index"
    manifest = json.loads((index/"manifest").read_text())
    assert manifest.get("cuda_precision_request","fp32") == precision
    positions = sum(e["total_positions"] for e in forwards)
    assert positions > 0
    with (out/"gpu.csv").open() as f:
        gpu_peak = max(int(r[1]) for r in csv.reader(f))
    result = {"row":arm, "precision":precision, "trial":trial,"wall_s":wall,"positions":positions,
              "passages":stored["passages_embedded"], "positions_per_s":positions/wall,
              "passages_per_s":stored["passages_embedded"]/wall,"rss_mib":int((out/"rss").read_text().strip())/1024,
              "device_peak_mib":gpu_peak, "manifest":manifest, "forwards":len(forwards),
              "spans":final["spans"],"fixture_sha256":digest.hexdigest()}
    (out/"summary.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result),flush=True)
    return result

if __name__ == "__main__":
    assert (root/"writer-ready").is_file()
    results = []
    for trial in (1,2):
        for arm in models:
            for precision in (("fp32","fp16") if trial == 1 else ("fp16","fp32")):
                results.append(run(arm, precision, trial))
    for arm in models:
        fmt = {p:statistics.median(r["positions_per_s"] for r in results if r["row"]==arm and r["precision"]==p)
               for p in ("fp32","fp16")}
        assert len({(r["positions"],r["passages"]) for r in results if r["row"]==arm}) == 1
        assert len({r["manifest"]["fingerprint"] for r in results if r["row"]==arm}) == 2
        print(json.dumps({"row":arm, "paired_positions_per_s":fmt, "speedup":fmt["fp16"]/fmt["fp32"]}),flush=True)
