"""Record prepared call shapes and the last admission estimate per shape."""
import json
from pathlib import Path
import sys

scratch = Path(__file__).resolve().parent
pkg = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(exist_ok=True)
replace = {str(pkg / "matched_test.go"): str(scratch / "matched_test.go")}
for name in ("gemma2.go", "batch.go"):
    source = (pkg / name).read_text()
    if name == "gemma2.go":
        forward, ids = "v, err := e.model.EmbedIDs(ids)", "[][]int{ids}"
    elif "vectors, err := e.model.EmbedIDsBatch(ids)" in source:
        forward, ids = "vectors, err := e.model.EmbedIDsBatch(ids)", "ids"
        probe = "memory, err := estimate(lengths[:i+1])"
        assert source.count(probe) == 1
        source = source.replace(probe, f"{probe}\nestimate56(i+1, memory)")
    else:
        forward, ids = "vs, err := e.model.EmbedIDsBatch(ids[:n])", "ids[:n]"
    assert source.count(forward) == 1
    source = source.replace('"context"\n', '"context"\n"time"\n')
    source = source.replace(forward, f"start56 := time.Now()\n{forward}\nrecord56({ids}, time.Since(start56), err)")
    dest = out / name
    dest.write_text(source)
    replace[str(pkg / name)] = str(dest)
print(json.dumps({"Replace": replace}))
