#!/usr/bin/env bash
set -euo pipefail
d=$(dirname "$(realpath "$0")")
stage="$d/amd"
repo=$PWD
jq -se 'last.phase=="result" and last.exit==-2 and last.stop_reason==null and last.peak_share_bytes<4294967296' \
    "$stage/partial/capture/vram.jsonl"
python3 "$d/export-checkpoint.py" "$stage/partial" "$stage/checkpoint.json"
cd "$repo/internal/embed/gemma2"
python3 "$d/quiet.py" --max-busy-pct 5 --attempts 24 > "$stage/checkpoint-cpu-quiet.jsonl"
nvidia-smi --query-gpu=uuid,name,driver_version,memory.used,memory.free,utilization.gpu --format=csv > "$stage/checkpoint-cpu-nvidia.csv"
export PBRAIN_ALLOW_GEMMA2=1 PBRAIN_TEST_GEMMA2_PACK=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
export GOMAXPROCS=32 CUDA_VISIBLE_DEVICES="" PBRAIN_56_CHECKPOINT="$stage/checkpoint.json"
export PBRAIN_56_OUT="$stage/checkpoint-cpu-summary.json"
unset PBRAIN_DEVICE PBRAIN_GPU_MEMORY GOGC GOMEMLIMIT
timeout -k 10s 650s taskset -c 0-31 "$d/candidate/checkpoint.test" \
    -test.v -test.run '^TestRadeonCheckpoint56$' -test.timeout=640s > "$stage/checkpoint-cpu.log" 2>&1
grep -q '^--- PASS: TestRadeonCheckpoint56 ' "$stage/checkpoint-cpu.log"
touch "$d/amd.complete"
