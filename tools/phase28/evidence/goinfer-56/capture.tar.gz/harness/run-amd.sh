#!/usr/bin/env bash
set -euo pipefail
d=$(dirname "$(realpath "$0")")
repo=$PWD
card=/sys/bus/pci/devices/0000:0c:00.0
[[ $(cat "$card/device") == 0x7590 ]]
export LD_LIBRARY_PATH=/nix/store/1l0a4cq8ahhpgwx0byq2zcsi316mlzm1-vulkan-loader-1.4.363.0/lib:/run/opengl-driver/lib
export PBRAIN_TEST_GEMMA2_PACK=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
export PBRAIN_ALLOW_GEMMA2=1 LC_ALL=C TZ=UTC GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_NOSYSTEM=1
export PBRAIN_56_SLICE="$d/fixture-passages.json"
unset VK_DRIVER_FILES VK_ICD_FILENAMES DRI_PRIME PBRAIN_DEVICE PBRAIN_BRAIN PBRAIN_DIR PBRAIN_GPU_MEMORY GOGC GOMEMLIMIT GOMAXPROCS
stage="$d/amd"
mkdir "$stage"
quiet() {
    python3 "$d/quiet.py" --max-busy-pct 5 --attempts 24 > "$stage/$1-quiet.jsonl"
    nvidia-smi --query-gpu=uuid,name,driver_version,memory.used,memory.free,utilization.gpu --format=csv > "$stage/$1-nvidia.csv"
}
quiet devices
CUDA_VISIBLE_DEVICES=$(nvidia-smi -i 0 --query-gpu=uuid --format=csv,noheader) \
    python3 "$d/amd-guard.py" --discovery-only --seconds 30 "$card" "$stage/discovery" \
    "$d/candidate/pbrain-dual" devices --json
jq -e '(.devices|length) == 3 and
    (.devices[0] | .backend=="cuda" and .memory=="live" and .memory_kind=="dedicated") and
    (.devices[1] | .backend=="vulkan" and .memory=="estimated" and .memory_kind=="dedicated") and
    .devices[2].id == "cpu"' "$stage/discovery/stdout"
id=$(jq -er '.devices[]|select(.backend=="vulkan")|.persistent' "$stage/discovery/stdout")
export PBRAIN_TEST_VULKAN_DEVICE="$id"
cd "$repo/internal/embed/gemma2"
quiet layouts
python3 "$d/amd-guard.py" --seconds 300 --budget-mib 1024 "$card" "$stage/layouts" \
    "$d/candidate/matched.test" -test.v -test.run '^TestGemmaVulkan$' -test.timeout=290s
grep -q '^--- PASS: TestGemmaVulkan ' "$stage/layouts/stdout"

quiet slice
PBRAIN_56_DEVICE="$id" PBRAIN_56_OUT="$stage/vulkan-slice.json" \
    python3 "$d/amd-guard.py" --default-workers --seconds 300 --budget-mib 1024 "$card" "$stage/slice" \
    "$d/candidate/matched.test" -test.v -test.run '^TestMatchedSlice56$' -test.timeout=290s
grep -q '^--- PASS: TestMatchedSlice56 ' "$stage/slice/stdout"
quiet slice-cpu
CUDA_VISIBLE_DEVICES="" PBRAIN_56_DEVICE="" PBRAIN_56_OUT="$stage/cpu-slice.json" \
    timeout -k 10s 600s "$(command -v time)" -f 'wall %e s; peak RSS KiB %M' -o "$stage/cpu-slice.time" \
    "$d/candidate/matched.test" -test.v -test.run '^TestMatchedSlice56$' -test.timeout=590s > "$stage/cpu-slice.log" 2>&1
grep -q '^--- PASS: TestMatchedSlice56 ' "$stage/cpu-slice.log"
python3 "$d/check-slice.py" "$stage"

mkdir "$stage/partial"
python3 - "$stage/partial" <<'PY'
from pathlib import Path
import sys
sys.path.insert(0, "/var/tmp/pbrain-sync-43.XW3O3B")
from measure import prepare
prepare(Path(sys.argv[1]), "gemma", "2cbd38cde77fdc6f1d67949e50efd40d261d9f0a79d6bda5a759a854218db490")
PY
cd "$stage/partial/corpus"
export PBRAIN_CACHE="$stage/partial/cache"
quiet partial
python3 "$d/amd-guard.py" --interrupt-at-bound --seconds 1800 --budget-mib 1024 "$card" "$stage/partial/capture" \
    "$d/candidate/pbrain-dual" --personal sync --device "$id" --json
python3 "$d/export-checkpoint.py" "$stage/partial" "$stage/checkpoint.json"
cd "$repo/internal/embed/gemma2"
quiet checkpoint-cpu
CUDA_VISIBLE_DEVICES="" PBRAIN_56_CHECKPOINT="$stage/checkpoint.json" PBRAIN_56_OUT="$stage/checkpoint-cpu-summary.json" \
    timeout -k 10s 1800s "$d/candidate/checkpoint.test" -test.v -test.run '^TestRadeonCheckpoint56$' -test.timeout=1790s > "$stage/checkpoint-cpu.log" 2>&1
grep -q '^--- PASS: TestRadeonCheckpoint56 ' "$stage/checkpoint-cpu.log"
touch "$d/amd.complete"
