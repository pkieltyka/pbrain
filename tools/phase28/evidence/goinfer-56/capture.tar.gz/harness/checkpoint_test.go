package gemma2

import (
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/pkieltyka/pbrain/internal/embed"
	"github.com/pkieltyka/pbrain/internal/item"
	"github.com/pkieltyka/pbrain/internal/semantic"
)

func TestRadeonCheckpoint56(t *testing.T) {
	source := os.Getenv("PBRAIN_56_CHECKPOINT")
	if source == "" {
		t.Skip("set PBRAIN_56_CHECKPOINT")
	}
	raw, err := os.ReadFile(source)
	if err != nil {
		t.Fatal(err)
	}
	var input struct {
		Brain    string
		Passages []struct {
			Path    string
			Ordinal int
			Digest  string
			Vector  []byte
		}
	}
	if err := json.Unmarshal(raw, &input); err != nil || len(input.Passages) < 200 {
		t.Fatalf("invalid checkpoint export: %d passages, %v", len(input.Passages), err)
	}
	entry := Entry()
	pack := fixtureDir(t, "PBRAIN_TEST_GEMMA2_PACK")
	cpu, err := embed.NewRegistry(entry).Open(t.Context(), verified(t, pack, entry.Model), embed.OpenOptions{})
	if err != nil {
		t.Fatal(err)
	}
	defer cpu.Close()
	if cpu.Info().Device != "cpu" {
		t.Fatalf("expected CPU, got %+v", cpu.Info())
	}
	worst, sameBits, below := 1.0, 0, 0
	var prepared []semantic.Passage
	var last string
	var vectors []byte
	for i, row := range input.Passages {
		if row.Path != last {
			path := filepath.Join(input.Brain, row.Path)
			body, err := os.ReadFile(path)
			if err != nil {
				t.Fatal(err)
			}
			header, off, _, err := item.Parse(strings.TrimSuffix(filepath.Base(path), ".md"), body)
			if err != nil {
				t.Fatal(err)
			}
			prepared = semantic.Passages(header.Title, body[off:])
			last = row.Path
		}
		if row.Ordinal < 0 || row.Ordinal >= len(prepared) || len(row.Vector) != dimension*4 {
			t.Fatalf("invalid passage %s/%d", row.Path, row.Ordinal)
		}
		p := prepared[row.Ordinal]
		if hex.EncodeToString(p.Digest[:]) != row.Digest {
			t.Fatalf("source passage digest changed %s/%d", row.Path, row.Ordinal)
		}
		got, err := cpu.Embed(t.Context(), embed.Document, []string{p.Text})
		if err != nil || len(got) != 1 || len(got[0]) != dimension {
			t.Fatalf("CPU embed %s/%d: %v", row.Path, row.Ordinal, err)
		}
		stored := make([]float32, dimension)
		for j := range stored {
			stored[j] = math.Float32frombits(binary.LittleEndian.Uint32(row.Vector[4*j:]))
			vectors = binary.LittleEndian.AppendUint32(vectors, math.Float32bits(got[0][j]))
		}
		if sameVectorBits(got[0], stored) {
			sameBits++
		}
		c := min(similarity(got[0], stored), similarity(got[0][:512], stored[:512]))
		if !(c >= .999) {
			below++
		}
		worst = min(worst, c)
		if (i+1)%100 == 0 {
			t.Logf("checked %d/%d", i+1, len(input.Passages))
		}
	}
	result, err := json.Marshal(map[string]any{
		"passages": len(input.Passages), "minimum_cosine": worst, "exact_bits": sameBits,
		"below_0_999": below, "cpu_vectors": vectors,
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(os.Getenv("PBRAIN_56_OUT"), result, 0o600); err != nil {
		t.Fatal(err)
	}
	t.Logf("%d checkpointed vectors: minimum cosine %.15f, %d exact, %d below .999",
		len(input.Passages), worst, sameBits, below)
	if below != 0 {
		t.Fatal("checkpoint vector parity failed")
	}
}
