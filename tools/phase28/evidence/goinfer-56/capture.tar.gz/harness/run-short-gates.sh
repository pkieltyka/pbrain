#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
cd internal/embed/gemma2
export GOMAXPROCS=4 PBRAIN_ALLOW_GEMMA2=1 LD_LIBRARY_PATH=/run/opengl-driver/lib
export PBRAIN_TEST_GEMMA2_PACK=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
PBRAIN_TEST_GEMMA2_Q8=$(cat /var/tmp/pbrain-q8-51.J0ZPn4/model-root)/q8
export PBRAIN_TEST_GEMMA2_Q8
unset PBRAIN_DEVICE PBRAIN_GPU_MEMORY GOGC GOMEMLIMIT
uuid=$(nvidia-smi -i 0 --query-gpu=uuid --format=csv,noheader)
preflight() {
    printf '%s %s\n' "$(date --iso-8601=seconds)" "$1"
    cat /proc/loadavg
    nvidia-smi -i "$uuid" --query-gpu=uuid,name,driver_version,memory.free,utilization.gpu --format=csv
    [[ -z $(nvidia-smi -i "$uuid" --query-compute-apps=pid --format=csv,noheader) ]]
    python3 "$scratch/quiet.py" --max-busy-pct 5 --attempts 24
}

preflight cpu-parity
CUDA_VISIBLE_DEVICES="" timeout 200s taskset -c 0-3 "$scratch/candidate/gemma2-cpu.test" \
    -test.run '^(TestGemmaParity|TestGemmaQ8Preparation)$' -test.v -test.timeout=190s
preflight cuda-bytes
CUDA_VISIBLE_DEVICES="$uuid" timeout 240s taskset -c 0-3 "$scratch/candidate/gemma2-cuda.test" \
    -test.run '^(TestGemmaBatchSameBytes|TestGemmaQ8CUDAByteLayouts|TestGemmaCUDAForcedSplitSameBytes)$' -test.v -test.timeout=230s
cat "$PBRAIN_TEST_GEMMA2_Q8/embeddinggemma-2-Q8_0.gguf" >/dev/null
for i in 1 2 3 4 5; do
    preflight "Q8 rule 3 CPU sample $i"
    CUDA_VISIBLE_DEVICES="" timeout 75s taskset -c 0-3 "$(command -v time)" -f 'peak RSS KiB %M' \
        "$scratch/candidate/gemma2-cpu.test" -test.run '^$' -test.bench '^BenchmarkGemmaQ8FirstQuery$' -test.benchtime=1x -test.count=1
done
touch "$scratch/short-gates.complete"
