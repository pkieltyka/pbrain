#!/usr/bin/env bash
set -euo pipefail
d=$(dirname "$(realpath "$0")")
[[ $(git rev-parse HEAD) == "$(cat "$d/candidate-revision")" ]]
export GOMAXPROCS=4 CGO_ENABLED=0
unset PBRAIN_ALLOW_GEMMA2 PBRAIN_TEST_GEMMA2_PACK PBRAIN_TEST_GEMMA2_Q8 PBRAIN_TEST_VULKAN_DEVICE
export CUDA_VISIBLE_DEVICES=""
for tags in '' cuda vulkan cuda,vulkan; do
    taskset -c 4-7 go vet -p 2 -tags "$tags" ./internal/embed/gemma2 ./internal/semantic ./internal/cli
    taskset -c 4-7 go test -p 2 -count=1 -tags "$tags" ./internal/embed/gemma2 ./internal/semantic ./internal/cli
    CGO_ENABLED=1 taskset -c 4-7 go test -race -p 2 -count=1 -tags "$tags" ./internal/embed/gemma2 ./internal/semantic ./internal/cli
done
GOOS=linux GOARCH=arm64 taskset -c 4-7 go build -p 2 -trimpath -tags cuda -o "$d/candidate/pbrain-linux-arm64" ./cmd/pbrain
GOOS=linux GOARCH=arm64 taskset -c 4-7 go vet -p 2 -tags cuda ./...
taskset -c 4-7 go mod verify
taskset -c 4-7 go test -p 2 -count=1 -v -run '^TestRuntimeEnvAndOutput$' ./internal/embed/bge

taskset -c 4-7 go test -p 2 -trimpath -tags cuda -c -o "$d/candidate/gemma2-cuda.test" ./internal/embed/gemma2
python3 "$d/slice-overlay.py" "$PWD/internal/embed/gemma2" "$d/candidate/instrumented" > "$d/candidate/overlay.json"
taskset -c 4-7 go test -p 2 -trimpath -tags cuda,vulkan -c -overlay="$d/candidate/overlay.json" -o "$d/candidate/matched.test" ./internal/embed/gemma2
taskset -c 4-7 go test -p 2 -trimpath -c -overlay="$d/checkpoint-overlay.json" -o "$d/candidate/checkpoint.test" ./internal/embed/gemma2
taskset -c 4-7 go build -p 2 -trimpath -ldflags '-s -w' -o "$d/candidate/pbrain-cpu" ./cmd/pbrain
taskset -c 4-7 go build -p 2 -trimpath -tags cuda,vulkan -ldflags '-s -w' -o "$d/candidate/pbrain-dual" ./cmd/pbrain
python3 "$d/storage-overlay.py" "$PWD/internal/embed/gemma2/batch.go" "$d/batch-forced.go" > "$d/storage-overlay.json"
taskset -c 4-7 go build -p 2 -trimpath -tags cuda,vulkan -overlay="$d/storage-overlay.json" -o "$d/candidate/pbrain-forced" ./cmd/pbrain
go version -m "$d/candidate/"{pbrain-cpu,pbrain-dual,gemma2-cuda.test,matched.test,checkpoint.test} > "$d/capped-build-info.log"
sha256sum "$d/candidate/"{pbrain-cpu,pbrain-dual,gemma2-cuda.test,matched.test,checkpoint.test,pbrain-forced} > "$d/capped-binary-sha256"
wc -c "$d"/{parent,pin,candidate}/pbrain-{cpu,dual} > "$d/capped-sizes.log"
touch "$d/capped-build.complete"
bash "$d/run-capped-cuda.sh" > "$d/capped-cuda.log" 2>&1
! grep -q -- '--- SKIP:' "$d/capped-cuda.log"
grep -q '^--- PASS: TestGemmaCUDAForcedSplitSameBytes ' "$d/capped-cuda.log"
touch "$d/capped-cuda.complete"

bash "$d/run-cuda-slices.sh" > "$d/slices.log" 2>&1
python3 "$d/quiet.py" --max-busy-pct 5 --attempts 24 > "$d/storage-quiet.jsonl"
python3 "$d/sync-storage.py" "$d" > "$d/storage-summary.json"
test -s "$d/storage-summary.json"
touch "$d/storage.complete"
bash "$d/run-amd.sh" > "$d/amd.log" 2>&1
