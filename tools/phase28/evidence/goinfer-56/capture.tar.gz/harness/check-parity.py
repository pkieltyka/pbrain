"""Compare each device's prepared vectors with the qualified same-file reference."""
import json
import math
from pathlib import Path
import sys

root = Path(sys.argv[1])

def cosine(x, y, n):
    a, b = x[:n], y[:n]
    return min(1.0, math.fsum(u*v for u,v in zip(a,b,strict=True)) /
               math.sqrt(math.fsum(u*u for u in a)*math.fsum(v*v for v in b)))

def vecs(model, device):
    path = root / "parity" / f"{model}-{device}" / "vectors.jsonl"
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    assert len(rows) == 81
    return {row["key"]: row for row in rows}

google = json.loads(Path(sys.argv[2]).read_text())
q8 = {row["id"]: row["vector"] for row in json.loads((root/"reference.json").read_text())["rows"]}
q8ids = {k: list(map(int, ids.split())) for k, _, ids in
         (line.split("\t") for line in (root/"prepared.tsv").read_text().splitlines())}
all_summary = {}
for model in ("google", "q8"):
    cpu, cuda = [vecs(model, d) for d in ("cpu","cuda")]
    assert cpu.keys() == cuda.keys()
    cross = []
    same = {"cpu": [], "cuda": []}
    for key, row in cpu.items():
        assert row["ids"] == cuda[key]["ids"]
        if key.startswith("small/"):
            cross.extend(cosine(row["vector"], cuda[key]["vector"], n) for n in (512,768))
        if model == "q8":
            assert row["ids"] == q8ids[key]
            ref = q8[key]
        elif key.startswith("reference/"):
            g = google[int(key.split("/")[1])]
            assert row["ids"] == g.get("prepared_ids", g["ids"])
            ref = g.get("prepared_vector", g["vector"])
        else:
            continue
        for n in (512,768):
            for dev, rows in (("cpu",cpu), ("cuda",cuda)):
                same[dev].append(cosine(rows[key]["vector"], ref, n))
    assert len(cross) == 118 and all(len(v) == (44 if model == "google" else 162) for v in same.values())
    assert all(value >= .999 for values in [cross,*same.values()] for value in values)
    all_summary[model] = {"pairs": len(cross)//2, "cpu_cuda_minimum": min(cross),
                          "same_file_comparisons_per_device": len(same["cpu"]),
                          "same_file_minimum": {d:min(v) for d,v in same.items()}}
print(json.dumps(all_summary, indent=2))
(root/"parity-summary.json").write_text(json.dumps(all_summary, indent=2)+"\n")
