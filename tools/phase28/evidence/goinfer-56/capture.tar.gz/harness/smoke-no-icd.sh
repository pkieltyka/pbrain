#!/usr/bin/env bash
set -euo pipefail
d=$(dirname "$(realpath "$0")")
case_dir="$d/no-icd"
mkdir "$case_dir"
binary="$d/candidate/pbrain-release-fix"
brain="$case_dir/brain"
mkdir -p "$brain/notes"
printf 'semantic.model = "embeddinggemma-2"\n' > "$brain/pbrain.toml"
printf 'model_path = "/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack"\n' > "$brain/personal.toml"
cat > "$brain/notes/session-storage.md" <<'NOTE'
---
kind: note
title: Session storage
created: 2026-01-01T00:00:00Z
author: agent:test
---

Authenticated sessions persist in Redis under their session keys.
NOTE
export PBRAIN_ALLOW_GEMMA2=1 GOMAXPROCS=4 CUDA_VISIBLE_DEVICES=""
unset PBRAIN_DEVICE PBRAIN_GPU_MEMORY PBRAIN_BRAIN PBRAIN_DIR VK_ICD_FILENAMES DRI_PRIME
export PBRAIN_CACHE="$case_dir/cache"
export LD_LIBRARY_PATH=/nix/store/1l0a4cq8ahhpgwx0byq2zcsi316mlzm1-vulkan-loader-1.4.363.0/lib:/run/opengl-driver/lib
export VK_DRIVER_FILES="$case_dir/missing-icd.json"
test ! -e "$VK_DRIVER_FILES"
go version -m "$binary" > "$case_dir/build-info.log"
timeout -k 10s 25s taskset -c 0-3 "$binary" devices --json > "$case_dir/devices.json" 2> "$case_dir/devices.stderr"
jq -e '.devices|length == 1 and .[0].id == "cpu"' "$case_dir/devices.json"
timeout -k 10s 60s taskset -c 0-3 "$binary" --brain "$brain" sync --device auto --json \
    > "$case_dir/sync.json" 2> "$case_dir/sync.stderr"
jq -e '.sections|length == 1 and .[0].device == "cpu" and .[0].passages_embedded == 1' "$case_dir/sync.json"
jq -se 'map(select(.notice.code == "cpu_fallback")) | length == 1 and
    (.[0].notice.message|contains("no usable GPU was found"))' \
    <(sed -n '/^{/p' "$case_dir/sync.stderr")
touch "$d/no-icd.complete"
