#!/usr/bin/env bash
set -euo pipefail
d=$(dirname "$(realpath "$0")")
cd internal/embed/gemma2
export GOMAXPROCS=4 PBRAIN_ALLOW_GEMMA2=1 LD_LIBRARY_PATH=/run/opengl-driver/lib
export PBRAIN_TEST_GEMMA2_PACK=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
PBRAIN_TEST_GEMMA2_Q8=$(cat /var/tmp/pbrain-q8-51.J0ZPn4/model-root)/q8
CUDA_VISIBLE_DEVICES=$(nvidia-smi -i 0 --query-gpu=uuid --format=csv,noheader)
export PBRAIN_TEST_GEMMA2_Q8 CUDA_VISIBLE_DEVICES
unset PBRAIN_DEVICE PBRAIN_GPU_MEMORY GOGC GOMEMLIMIT
date --iso-8601=seconds
cat /proc/loadavg
nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-gpu=uuid,name,driver_version,memory.free,utilization.gpu --format=csv
[[ -z $(nvidia-smi -i "$CUDA_VISIBLE_DEVICES" --query-compute-apps=pid --format=csv,noheader) ]]
python3 "$d/quiet.py" --max-busy-pct 5 --attempts 24
timeout -k 10s 240s taskset -c 0-3 "$d/candidate/gemma2-cuda.test" \
    -test.run '^(TestGemmaBatchSameBytes|TestGemmaQ8CUDAByteLayouts|TestGemmaCUDAForcedSplitSameBytes)$' -test.v -test.timeout=230s
