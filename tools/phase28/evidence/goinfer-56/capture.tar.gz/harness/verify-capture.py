"""Check extracted storage bytes and checkpoint cosine against the raw vectors."""
import base64
import hashlib
import json
import math
import random
import sqlite3
import struct
import sys
from pathlib import Path

capture = Path(sys.argv[1]).resolve()
matrix = json.loads((capture/"storage-summary.json").read_text())
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
for case, result in matrix.items():
    dest = capture/"storage"/case
    cache = dest/"cache/vectors"
    actual = {str(p.relative_to(cache)):sha(p) for p in cache.rglob("*") if p.is_file()}
    assert actual == result["cache"], case
    for section in ("shared","personal"):
        brain = dest/"brain"
        if section == "personal":
            brain /= "personal"
        index = brain/".pbrain/index"
        manifest = json.loads((index/"manifest").read_text())
        db = index/manifest["db"]
        checks = result["db"][section]
        assert sha(db) == checks["sha256"], (case, section)
        with sqlite3.connect(db.as_uri()+"?mode=ro&immutable=1",uri=True) as conn:
            assert conn.execute("PRAGMA quick_check").fetchall() == [("ok",)]
            for table, key in (("meta","key"),("item","path"),("passage","item_id, ord")):
                rows = conn.execute(f"SELECT * FROM {table} ORDER BY {key}").fetchall()
                assert len(rows) == checks["tables"][table]["rows"]
                assert hashlib.sha256(repr(rows).encode()).hexdigest() == checks["tables"][table]["digest"]
            if section == "personal":
                digest, = conn.execute(
                    "SELECT lower(hex(p.digest)) FROM passage p JOIN item i ON p.item_id=i.id WHERE i.path='notes/h-private.md'").fetchone()
                assert all(Path(path).name != digest for path in actual), case
        print(case, section, len(actual), checks["sha256"])
amd = capture/"amd"
checkpoint = json.loads((amd/"checkpoint.json").read_text())
db = amd/"checkpoint-db"/checkpoint["manifest"]["db"]
assert checkpoint["manifest"] == json.loads((db.parent/"manifest").read_text())
assert sha(db) == checkpoint["db_sha256"]
with sqlite3.connect(db.as_uri()+"?mode=ro&immutable=1",uri=True) as conn:
    assert conn.execute("PRAGMA quick_check").fetchall() == [("ok",)]
    count, = conn.execute("SELECT count(*) FROM passage").fetchone()
    assert count == checkpoint["complete_checkpoint_passages"]
    rows = conn.execute(
        "SELECT i.path, p.ord, p.digest, p.vector FROM passage p JOIN item i ON p.item_id=i.id ORDER BY i.path,p.ord LIMIT ?",
        (checkpoint["sampling_population"],),
    ).fetchall()
indices = sorted(random.Random(checkpoint["sampling_seed"]).sample(range(len(rows)),500))
assert indices == checkpoint["sample_indices"]
gpu = checkpoint["passages"]
for i, r in zip(indices,gpu,strict=True):
    path, ordinal, digest, vector = rows[i]
    assert (path,ordinal,digest,vector) == (r["path"],r["ordinal"],bytes.fromhex(r["digest"]),base64.b64decode(r["vector"]))
cpu = json.loads((amd/"checkpoint-cpu-summary.json").read_text())
payload = base64.b64decode(cpu["cpu_vectors"])
assert len(payload) == len(gpu)*768*4 == cpu["passages"]*768*4
low = 1.0
same = 0
for n,row in enumerate(gpu):
    gpu_bits = base64.b64decode(row["vector"])
    cpu_bits = payload[n*3072:(n+1)*3072]
    same += gpu_bits == cpu_bits
    a,b = (struct.unpack("<768f",v) for v in (gpu_bits,cpu_bits))
    for dims in (512,768):
        x,y = a[:dims],b[:dims]
        dot = math.fsum(u*v for u,v in zip(x,y,strict=True))
        cosine = dot/math.sqrt(math.fsum(u*u for u in x)*math.fsum(v*v for v in y))
        assert cosine >= .999, (row["path"], row["ordinal"], cosine)
        low = min(low,cosine)
assert same == cpu["exact_bits"]
assert math.isclose(low,cpu["minimum_cosine"],rel_tol=1e-14)
print(f"checkpoint: {len(gpu)} passages, minimum {low:.15f}, {same} exact bit matches")
