"""Inject one certified failure per real candidate encoder, before dispatch."""
import json
from pathlib import Path
import sys
src = Path(sys.argv[1])
out = Path(sys.argv[2])
source = src.read_text()
source = source.replace('"fmt"\n', '"fmt"\n"os"\n')
statement = "vectors, err := e.model.EmbedIDsBatch(ids)"
assert source.count(statement) == 1
source = source.replace(statement, """var vectors [][]float32
var err error
if e.retryLimit == nil {
    trace, traceErr := os.OpenFile(os.Getenv("PBRAIN_56_FORCE_TRACE"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
    if traceErr != nil { return traceErr }
    _, traceErr = fmt.Fprintf(trace, "forced certified OOM before dispatch for %d inputs\n", len(ids))
    if closeErr := trace.Close(); closeErr != nil { return closeErr }
    if traceErr != nil { return traceErr }
    err = embeddinggemma2.ErrBatchOutOfMemory
} else {
    vectors, err = e.model.EmbedIDsBatch(ids)
}""".replace("inputs\n", "inputs\\n"))
out.write_text(source)
print(json.dumps({"Replace": {str(src): str(out)}}))
