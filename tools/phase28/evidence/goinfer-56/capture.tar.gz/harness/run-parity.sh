#!/usr/bin/env bash
set -euo pipefail
d=$(dirname "$(realpath "$0")")
repo=$PWD
export GOMAXPROCS=4 PBRAIN_ALLOW_GEMMA2=1 PBRAIN_EVAL_SAME_FILE=1
export PBRAIN_EVAL_SMALL_PATHS="$repo/tools/phase28/evidence/gemma-pax-22/fixture-paths.txt"
export PBRAIN_EVAL_SMALL_ROOT=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/small-cpu/docs/brain
export PBRAIN_EVAL_SLICE_ROOT=/var/tmp/pbrain-sync-throughput.yqF3OJ/bge-corpus/docs/brain
export PBRAIN_EVAL_SLICE_PATHS=/var/tmp/pbrain-sync-throughput.yqF3OJ/fixture-files.txt
export LD_LIBRARY_PATH=/run/opengl-driver/lib
unset PBRAIN_DEVICE PBRAIN_GPU_MEMORY GOGC GOMEMLIMIT
gpu=$(nvidia-smi -i 0 --query-gpu=uuid --format=csv,noheader)
cd "$repo/internal/embed/gemma2"
for model in google q8; do
    case "$model" in
        google)
            export PBRAIN_EVAL_MODEL=embeddinggemma-2
            export PBRAIN_TEST_GEMMA2_PACK=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
            ;;
        q8)
            export PBRAIN_EVAL_MODEL=embeddinggemma-2-q8-0
            PBRAIN_TEST_GEMMA2_PACK=$(cat /var/tmp/pbrain-q8-51.J0ZPn4/model-root)/q8
            export PBRAIN_TEST_GEMMA2_PACK
            ;;
    esac
    for device in cpu cuda; do
        visible= selector=
        if [[ $device == cuda ]]; then visible=$gpu selector=cuda:0; fi
        out="$d/parity/$model-$device"
        mkdir -p "$out"
        python3 "$d/quiet.py" --max-busy-pct 5 --attempts 24 > "$out/quiet.jsonl"
        nvidia-smi -i "$gpu" --query-gpu=uuid,name,driver_version,memory.used,memory.free,utilization.gpu --format=csv > "$out/preflight.csv"
        CUDA_VISIBLE_DEVICES="$visible" PBRAIN_EVAL_DEVICE="$selector" PBRAIN_EVAL_DUMP="$out/vectors.jsonl" \
            timeout -k 10s 180s taskset -c 0-3 "$d/candidate/parity.test" \
            -test.v -test.run '^TestGemmaEvalVectors$' -test.timeout=170s > "$out/stdout" 2> "$out/stderr"
        grep -q '^--- PASS: TestGemmaEvalVectors ' "$out/stdout"
    done
done
python3 "$d/check-parity.py" "$d" "$repo/internal/embed/gemma2/testdata/reference.json"
touch "$d/parity.complete"
