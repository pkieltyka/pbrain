#!/usr/bin/env bash
set -euo pipefail
scratch=$(dirname "$(realpath "$0")")
export PBRAIN_56_SLICE="$scratch/fixture-passages.json"
export PBRAIN_ALLOW_GEMMA2=1 PBRAIN_TEST_GEMMA2_PACK=/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack
export LD_LIBRARY_PATH=/run/opengl-driver/lib
uuid=$(nvidia-smi -i 0 --query-gpu=uuid --format=csv,noheader)
export CUDA_VISIBLE_DEVICES="$uuid"
export PBRAIN_56_DEVICE="cuda:$uuid"
unset GOMAXPROCS PBRAIN_GPU_MEMORY PBRAIN_DEVICE GOGC GOMEMLIMIT
cd internal/embed/gemma2

run() {
    local variant=$1 mode=$2 label=$3 sampler ec=0
    local out="$scratch/slices/$label"
    if [[ $variant == pin ]]; then export PBRAIN_56_DEVICE=cuda:0; else export PBRAIN_56_DEVICE="cuda:$uuid"; fi
    mkdir -p "$out"
    if [[ $mode == narrow ]]; then export PBRAIN_GPU_MEMORY=1024; else unset PBRAIN_GPU_MEMORY; fi
    export PBRAIN_56_OUT="$out/result.json"
    python3 "$scratch/quiet.py" --max-busy-pct 5 --attempts 24 > "$out/quiet.jsonl"
    if [[ -n $(nvidia-smi -i "$uuid" --query-compute-apps=pid --format=csv,noheader) ]]; then
        printf 'NVIDIA already in use\n' >&2
        return 1
    fi
    nvidia-smi -i "$uuid" --query-gpu=uuid,name,driver_version,memory.used,memory.free,utilization.gpu --format=csv > "$out/preflight.csv"
    stdbuf -oL nvidia-smi -i "$uuid" --query-gpu=timestamp,memory.used,utilization.gpu --format=csv,noheader,nounits -lms 100 > "$out/gpu.csv" &
    sampler=$!
    timeout -k 10s 180s "$(command -v time)" -f 'wall %e s; peak RSS KiB %M' -o "$out/time.log" \
        "$scratch/$variant/matched.test" -test.run '^TestMatchedSlice56$' -test.v -test.timeout=170s \
        > "$out/stdout" 2> "$out/stderr" || ec=$?
    kill "$sampler"
    wait "$sampler" || true
    [[ $ec == 0 ]]
    grep -q '^--- PASS: TestMatchedSlice56 ' "$out/stdout"
    jq -c 'del(.vector_bits) | .forwards |= map({positions, inputs:(.lengths|length),additional_peak_bytes,quality})' "$PBRAIN_56_OUT"
}

run pin narrow pin-1024
run pin default pin-1
run candidate default candidate-1
run candidate default candidate-2
run pin default pin-2
run pin default pin-3
run candidate default candidate-3

python3 - "$scratch/slices" <<'PY'
import hashlib
import json
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1])
runs = {p.parent.name: json.loads(p.read_text()) for p in sorted(root.glob("*/result.json"))}
assert len(runs) == 7
hashes = {hashlib.sha256(row["vector_bits"].encode()).hexdigest() for row in runs.values()}
assert len(hashes) == 1, "slice vector bytes differ"
assert all(row["inputs"] == 200 and row["positions"] == 100066 and row["gomaxprocs"] == 32 for row in runs.values())
rates = {name: [runs[f"{name}-{i}"]["passages_per_s"] for i in (1, 2, 3)] for name in ("pin", "candidate")}
summary = {"matched_rates": rates, "medians": {k: statistics.median(v) for k, v in rates.items()},
           "historical_control": runs["pin-1024"]["passages_per_s"], "vector_bits_equal": True}
print(json.dumps(summary))
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
assert summary["medians"]["candidate"] >= .95 * summary["medians"]["pin"], "candidate more than 5% slower than pin-only"
PY
touch "$scratch/slices.complete"
