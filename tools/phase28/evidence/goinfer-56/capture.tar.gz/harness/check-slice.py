"""Independently compare the matched Radeon/CPU slice, preserving bits."""
import base64
import json
import math
from pathlib import Path
import struct
import sys
path = Path(sys.argv[1])
a, b = (json.loads((path / f"{d}-slice.json").read_text()) for d in ("vulkan", "cpu"))
assert a["inputs"] == b["inputs"] == 200
assert a["positions"] == b["positions"] == 100066
left, right = (base64.b64decode(z["vector_bits"]) for z in (a, b))
assert len(left) == len(right) == 200*768*4
equal = sum(left[i:i+3072] == right[i:i+3072] for i in range(0,len(left),3072))
cosines = []
for u,v in zip(struct.iter_unpack("<768f", left), struct.iter_unpack("<768f", right), strict=True):
    def cosine(n):
        x, y = u[:n], v[:n]
        return math.fsum(p*q for p,q in zip(x,y,strict=True)) / math.sqrt(
            math.fsum(p*p for p in x) * math.fsum(q*q for q in y))
    cosines.append([cosine(512), cosine(768)])
result = {
    "vulkan_passages_per_s": a["passages_per_s"], "cpu_passages_per_s": b["passages_per_s"],
    "vectors": len(cosines), "exact_bits": equal, "minimum_cosine": min(map(min, cosines)),
    "below_0_999": sum(min(c) < .999 for c in cosines),
}
print(json.dumps(result))
(path / "slice-summary.json").write_text(json.dumps(result, indent=2) + "\n")
assert result["below_0_999"] == 0
