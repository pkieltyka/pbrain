// Re-create a module zip from its peeled Git tag with the Go module-zip rules.
package main

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path"

	"golang.org/x/mod/module"
	"golang.org/x/mod/sumdb/dirhash"
	modzip "golang.org/x/mod/zip"
)

type download struct {
	Path, Version, GoMod, Zip, Sum, GoModSum string
}

func verify(repo, tag, subdir, record string) error {
	log, err := os.ReadFile(record)
	if err != nil {
		return err
	}
	var pin download
	if err := json.Unmarshal(log, &pin); err != nil {
		return err
	}
	if pin.Version != "v0.6.3" || pin.Sum == "" || pin.GoModSum == "" {
		return fmt.Errorf("incomplete pin in %s", record)
	}
	name := path.Join(subdir, "go.mod")
	original, err := exec.Command("git", "-C", repo, "show", tag+":"+name).Output()
	if err != nil {
		return err
	}
	proxy, err := os.ReadFile(pin.GoMod)
	if err != nil {
		return err
	}
	if !bytes.Equal(original, proxy) {
		return errors.New("proxy go.mod differs from tag")
	}
	local, err := os.CreateTemp("", "pbrain-module-tag-*.zip")
	if err != nil {
		return err
	}
	defer os.Remove(local.Name())
	m := module.Version{Path: pin.Path, Version: pin.Version}
	err = modzip.CreateFromVCS(local, m, repo, tag, subdir)
	if cerr := local.Close(); cerr != nil || err != nil {
		return errors.Join(err, cerr)
	}
	gitSum, err := dirhash.HashZip(local.Name(), dirhash.Hash1)
	if err != nil {
		return err
	}
	proxySum, err := dirhash.HashZip(pin.Zip, dirhash.Hash1)
	if err != nil {
		return err
	}
	if gitSum != proxySum || gitSum != pin.Sum {
		return fmt.Errorf("tag zip %s, proxy zip %s, download reported %s", gitSum, proxySum, pin.Sum)
	}
	z, err := zip.OpenReader(pin.Zip)
	if err != nil {
		return err
	}
	defer z.Close()
	fmt.Printf("%s@%s tag %s: all %d entries match %s; .mod matches %s\n",
		pin.Path, pin.Version, tag, len(z.File), pin.Sum, pin.GoModSum)
	return nil
}

func main() {
	if len(os.Args) != 5 {
		fmt.Fprintln(os.Stderr, "usage: verify <repo> <tag> <module-subdirectory> <go-mod-download.json>")
		os.Exit(2)
	}
	if err := verify(os.Args[1], os.Args[2], os.Args[3], os.Args[4]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
