"""Export manifest-selected passage rows with their exact GPU vector bytes."""
import base64
import hashlib
import json
from pathlib import Path
import random
import shutil
import sqlite3
import sys

partial = Path(sys.argv[1])
brain = partial / "corpus/docs/brain"
index = brain / ".pbrain/index"
manifest = json.loads((index / "manifest").read_text())
db = index / manifest["db"]
with db.open("rb") as f:
    sha = hashlib.file_digest(f, "sha256").hexdigest()
with sqlite3.connect(db.as_uri() + "?mode=ro&immutable=1", uri=True) as con:
    assert con.execute("PRAGMA quick_check").fetchall() == [("ok",)]
    rows = [
        {"path": p, "ordinal": n, "digest": d.hex(), "vector": base64.b64encode(v).decode()}
        for p,n,d,v in con.execute(
            "SELECT i.path, p.ord, p.digest, p.vector FROM passage p JOIN item i ON p.item_id=i.id ORDER BY i.path,p.ord")
    ]
count, population, seed = len(rows), 2098, 56
assert count >= population
indices = sorted(random.Random(seed).sample(range(population), 500))
selected = [rows[i] for i in indices]
checkpoint = Path(sys.argv[2])
copy = checkpoint.parent / "checkpoint-db"
copy.mkdir()
shutil.copyfile(db, copy / manifest["db"])
shutil.copyfile(index / "manifest", copy / "manifest")
json_data = {"brain": str(brain), "manifest": manifest, "db_sha256": sha, "quick_check": "ok",
             "complete_checkpoint_passages": count, "sampling_population": population,
             "sampling_seed": seed, "sample_indices": indices, "passages": selected}
checkpoint.write_text(json.dumps(json_data, separators=(",",":")) + "\n")
print(f"{len(selected)} of the first {population} ordered passages from {count} checkpointed, seed {seed}")
