package gemma2

import (
	"encoding/binary"
	"encoding/json"
	"math"
	"os"
	"runtime"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/pkieltyka/goinfer/embeddinggemma2"
	"github.com/pkieltyka/pbrain/internal/embed"
)

type forward56 struct {
	Lengths    []int  `json:"lengths"`
	Positions  int    `json:"positions"`
	ElapsedNS  int64  `json:"elapsed_ns"`
	Additional int64  `json:"additional_peak_bytes"`
	Resident   int64  `json:"resident_weight_bytes"`
	Quality    string `json:"quality"`
	Error      string `json:"error,omitempty"`
}

var trace56 []forward56
var estimates56 map[int]embeddinggemma2.BatchMemoryEstimate

func estimate56(n int, estimate embeddinggemma2.BatchMemoryEstimate) {
	if estimates56 != nil {
		estimates56[n] = estimate
	}
}

func record56(ids [][]int, duration time.Duration, err error) {
	if estimates56 == nil {
		return
	}
	lengths, positions := make([]int, len(ids)), 0
	for i, input := range ids {
		lengths[i] = len(input)
		positions += lengths[i]
	}
	m := estimates56[len(ids)]
	row := forward56{Lengths: lengths, Positions: positions, ElapsedNS: duration.Nanoseconds(),
		Additional: m.AdditionalPeakBytes, Resident: m.ResidentWeightBytes, Quality: m.Quality.String()}
	if err != nil {
		row.Error = err.Error()
	}
	trace56 = append(trace56, row)
	clear(estimates56)
}

func TestMatchedSlice56(t *testing.T) {
	file := os.Getenv("PBRAIN_56_SLICE")
	if file == "" {
		t.Skip("set PBRAIN_56_SLICE")
	}
	input, err := os.ReadFile(file)
	if err != nil {
		t.Fatal(err)
	}
	var fixture []struct {
		Text      string
		Positions int
	}
	if err := json.Unmarshal(input, &fixture); err != nil || len(fixture) < 200 {
		t.Fatalf("need at least 200 saved passages, got %d: %v", len(fixture), err)
	}
	fixture = fixture[:200]
	texts := make([]string, len(fixture))
	positions := 0
	for i, row := range fixture {
		texts[i] = row.Text
		positions += row.Positions
	}
	if positions != 100066 {
		t.Fatalf("saved token sum = %d, want 100066", positions)
	}
	var budget int64
	if raw := os.Getenv("PBRAIN_GPU_MEMORY"); raw != "" {
		n, err := strconv.ParseInt(raw, 10, 64)
		if err != nil || n <= 0 {
			t.Fatalf("bad budget %q", raw)
		}
		budget = n << 20
	}
	selector := os.Getenv("PBRAIN_56_DEVICE")
	entry := Entry()
	pack := fixtureDir(t, "PBRAIN_TEST_GEMMA2_PACK")
	e, err := embed.NewRegistry(entry).Open(t.Context(), verified(t, pack, entry.Model),
		embed.OpenOptions{Device: selector, MemoryBudget: budget})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = e.Close() })
	wantDevice := "cpu"
	switch {
	case strings.HasPrefix(selector, "vulkan:"):
		wantDevice = "vulkan:0"
	case strings.HasPrefix(selector, "cuda:"):
		wantDevice = "cuda:0"
	}
	info := e.Info()
	if info.Device != wantDevice || budget != 0 && info.Budget != budget {
		t.Fatalf("opened %+v, want device %s and override %d", info, wantDevice, budget)
	}
	estimates56 = make(map[int]embeddinggemma2.BatchMemoryEstimate)
	defer func() { estimates56 = nil }()
	trace56 = nil
	start := time.Now()
	got, err := e.Embed(t.Context(), embed.Document, texts)
	elapsed := time.Since(start)
	if err != nil || len(got) != len(texts) {
		t.Fatalf("embedded %d of %d: %v", len(got), len(texts), err)
	}
	off := 0
	for _, f := range trace56 {
		if f.Error != "" {
			t.Fatalf("actual forward failed: %+v", f)
		}
		if len(f.Lengths) > 1 && f.Quality != "unknown" && f.Additional > info.Budget {
			t.Fatalf("admitted known-cost batch above budget: %+v", f)
		}
		if wantDevice != "cpu" && f.Positions > 8192 {
			t.Fatalf("admitted GPU batch above 8192 positions: %+v", f)
		}
		for _, length := range f.Lengths {
			if off >= len(fixture) || fixture[off].Positions != length {
				t.Fatalf("forward input %d diverges from the saved token count", off)
			}
			off++
		}
	}
	if off != len(texts) || e.Info() != info {
		t.Fatalf("device changed or forwarded %d/%d inputs", off, len(texts))
	}
	bits := make([]byte, 0, len(got)*dimension*4)
	for _, row := range got {
		for _, value := range row {
			bits = binary.LittleEndian.AppendUint32(bits, math.Float32bits(value))
		}
	}
	out, err := json.Marshal(map[string]any{
		"device": info, "gomaxprocs": runtime.GOMAXPROCS(0), "inputs": len(texts), "positions": positions,
		"elapsed_s": elapsed.Seconds(), "passages_per_s": float64(len(texts)) / elapsed.Seconds(),
		"forwards": trace56, "vector_bits": bits,
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(os.Getenv("PBRAIN_56_OUT"), append(out, '\n'), 0o600); err != nil {
		t.Fatal(err)
	}
	t.Logf("%s, %d passages, %d positions, %d forwards, %.3f passages/s",
		info.Device, len(texts), positions, len(trace56), float64(len(texts))/elapsed.Seconds())
	if err := e.Close(); err != nil {
		t.Fatal(err)
	}
}
