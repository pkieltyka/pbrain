"""Compare real GPU builds across layouts from independent cold and seeded states."""
import filecmp
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys

d = Path(sys.argv[1])
out = d / "storage"
out.mkdir()
gpu = subprocess.check_output(["nvidia-smi", "-i", "0", "--query-gpu=uuid",
                               "--format=csv,noheader"], text=True).strip()
env = dict(os.environ, PBRAIN_ALLOW_GEMMA2="1", GOMAXPROCS="4",
           LD_LIBRARY_PATH="/run/opengl-driver/lib", CUDA_VISIBLE_DEVICES=gpu,
           GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM="1")
for name in ("PBRAIN_DEVICE", "PBRAIN_GPU_MEMORY", "PBRAIN_BRAIN", "PBRAIN_DIR"):
    env.pop(name, None)
pack = "/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack"

def digest(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()

def make(case):
    brain = out / case / "brain"
    (brain / "notes").mkdir(parents=True)
    (brain / "personal/notes").mkdir(parents=True)
    (brain / "pbrain.toml").write_text('semantic.model = "embeddinggemma-2"\n')
    (brain / "personal.toml").write_text(f'model_path = "{pack}"\n')
    return brain

def note(brain, name, body, private):
    base = brain / "personal" if private else brain
    path = base / "notes" / (name + ".md")
    path.write_text(
        "---\nkind: note\ntitle: Sync reuse\ncreated: 2026-01-01T00:00:00Z\n"
        f"author: agent:test\n---\n\n{body}\n"
    )
    return path

def sync(brain, variant, label):
    run_dir = brain.parent
    run_env = dict(env, PBRAIN_CACHE=str(run_dir / "cache"))
    binary = d / "candidate" / ("pbrain-forced" if variant == "forced" else "pbrain-dual")
    trace = run_dir / f"{label}.trace"
    run_env["PBRAIN_56_FORCE_TRACE"] = str(trace)
    if variant == "narrow":
        run_env["PBRAIN_GPU_MEMORY"] = "1"
    stdout, stderr = [run_dir / f"{label}.{stream}" for stream in ("json", "stderr")]
    with stdout.open("xb") as out_stream, stderr.open("xb") as err_stream:
        subprocess.run(["timeout", "-k", "10s", "90s", "taskset", "-c", "0-3", binary,
                        "--brain", brain, "--personal", "sync", "--device", "cuda:" + gpu, "--json"],
                       stdout=out_stream, stderr=err_stream, env=run_env, check=True)
    if variant == "forced":
        assert trace.read_text().count("forced certified OOM before dispatch") == 2
    result = json.loads(stdout.read_text())
    if label == "final":
        assert all(s["device"] == "cuda:0" and s["passages_embedded"] > 1 and s["passages_reused"] > 0
                   for s in result["sections"])
    return result

common = "# Alpha\n\nThis passage is reused by two unchanged notes."
previous = common + "\n\n# Tail\n\nAn original tail."
changed = common + "\n\n# Tail\n\nA replacement tail."
cached = "Only an existing shared cache can reuse this passage."

seed = make("initial")
for private in (False, True):
    note(seed, "a", previous, private)
    note(seed, "z", common, private)
    note(seed, "zz", common, private)
extra = note(seed, "cache-prime", cached, False)
sync(seed, "wide", "seed")
extra.unlink()
sync(seed, "wide", "remove-cache-prime")

def inputs(brain):
    for private in (False, True):
        note(brain, "a", changed, private)
        note(brain, "b", common, private)
        note(brain, "c", cached, private)
        note(brain, "d", "Each new passage is embedded once.", private)
        note(brain, "e", "A second new passage has its own text.", private)
        note(brain, "f", "Each new passage is embedded once.", private)
        note(brain, "z", common, private)
        note(brain, "zz", common, private)
        if private:
            note(brain, "h-private", "This digest belongs to the personal index only.", private)

def db(brain, private):
    base = brain / "personal" if private else brain
    index = base / ".pbrain/index"
    return index / json.loads((index / "manifest").read_text())["db"]

def cache(brain):
    root = brain.parent / "cache/vectors"
    return {str(p.relative_to(root)): digest(p) for p in root.rglob("*") if p.is_file()}

matrix = {}
for state in ("cold", "seeded"):
    for variant in ("narrow", "wide", "forced"):
        label = f"{state}-{variant}"
        if state == "seeded":
            shutil.copytree(seed.parent, out / label, ignore=shutil.ignore_patterns("*.json", "*.stderr"))
            brain = out / label / "brain"
        else:
            brain = make(label)
        inputs(brain)
        result = sync(brain, variant, "final")
        caches = cache(brain)
        summary = {"result": result, "db": {}, "cache": caches}
        for private in (False, True):
            section = "personal" if private else "shared"
            path = db(brain, private)
            with sqlite3.connect(path.as_uri() + "?mode=ro&immutable=1", uri=True) as con:
                assert con.execute("PRAGMA quick_check").fetchall() == [("ok",)]
                if private:
                    private_digest, = con.execute("SELECT lower(hex(p.digest)) FROM passage p JOIN item i ON p.item_id=i.id WHERE i.path = 'notes/h-private.md'").fetchone()
                    assert all(Path(p).name != private_digest for p in caches)
                tables = {}
                for table, order in (("meta", "key"), ("item", "path"), ("passage", "item_id, ord")):
                    rows = con.execute(f"SELECT * FROM {table} ORDER BY {order}").fetchall()
                    tables[table] = {"rows": len(rows), "digest": hashlib.sha256(repr(rows).encode()).hexdigest()}
                summary["db"][section] = {"sha256": digest(path), "tables": tables, "quick_check": "ok"}
        if variant != "narrow":
            assert summary == matrix[f"{state}-narrow"], (state, variant, summary)
            narrow = out / f"{state}-narrow" / "brain"
            assert all(filecmp.cmp(db(brain, p), db(narrow, p), shallow=False) for p in (False, True))
        matrix[label] = summary
print(json.dumps(matrix, indent=2))
