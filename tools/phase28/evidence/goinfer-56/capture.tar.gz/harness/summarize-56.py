"""Summarize the capped candidate and the archived experiment from raw captures."""
import base64
import csv
import hashlib
import json
import re
import statistics
import sys
from pathlib import Path

work = Path(sys.argv[1])

def payload(path):
    return json.loads(path.read_text())

def records(path):
    return [json.loads(line) for line in path.read_text().splitlines()]

def stats(samples):
    return {"samples": samples, "median": statistics.median(samples), "range": [min(samples), max(samples)]}

def slices(root, capped):
    results, hashes = {}, set()
    for path in sorted(root.glob("*/result.json")):
        row = payload(path)
        assert row["inputs"] == 200 and row["positions"] == 100066 and row["gomaxprocs"] == 32
        digest = hashlib.sha256(base64.b64decode(row["vector_bits"])).hexdigest()
        hashes.add(digest)
        with (path.parent / "gpu.csv").open() as fp:
            gpu = list(csv.reader(fp))
        peak_rss = int(re.search(r"peak RSS KiB (\d+)", (path.parent/"time.log").read_text())[1])
        usage = [int(g[1]) for g in gpu]
        forwards = row["forwards"]
        max_positions = max(f["positions"] for f in forwards)
        assert max_positions <= 8192 or not capped
        assert all(f["additional_peak_bytes"] <= row["device"]["Budget"] for f in forwards if len(f["lengths"]) > 1)
        results[path.parent.name] = {
            "rate": row["passages_per_s"], "elapsed_s": row["elapsed_s"],
            "budget_bytes": row["device"]["Budget"], "calls": len(forwards),
            "max_positions": max_positions, "device_peak_mib": max(usage),
            "device_samples": len(usage), "device_busy_median_percent": statistics.median(int(g[2]) for g in gpu),
            "host_peak_rss_mib": peak_rss/1024,
            "additional_peak_bytes": max(f["additional_peak_bytes"] for f in forwards),
            "resident_weight_bytes": max(f["resident_weight_bytes"] for f in forwards),
        }
    assert len(results) == 7 and len(hashes) == 1
    return {
        "results": results, "vector_sha256": hashes.pop(),
        "rates": {
            k: stats([results[f"{k}-{i}"]["rate"] for i in (1, 2, 3)])
            for k in ("pin", "candidate")
        },
    }

def guarded(path, expected_exit):
    rows = records(path/"vram.jsonl")
    pre = rows[0]
    final = rows[-1]
    timing = next(row for row in rows if row.get("phase") == "timing")
    assert final["phase"] == "result" and final["exit"] == expected_exit and final["stop_reason"] is None
    assert pre["limit_bytes"] == 4*2**30 and pre["budget_mib"] == 1024
    trace = [row for row in rows if "guard_share_bytes" in row]
    assert trace and final["peak_share_bytes"] == max(row["guard_share_bytes"] for row in trace)
    assert final["peak_share_bytes"] < 4*2**30
    return {
        "seconds_limit": pre["seconds_limit"], "wall_s": timing["wall_s"], "peak_rss_mib": timing["peak_rss_kib"]/1024,
        "peak_vram_bytes": final["peak_share_bytes"], "peak_vram_mib": final["peak_share_bytes"]/2**20,
        "peak_raw_card_bytes": max(row["device_used_bytes"] for row in trace),
        "peak_process_drm_bytes": max(row["process_vram_bytes"] or 0 for row in trace),
        "sample_count": len(trace),
        "interrupted": any(row.get("phase")=="operator_interrupt" for row in rows),
    }

base = (work/"parent-revision").read_text().strip()
pin = (work/"control-revision").read_text().strip()
candidate = (work/"candidate-revision").read_text().strip()
uncapped = (work/"uncapped-revision").read_text().strip()
timings = (work/"short-gates.log").read_text()
q8 = [int(m)/1e6 for m in re.findall(r"^BenchmarkGemmaQ8FirstQuery-4\s+1\s+(\d+) ns/op", timings, re.M)]
q8rss = list(map(int,re.findall(r"^peak RSS KiB (\d+)", timings, re.M)))
assert len(q8) == len(q8rss) == 5 and all(ms < 600 for ms in q8)
layout_log = (work/"capped-cuda.log").read_text()
assert layout_log.count("default budget: 59 bit-identical vectors") == 2
assert layout_log.count("forced split: 59 bit-identical vectors") == 2
matrix = payload(work/"storage-summary.json")
for initial in ("cold", "seeded"):
    assert matrix[initial+"-narrow"] == matrix[initial+"-wide"] == matrix[initial+"-forced"]
cap, wide = [slices(work/p, capped) for p,capped in (("slices",True),("uncapped-slices",False))]
assert cap["vector_sha256"] == wide["vector_sha256"]
assert cap["rates"]["candidate"]["median"] >= .95 * cap["rates"]["pin"]["median"]

amd = work/"amd"
checkpoint = payload(amd/"checkpoint.json")
cpu_verify = payload(amd/"checkpoint-cpu-summary.json")
assert len(checkpoint["passages"]) == cpu_verify["passages"] == 500 and cpu_verify["below_0_999"] == 0
assert checkpoint["quick_check"] == "ok"
assert checkpoint["sampling_seed"] == 56 and checkpoint["sampling_population"] == 2098
stop = records(amd/"operator-stop.jsonl")
assert [entry["signal"] for entry in stop] == ["SIGTERM","SIGINT"]
result = {
    "revisions": {"parent":base,"pin_only":pin,"uncapped":uncapped,"candidate":candidate,
                  "release_fix":(work/"release-fix-source").read_text().strip()},
    "cuda": {"uncapped":wide,"capped":cap,"real_layouts_passed":True},
    "parity":payload(work/"parity-summary.json"),
    "storage":matrix,
    "q8_rule3_cpu": {**stats(q8), "below_600":sum(t<600 for t in q8), "peak_rss_mib":max(q8rss)/1024},
    "amd": {
        "layouts": guarded(amd/"layouts", 0),
        "slice": {**guarded(amd/"slice", 0), **payload(amd/"slice-summary.json")},
        "partial": {
            **guarded(amd/"partial/capture", -2),
            "operator_interrupted": True,
            "checkpoint":{k:v for k,v in checkpoint.items() if k!="passages"},
            "parity":{k:v for k,v in cpu_verify.items() if k!="cpu_vectors"},
        },
    },
}
print(json.dumps(result, indent=2, sort_keys=True))
