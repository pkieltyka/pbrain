"""Copy raw captures and the storage files needed to reproduce report comparisons."""
import json
import shutil
import sys
from pathlib import Path

work, stage = (Path(arg) for arg in sys.argv[1:])
stage.mkdir()
names = [
    "parent-revision", "control-revision", "uncapped-revision", "candidate-revision",
    "host.log", "tags.log", "download.json", "public-proxy-and-sums.log", "sum-differences", "go-mod-verify.log",
    "runtime-audit.log", "tag-compare.log", "capped-checks.log", "capped-build-info.log",
    "capped-binary-sha256", "capped-sizes.log", "binary-sha256",
    "parent-build-info.log", "pin-build-info.log", "short-gates.log", "capped-cuda.log",
    "parity-summary.json", "parity.log", "parity", "reference.json", "prepared.tsv", "q8-reference-sha256.log",
    "fixture-sha256.log", "slices", "uncapped-slices", "storage-quiet.jsonl", "storage-summary.json",
    "capped-cuda.complete", "slices.complete", "storage.complete", "amd.complete",
    "release-fix-source", "release-fix-checks.log", "no-icd.log", "no-icd.complete",
]
for name in names:
    source = work / name
    if source.is_dir():
        shutil.copytree(source, stage / name)
    else:
        shutil.copyfile(source, stage / name)
for name, pathway in (("parent", "parent-source"), ("pin", "pin-source")):
    for file in ("go.mod", "go.sum"):
        shutil.copyfile(work / pathway / file, stage / f"{name}-{file}")
source = work / "amd"
target = stage / "amd"
shutil.copytree(source, target, ignore=shutil.ignore_patterns("corpus", "cache"))
shutil.copytree(work / "no-icd", stage / "no-icd", ignore=shutil.ignore_patterns("brain", "cache"))
for case in sorted((work / "storage").iterdir()):
    target = stage / "storage" / case.name
    target.mkdir(parents=True)
    for path in case.iterdir():
        if path.suffix in {".json", ".stderr", ".trace"}:
            shutil.copyfile(path, target / path.name)
    if case.name == "initial":
        continue
    for section in (Path(), Path("personal")):
        index = case / "brain" / section / ".pbrain/index"
        new_index = target / "brain" / section / ".pbrain/index"
        new_index.mkdir(parents=True)
        file = json.loads((index / "manifest").read_text())["db"]
        for name in ("manifest", file):
            shutil.copyfile(index / name, new_index / name)
    shutil.copytree(case / "cache/vectors", target / "cache/vectors")
harness = stage / "harness"
harness.mkdir()
for name in (
    "amd-guard.py", "batch-forced.go", "check-parity.py", "check-slice.py", "checkpoint_test.go",
    "export-checkpoint.py", "finish-amd-56.sh", "gemma_eval_test.go", "matched_test.go", "quiet.py", "recheck-56.sh",
    "run-amd.sh", "run-capped-cuda.sh", "smoke-no-icd.sh", "run-cuda-slices.sh", "run-parity.sh", "run-short-gates.sh",
    "verify-capture.py", "slice-overlay.py", "stage-evidence.py", "storage-overlay.py", "summarize-56.py", "sync-storage.py",
):
    shutil.copyfile(work / name, harness / name)
module_verify = harness / "module-verify"
module_verify.mkdir()
for name in ("main.go", "go.mod", "go.sum"):
    shutil.copyfile(work / "verify" / name, module_verify / name)
