"""M4 paired 59-passage Metal and paired 219/59 CPU baselines for #69."""
import json
import os
from pathlib import Path
import re
import runpy
import subprocess
import time

shared = runpy.run_path(str(Path(__file__).with_name("run-m4.py")))
ROOT, EVIDENCE, ENV = (shared[key] for key in ("ROOT", "EVIDENCE", "ENV"))
STOCK, COMBINED = shared["STOCK"], shared["COMBINED"]
quiet, manifest = shared["quiet"], shared["manifest"]
index_fingerprint = shared["index_fingerprint"]


def run(count, model, profile, trial):
    arm = {"": model + "-cpu", STOCK: "stock", COMBINED: "default"}[profile]
    label = f"matrix-{count}-{arm}-{trial}"
    project = ROOT / "runs" / label
    project.mkdir(parents=True)
    name, files = {"q8": (shared["NAME"], ROOT / "model"),
                   "bge": ("bge-small-en-v1.5", ROOT / "bge-model")}[model]
    binary = ROOT / ("pbrain-m4-bench" if profile else "pbrain-m4-cpu")
    env = dict(ENV, PBRAIN_CACHE=str(project / "cache"),
               PBRAIN_TRACE=str(EVIDENCE / f"{label}.trace.jsonl"))
    if profile == STOCK:
        env["PBRAIN_BENCH_METAL_SELECTOR"] = "metal-eg2-stock"
    subprocess.run([str(binary), "init"], cwd=project, env=env, check=True, capture_output=True)
    fixture = ROOT / ("fixture" if count == 219 else "fixture-59")
    brain = project / "docs/brain"
    notes = sorted(fixture.rglob("*.md"))
    assert len(notes) == (22 if count == 219 else 32)
    for note in notes:
        target = brain / note.relative_to(fixture)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(note.read_bytes())
    (brain / "pbrain.toml").write_text(f'[semantic]\nmodel = "{name}"\n')
    (brain / "personal.toml").write_text(f'model_path = "{files}"\n')

    # The original 219-passage Metal cells already form an order-reversed pair.
    # This runner adds the 59-passage Metal cells and paired CPU controls.
    idle = quiet(label)
    out = EVIDENCE / f"{label}.sync.json"
    device = "metal:0" if profile else "cpu"
    with out.open("w") as stdout, (EVIDENCE / f"{label}.time").open("w") as stderr:
        start = time.monotonic()
        subprocess.run(["/usr/bin/time", "-l", str(binary), "sync", "--device", device, "--json"],
                       cwd=project, env=env, stdout=stdout, stderr=stderr, check=True, timeout=900)
        wall = time.monotonic() - start
    result = json.loads(out.read_text())["sections"][0]
    assert result["items"] == len(notes) and result["passages_embedded"] == count and not result["passages_reused"], result
    events = [json.loads(line) for line in (EVIDENCE / f"{label}.trace.jsonl").read_text().splitlines()]
    trace = events[-1]
    forwards = [e for e in events if e.get("span") == "forward"]
    assert len(forwards) == count
    assert all(e["device"] == device and e["inputs"] == 1 and not e.get("failed") for e in forwards)
    assert trace["accelerator_attaches"] == int(bool(profile))
    saved = manifest(project)
    if model == "q8":
        assert saved["fingerprint"] == index_fingerprint(profile)
    reading = (EVIDENCE / f"{label}.time").read_text()
    rss = int(re.search(r"(\d+)\s+maximum resident set size", reading)[1])
    footprint = int(re.search(r"(\d+)\s+peak memory footprint", reading)[1])
    receipt = {"label": label, "count": count, "trial": trial, "model": model, "profile": profile,
               "idle_pct": idle, "wall_s": wall, "passages_per_s": count / wall, "peak_rss_bytes": rss,
               "peak_footprint_bytes": footprint, "spans": trace["spans"], "path": label,
               "fingerprint": saved["fingerprint"], **result}
    (EVIDENCE / f"{label}.summary.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt), flush=True)


for trial, order in ((1, (STOCK, COMBINED)), (2, (COMBINED, STOCK))):
    for profile in order:
        run(59, "q8", profile, trial)
for count in (59, 219):
    for trial, order in ((1, ("bge", "q8")), (2, ("q8", "bge"))):
        for model in order:
            run(count, model, "", trial)
