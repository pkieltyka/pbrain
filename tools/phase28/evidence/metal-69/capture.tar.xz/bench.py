"""Compare pbrain d48cf1c with only the goinfer pin and profile revision changed."""
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sqlite3
import struct
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = Path("/home/peter/Dev/pkieltyka/pbrain")
MODELS = {
    "q6": ("embeddinggemma-2-ud-q6-k-xl",
           Path.home() / "goinfer-logs/pbrain-65-device.20261123T234251Z/cells/q6-cpu/model",
           "16d5093f31a4399589c717804e04d2ad3fd70df5bd42b36bf60424dc4599e2f4"),
    "q8": ("embeddinggemma-2-q8-0", "/var/tmp/pbrain-sync-trace.NSKyVs/q8-model",
           "9ebb0de1d547aee1abffec1288639ce596a06b0c32447d502782a474118cf691"),
    "google": ("embeddinggemma-2", "/var/tmp/pbrain-phase28-gemma-22.5UFzx5/gemma-pack",
               "79cd8cb6d605c915fb0ea74c3680816bd15df66e5db70ad0de1bf13df463de48"),
}
REVISIONS = {
    "067": "c26c69ed44717d86cf2218370054d5e89886b694",
    "068": "fd85e325a50f3f525f4629599ff2a5b9cca4c246",
}
CASES = (("q6", "fp32"), ("q8", "fp32"), ("google", "fp16"), ("q8", "fp16"))


def load_fixtures():
    fixed = json.loads((ROOT / "fixture-219.json").read_text())
    notes = {}
    digest = hashlib.sha256()
    for name in fixed["notes"]:
        data = (Path(fixed["source"]) / name).read_bytes()
        notes[name] = data
        digest.update(os.fsencode(name) + b"\0" + hashlib.sha256(data).digest())
    assert len(notes) == 22 and digest.hexdigest() == fixed["digested_path_sha256"]

    frozen = {}
    retrieval = REPO / "internal/semantic/calibrate/testdata/retrieval/brain"
    for line in (ROOT / "fixture-59.SHA256").read_text().splitlines():
        expected, name = line.split(maxsplit=1)
        data = (retrieval / name).read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected, name
        frozen[name] = data
    assert list(frozen) == (ROOT / "fixture-59.txt").read_text().splitlines()
    assert len(frozen) == 32
    return {219: notes, 59: frozen}


def expected_index(base, precision, version):
    if precision == "fp16":
        identity = f"pbrain-vector-profile-v1\n{base}\ncuda-eg2-fp16\n{REVISIONS[version]}"
        base = hashlib.sha256(identity.encode()).hexdigest()
    return hashlib.sha256(f"pbrain-index\n1\n{base}".encode()).hexdigest()


def vectors(index, manifest, notes, count):
    db = index / manifest["db"]
    with sqlite3.connect(db.as_uri() + "?mode=ro&immutable=1", uri=True) as con:
        assert con.execute("PRAGMA quick_check").fetchone() == ("ok",), db
        paths = con.execute("SELECT path FROM item ORDER BY path").fetchall()
        rows = con.execute(
            "SELECT item.path, passage.ord, passage.start, passage.stop, passage.digest, passage.vector "
            "FROM passage JOIN item ON passage.item_id = item.id ORDER BY item.path, passage.ord"
        ).fetchall()
    assert paths == [(name,) for name in sorted(notes)], db
    assert len(rows) == count and all(len(r[-1]) == 768 * 4 for r in rows), db
    return rows


def compare(old, new):
    assert len(old) == len(new) and old, "missing vectors"
    minimum, equal = 1.0, 0
    for a, b in zip(old, new, strict=True):
        assert a[:-1] == b[:-1], (a[0:2], b[0:2])
        va, vb = struct.unpack("<768f", a[-1]), struct.unpack("<768f", b[-1])
        assert all(math.isfinite(v) for v in (*va, *vb))
        aa, bb = sum(v * v for v in va), sum(v * v for v in vb)
        assert abs(1 - aa) < 1e-5 and abs(1 - bb) < 1e-5, a[0:2]
        equal += a[-1] == b[-1]
        minimum = min(minimum, sum(x * y for x, y in zip(va, vb, strict=True)) / math.sqrt(aa * bb))
    return {"vectors_equal": equal, "vectors_compared": len(old), "min_cosine": minimum}


def run(fixture, count, model, precision, version, trial, gpu):
    name, model_path, base = MODELS[model]
    out = ROOT / f"{count}-{model}-{precision}-{trial}-{version}"
    out.mkdir()
    project, home = out / "project", out / "home"
    project.mkdir()
    home.mkdir()
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(("PBRAIN_", "GOINFER_", "LD_"))}
    env.update(HOME=str(home), GOMAXPROCS="4", PBRAIN_ALLOW_GEMMA2="1",
               PBRAIN_CACHE=str(out / "cache"), CUDA_VISIBLE_DEVICES=gpu,
               LD_LIBRARY_PATH="/run/opengl-driver/lib", GIT_CONFIG_GLOBAL="/dev/null",
               GIT_CONFIG_NOSYSTEM="1", LC_ALL="C", TZ="UTC")
    cli = ["taskset", "-c", "0-3", str(ROOT / f"pbrain-{version}")]
    subprocess.run([*cli, "init"], cwd=project, env=env, check=True, capture_output=True)
    brain = project / "docs/brain"
    for name_in_brain, data in fixture.items():
        path = brain / name_in_brain
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    (brain / "pbrain.toml").write_text(f'[semantic]\nmodel = "{name}"\ncuda_precision = "{precision}"\n')
    (brain / "personal.toml").write_text(f'model_path = "{model_path}"\n')
    with (out / "quiet.jsonl").open("w") as record:
        subprocess.run([sys.executable, str(ROOT / "quiet.py"), "--max-busy-pct", "4",
                        "--attempts", "48"], stdout=record, check=True)
    smi = ["nvidia-smi", "-i", gpu]
    apps = subprocess.check_output([*smi, "--query-compute-apps=pid", "--format=csv,noheader"], text=True)
    assert not apps.strip(), apps
    env["PBRAIN_TRACE"] = str(out / "trace.jsonl")
    with (out / "gpu.csv").open("w") as samples, (out / "sync.json").open("w") as stdout, \
         (out / "stderr").open("w") as stderr:
        monitor = subprocess.Popen(["stdbuf", "-oL", *smi,
                                    "--query-gpu=timestamp,memory.used,utilization.gpu",
                                    "--format=csv,noheader,nounits", "-lms", "100"], stdout=samples)
        try:
            start = time.monotonic()
            subprocess.run(["timeout", "-s", "INT", "-k", "5s", "115s", *cli, "sync",
                            "--device", f"cuda:{gpu}", "--json"],
                           cwd=project, env=env, stdout=stdout, stderr=stderr, check=True)
            wall = time.monotonic() - start
        finally:
            monitor.terminate()
            monitor.wait(timeout=5)
    stored = json.loads((out / "sync.json").read_text())["sections"]
    assert len(stored) == 1 and stored[0]["items"] == len(fixture)
    assert stored[0]["passages_embedded"] == count and stored[0]["passages_reused"] == 0
    notices = (out / "stderr").read_text()
    assert "6144 MiB a batch" in notices and "cuda_precision_fallback" not in notices, notices
    trace = [json.loads(line) for line in (out / "trace.jsonl").read_text().splitlines()]
    fwd = [e for e in trace if e["span"] == "forward"]
    assert trace[-1]["model_opens"] == trace[-1]["accelerator_attaches"] == 1
    assert sum(e["inputs"] for e in fwd) == count
    assert all(e["device"] == "cuda:0" and not e.get("failed") and e["total_positions"] <= 8192 for e in fwd)
    longest = [e["max_positions"] for e in fwd]
    assert max(longest) >= 128, longest
    index = brain / ".pbrain/index"
    manifest = json.loads((index / "manifest").read_text())
    assert manifest["fingerprint"] == expected_index(base, precision, version), manifest
    assert manifest.get("cuda_precision_request", "fp32") == precision, manifest
    rows = vectors(index, manifest, fixture, count)
    with (out / "gpu.csv").open() as samples:
        peak = max(int(row[1]) for row in csv.reader(samples))
    result = {
        "model": model, "precision": precision, "version": version, "trial": trial, "wall_s": wall,
        "passages": count, "passages_per_s": count / wall, "device_peak_mib": peak,
        "forwards": len(fwd), "eligible_by_length": sum(n >= 128 for n in longest),
        "min_batch_max_positions": min(longest), "max_batch_max_positions": max(longest),
        "positions": sum(e["total_positions"] for e in fwd), "forward_ms": sum(e["ms"] for e in fwd),
        "fingerprint": manifest["fingerprint"], "trace_shape": [[e[k] for k in ("inputs", "total_positions", "max_positions")] for e in fwd],
        "vectors_sha256": hashlib.sha256(b"".join(row[-1] for row in rows)).hexdigest(),
    }
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)
    return result, rows


def main():
    assert os.environ.get("GOINFER_TIMING_LOCK", "") and not os.environ["GOINFER_TIMING_LOCK"].startswith("sh-")
    gpu = subprocess.check_output(["nvidia-smi", "-i", "0", "--query-gpu=uuid",
                                   "--format=csv,noheader"], text=True).strip()
    for count, fixture in load_fixtures().items():
        for model, precision in CASES:
            for trial, versions in enumerate((("067", "068"), ("068", "067")), 1):
                pair = {v: run(fixture, count, model, precision, v, trial, gpu) for v in versions}
                (a, old), (b, new) = pair["067"], pair["068"]
                assert a["trace_shape"] == b["trace_shape"], (a, b)
                comparison = compare(old, new)
                print(json.dumps({"comparison": [count, model, precision, trial],
                                  "speedup": a["wall_s"] / b["wall_s"], **comparison}), flush=True)


if __name__ == "__main__":
    main()
