"""Frozen #69 Linux CPU baselines, same-file CPU references and guarded Radeon matrix."""
import argparse
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

from bench import ROOT, MODELS, load_fixtures

BGE = ("bge-small-en-v1.5", "/var/tmp/pbrain-phase28-bge-pax-fresh.rCsjGe/bge-model", None)
CARD = Path("/sys/bus/pci/devices/0000:0c:00.0")
LOADER = "/nix/store/1l0a4cq8ahhpgwx0byq2zcsi316mlzm1-vulkan-loader-1.4.363.0/lib:/run/opengl-driver/lib"
GUARD = "/var/tmp/pbrain-batch-56.isNnY3/amd-guard.py"
BINARY = str(ROOT / "pbrain-068")
RUNS = ROOT / "linux-comparison"
RUNS.mkdir(exist_ok=True)
FIXTURES = load_fixtures()


def vectors(arm, count, dim):
    directory = arm / "project/docs/brain/.pbrain/index"
    manifest = json.loads((directory / "manifest").read_text())
    with sqlite3.connect((directory / manifest["db"]).as_uri() + "?mode=ro&immutable=1", uri=True) as connection:
        assert connection.execute("PRAGMA quick_check").fetchall() == [("ok",)]
        items = connection.execute("SELECT * FROM item ORDER BY path").fetchall()
        passages = connection.execute("SELECT * FROM passage ORDER BY item_id, ord").fetchall()
    assert sorted(r[1] for r in items) == sorted(FIXTURES[count])
    assert len(passages) == count and all(len(r[-1]) == 4 * dim for r in passages)
    return items, passages


def run(device, count, model, trial):
    note_files = FIXTURES[count]
    name, model_path, _ = BGE if model == "bge" else MODELS[model]
    stage = RUNS / f"{device.split(':')[0]}-{count}-{model}-{trial}"
    cwd = stage / "project"
    cwd.mkdir(parents=True)
    env = {k: v for k, v in os.environ.items() if not k.startswith(("PBRAIN_", "GOINFER_", "GOMAX", "GOGC", "GOMEM", "GIT_", "VK_", "LD_"))}
    env.update(GOMAXPROCS="4", PBRAIN_ALLOW_GEMMA2="1", PBRAIN_CACHE=str(stage / "cache"),
               PBRAIN_TRACE=str(stage / "trace.jsonl"), LD_LIBRARY_PATH=LOADER,
               GIT_CONFIG_GLOBAL="/dev/null", GIT_CONFIG_NOSYSTEM="1", LC_ALL="C", TZ="UTC",
               CUDA_VISIBLE_DEVICES="")
    subprocess.run([BINARY, "init"], cwd=cwd, env=env, check=True, capture_output=True)
    brain = cwd / "docs/brain"
    for filename, body in note_files.items():
        trg = brain / filename
        trg.parent.mkdir(parents=True, exist_ok=True)
        trg.write_bytes(body)
    (brain / "pbrain.toml").write_text(f'[semantic]\nmodel = "{name}"\ncuda_precision = "fp32"\n')
    (brain / "personal.toml").write_text(f'model_path = "{model_path}"\n')
    with (stage / "quiet.jsonl").open("w") as quiet:
        subprocess.run([sys.executable, str(ROOT / "quiet.py"), "--attempts", "48"], stdout=quiet, check=True)
    peak = None
    if device == "cpu":
        output = stage / "stdout"
        with output.open("w") as stdout, (stage / "stderr").open("w") as stderr:
            start = time.monotonic()
            subprocess.run(["timeout", "-k", "5s", "900s", "taskset", "-c", "0-3",
                            BINARY, "sync", "--device", "cpu", "--json"],
                           cwd=cwd, env=env, stdout=stdout, stderr=stderr, check=True)
            wall = time.monotonic() - start
    else:
        assert int((CARD / "gpu_busy_percent").read_text()) <= 10
        assert int((CARD / "mem_info_vram_total").read_text()) - int((CARD / "mem_info_vram_used").read_text()) > 3 << 30
        output = stage / "guard/stdout"
        subprocess.run([sys.executable, GUARD, "--budget-mib", "1024", "--seconds", "120",
                        str(CARD), str(stage / "guard"), BINARY, "sync", "--device", device, "--json"],
                       cwd=cwd, env=env, check=True)
        guarded = [json.loads(l) for l in (stage / "guard/vram.jsonl").read_text().splitlines()]
        wall = next(r["wall_s"] for r in guarded if r.get("phase") == "timing")
        peak = guarded[-1]["peak_share_bytes"]
    section = json.loads(output.read_text())["sections"][0]
    assert section["items"] == len(note_files) and section["passages_embedded"] == count and not section["passages_reused"], section
    trace = [json.loads(l) for l in (stage / "trace.jsonl").read_text().splitlines()]
    forwards = [r for r in trace if r.get("span") == "forward"]
    assert forwards and all(r["device"] == ("cpu" if device == "cpu" else "vulkan:0") and not r.get("failed") for r in forwards)
    assert sum(r["inputs"] for r in forwards) == count
    vectors(stage, count, 384 if model == "bge" else 768)
    receipt = {"model": model, "count": count, "trial": trial, "device": device, "wall_s": wall,
               "passages_per_s": count / wall, "device_peak_bytes": peak,
               "spans": trace[-1]["spans"], "path": stage.name}
    (stage / "summary.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("group", choices=["vulkan", "cpu"])
    args = parser.parse_args()
    if args.group == "vulkan":
        assert (CARD / "device").read_text().strip() == "0x7590"
        devices = json.loads((ROOT / "vulkan-inventory.json").read_text())["devices"]
        device, = (d["persistent"] for d in devices if d["backend"] == "vulkan" and "9060 XT" in d["name"])
        sanity_peaks = [json.loads((ROOT / f"vulkan-{name}/summary.json").read_text())["peak_share_bytes"] for name in ("q8", "q6")]
        assert max(sanity_peaks) < 2 << 30  # 2.0+ GiB margin on the frozen cases before the longer sync
        for n in (59, 219):
            for trial, order in ((1, ("q8", "q6")), (2, ("q6", "q8"))):
                for arm in order:
                    run(device, n, arm, trial)
    else:
        for n in (59, 219):
            for trial, order in ((1, ("bge", "q8")), (2, ("q8", "bge"))):
                for arm in order:
                    run("cpu", n, arm, trial)
            for arm in ("google", "q6"):
                run("cpu", n, arm, "reference")


if __name__ == "__main__":
    main()
