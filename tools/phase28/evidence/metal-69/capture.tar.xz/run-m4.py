"""Native cgo-free Q8 qualification. Run from the one Mac scratch directory."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
EVIDENCE.mkdir(exist_ok=True)
MODEL = ROOT / "model"
NAME = "embeddinggemma-2-q8-0"
SAFE = ROOT / "tmp"
SAFE.mkdir(exist_ok=True)
STOCK = "metal-eg2-stock-v1"
COMBINED = "metal-eg2-combined-v1"
REV = "fd85e325a50f3f525f4629599ff2a5b9cca4c246"
BASE = "9ebb0de1d547aee1abffec1288639ce596a06b0c32447d502782a474118cf691"
ENV = {k: v for k, v in os.environ.items() if not k.startswith(("PBRAIN_", "GOINFER_", "GOMAX", "GOGC", "GOMEM", "GIT_", "DYLD_"))}
ENV.update(PATH="/usr/bin:/bin:/usr/sbin:/sbin", PBRAIN_ALLOW_GEMMA2="1",
           GIT_CONFIG_GLOBAL="/dev/null", GIT_CONFIG_NOSYSTEM="1",
           LC_ALL="C", TZ="UTC", GOMAXPROCS="4", TMPDIR=str(SAFE))
EXPECTED_MODEL = "6f1bd4ac6c5df7444f9cca7ca36cafe6cfa34cd6f49fefb1e0b4be8143aed8bc"


def index_fingerprint(profile):
    vector = BASE
    if profile:
        vector = hashlib.sha256(f"pbrain-vector-profile-v1\n{BASE}\n{profile}\n{REV}".encode()).hexdigest()
    return hashlib.sha256(f"pbrain-index\n1\n{vector}".encode()).hexdigest()


def manifest(project):
    return json.loads((project / "docs/brain/.pbrain/index/manifest").read_text())


def quiet(label):
    idle = []
    with (EVIDENCE / f"{label}.quiet").open("w") as record:
        for _ in range(15):
            out = subprocess.check_output(["/usr/bin/top", "-l", "3", "-s", "2", "-n", "0"], text=True,
                                          env=ENV, timeout=15)
            idle = [float(v) for v in re.findall(r"([\d.]+)% idle", out)]
            record.write(json.dumps(idle) + "\n")
            record.flush()
            if len(idle) >= 3 and min(idle[-2:]) >= 95:
                return idle[-2:]
    raise RuntimeError(f"Mac not idle: {idle}")


def prepare(label):
    project = ROOT / "runs" / label
    project.mkdir(parents=True)
    subprocess.run([str(ROOT / "pbrain-m4"), "init"], cwd=project, env=ENV, check=True, capture_output=True)
    brain = project / "docs/brain"
    for note in (ROOT / "fixture").rglob("*.md"):
        target = brain / note.relative_to(ROOT / "fixture")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(note.read_bytes())
    (brain / "pbrain.toml").write_text(f'[semantic]\nmodel = "{NAME}"\n')
    (brain / "personal.toml").write_text(f'model_path = "{MODEL}"\n')
    return project


def sync(label, project, profile, selector, binary, override="", embedded=219, reused=0, cache=None):
    environment = dict(ENV, PBRAIN_TRACE=str(EVIDENCE / f"{label}.trace.jsonl"),
                       PBRAIN_CACHE=str(cache or project / "cache"))
    if override:
        environment["PBRAIN_BENCH_METAL_SELECTOR"] = override
    idle = quiet(label)
    out = EVIDENCE / f"{label}.sync.json"
    with out.open("w") as output, (EVIDENCE / f"{label}.time").open("w") as timing:
        start = time.monotonic()
        subprocess.run(["/usr/bin/time", "-l", str(ROOT / binary), "sync", "--device", selector, "--json"],
                       cwd=project, env=environment, stdout=output, stderr=timing,
                       check=True, timeout=900)
        wall = time.monotonic() - start
    result = json.loads(out.read_text())["sections"][0]
    assert result["items"] == 22 and result["passages_embedded"] == embedded and result["passages_reused"] == reused, result
    saved = manifest(project)
    actual = next((p for p in (STOCK, COMBINED, "") if saved["fingerprint"] == index_fingerprint(p)), None)
    events = [json.loads(line) for line in (EVIDENCE / f"{label}.trace.jsonl").read_text().splitlines()]
    forwards = [event for event in events if event.get("span") == "forward"]
    attached = [event for event in events if event.get("span") == "device_attach"]
    if profile:
        assert len(attached) == 1 and attached[0]["device"] == "metal:0" and not attached[0].get("failed")
        assert all(e["device"] == "metal:0" and e["inputs"] == 1 for e in forwards)
        assert actual in (STOCK, COMBINED)
        assert not saved.get("cuda_precision_request")
    assert actual == profile, (label, profile, actual, saved)
    assert len(forwards) == embedded
    positions = sum(e["total_positions"] for e in forwards)
    if embedded == 219:
        assert positions == 110157, positions
    timing = (EVIDENCE / f"{label}.time").read_text()
    rss = int(re.search(r"(\d+)\s+maximum resident set size", timing)[1])
    footprint_re = re.search(r"(\d+)\s+peak memory footprint", timing)
    footprint = int(footprint_re[1]) if footprint_re else None
    summary = {"label": label, "idle_pct": idle, "wall_s": wall, "passages_per_s": embedded / wall,
               "profile": actual, "fingerprint": saved["fingerprint"], "forward_calls": len(forwards),
               "positions": positions, "peak_rss_bytes": rss, "peak_footprint_bytes": footprint,
               **result}
    (EVIDENCE / f"{label}.summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)


def searches(label, project):
    binary = ROOT / "pbrain-m4-cpu"
    environment = dict(ENV, PBRAIN_CACHE=str(project / "cache"))
    commands = [
        ["sync", "--status", "--json"],
        *[["search", query, "--semantic", "--json"] for query in json.loads((ROOT / "queries.json").read_text())],
    ]
    results = []
    for n, args in enumerate(commands):
        proc = subprocess.run([str(binary), *args], cwd=project, env=environment, check=True, capture_output=True,
                              text=True, timeout=30)
        result = json.loads(proc.stdout)
        (EVIDENCE / f"{label}.reader-{n}.json").write_text(proc.stdout)
        (EVIDENCE / f"{label}.reader-{n}.stderr").write_text(proc.stderr)
        if n == 0:
            sec = result["sections"][0]
            assert sec["indexed"] == 22 and not sec.get("stale"), (label, sec)
        else:
            assert not proc.stderr, proc.stderr
            ids = [hit["id"] for hit in result.get("results", [])]
            results.append(ids)
    (EVIDENCE / f"{label}.ranks.json").write_text(json.dumps(results) + "\n")


def main():
    notes = json.loads((ROOT / "fixture-219.json").read_text())
    digest = hashlib.sha256()
    for name in notes["notes"]:
        path = ROOT / "fixture" / name
        digest.update(name.encode() + b"\0" + hashlib.sha256(path.read_bytes()).digest())
    assert digest.hexdigest() == notes["digested_path_sha256"]
    model, = MODEL.glob("*.gguf")
    with model.open("rb") as reader:
        assert hashlib.file_digest(reader, "sha256").hexdigest() == EXPECTED_MODEL

    schedule = [("stock-1", STOCK), ("default-1", COMBINED), ("default-2", COMBINED), ("stock-2", STOCK)]
    for label, profile in schedule:
        sync(label, prepare(label), profile, "metal:0", "pbrain-m4-bench",
             "metal-eg2-stock" if profile == STOCK else "")
    sync("cpu", prepare("cpu"), "", "cpu", "pbrain-m4-cpu")
    for label in ("stock-1", "default-1", "cpu"):
        searches(label, ROOT / "runs" / label)

    # Copy a populated generation to test replacing it without changing a note.
    import shutil
    source = ROOT / "runs" / "stock-1"
    changed = ROOT / "runs" / "migration"
    shutil.copytree(source, changed, ignore=shutil.ignore_patterns("cache"))
    sync("migration-combined", changed, COMBINED, "metal", "pbrain-m4")
    # Neither a warm generation nor a warm cache eliminates early attachment.
    sync("noop-combined", changed, COMBINED, "metal:0", "pbrain-m4", embedded=0)
    sync("migration-stock", changed, STOCK, "metal", "pbrain-m4-bench", "metal-eg2-stock",
         embedded=0, reused=219, cache=source / "cache")


if __name__ == "__main__":
    main()
